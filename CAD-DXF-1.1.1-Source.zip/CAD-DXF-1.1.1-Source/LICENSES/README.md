# License notices

CAD DXF is a combined distribution of open-source works:

- `AGPL-3.0-or-later.txt` applies to the CAD DXF Android wrapper, DXF-only
  integration changes, build scripts, and newly written glue code. Copyright
  2026 Maclean Of Duart Enterprises Corp.
- `mlightcad-MIT.txt` applies to the original mlightcad/cad-viewer code and
  portions derived from it. Copyright 2026 mlightcad.
- `packages/cad-viewer-example/public/cad-data/fonts/OFL.txt` applies to the
  bundled Noto Sans font. Copyright The Noto Project Authors.

JavaScript dependencies retain their respective open-source licenses as
declared in `pnpm-lock.yaml` and their package metadata. The build includes no
LibreDWG converter or proprietary DWG implementation.
