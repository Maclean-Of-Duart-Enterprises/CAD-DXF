import type { AcExViewportSnapshot } from '../src/AcExSnapshotTypes'
import {
  computeOnscreenPaperViewportPass,
  computeViewportCamera,
  findDrillThroughViewport,
  modelPointToPaper,
  paperPointToModel,
  snapshotHasPaperViewports,
  viewportContainsPaperPoint,
  viewportIsNearPaperBorder,
  viewportPaperToModelScale
} from '../src/AcExPaperViewport'

const viewport: AcExViewportSnapshot = {
  paper: { minX: 0, minY: 0, maxX: 10, maxY: 10 },
  model: { minX: 100, minY: 200, maxX: 200, maxY: 400 }
}

describe('AcExPaperViewport', () => {
  it('maps paper points to model viewBox and back', () => {
    const model = paperPointToModel(viewport, 5, 5)
    expect(model).toEqual({ x: 150, y: 300 })
    expect(modelPointToPaper(viewport, model.x, model.y)).toEqual({
      x: 5,
      y: 5
    })
  })

  it('maps paper corners onto model corners', () => {
    expect(paperPointToModel(viewport, 0, 0)).toEqual({ x: 100, y: 200 })
    expect(paperPointToModel(viewport, 10, 10)).toEqual({ x: 200, y: 400 })
  })

  it('rotates paper-to-model mapping by view twist', () => {
    const twisted: AcExViewportSnapshot = {
      ...viewport,
      twist: Math.PI / 2
    }
    expect(paperPointToModel(twisted, 5, 5)).toEqual({ x: 150, y: 300 })
    const model = paperPointToModel(twisted, 10, 5)
    expect(model.x).toBeCloseTo(150)
    expect(model.y).toBeCloseTo(350)
    const paper = modelPointToPaper(twisted, model.x, model.y)
    expect(paper.x).toBeCloseTo(10)
    expect(paper.y).toBeCloseTo(5)
  })

  it('computes paper-to-model scale from width', () => {
    expect(viewportPaperToModelScale(viewport)).toBe(10)
  })

  it('detects interior vs border hits', () => {
    expect(viewportContainsPaperPoint(viewport, 5, 5)).toBe(true)
    expect(viewportContainsPaperPoint(viewport, -1, 5)).toBe(false)
    expect(viewportIsNearPaperBorder(viewport, 5, 5, 0.5)).toBe(false)
    expect(viewportIsNearPaperBorder(viewport, 0.2, 5, 0.5)).toBe(true)
  })

  it('picks the top-most interior viewport for drill-through', () => {
    const bottom: AcExViewportSnapshot = {
      paper: { minX: 0, minY: 0, maxX: 20, maxY: 20 },
      model: { minX: 0, minY: 0, maxX: 1, maxY: 1 }
    }
    const top: AcExViewportSnapshot = {
      paper: { minX: 4, minY: 4, maxX: 8, maxY: 8 },
      model: { minX: 10, minY: 10, maxX: 20, maxY: 20 }
    }
    expect(findDrillThroughViewport([bottom, top], 6, 6, 0.1)).toBe(top)
    expect(findDrillThroughViewport([bottom, top], 4.05, 6, 0.1)).toBe(bottom)
  })

  it('fits a viewport camera so model extents fill the scissor rectangle', () => {
    const fitted = computeViewportCamera(
      { minX: 0, minY: 0, maxX: 100, maxY: 50 },
      200,
      100
    )
    expect(fitted.centerX).toBe(50)
    expect(fitted.centerY).toBe(25)
    expect(fitted.frustum).toBe(50)
    expect(fitted.aspect).toBe(2)
    expect(fitted.zoom).toBe(2)
  })

  it('clips an oversized paper-viewport CSS window to the canvas', () => {
    const pass = computeOnscreenPaperViewportPass(
      viewport,
      { x: -50000, y: -20000, width: 100000, height: 50000 },
      { x: 0, y: 0, width: 800, height: 600 }
    )
    expect(pass).not.toBeNull()
    expect(pass!.hit).toEqual({ x: 0, y: 0, width: 800, height: 600 })
    const visibleW = pass!.model.maxX - pass!.model.minX
    const fullW = viewport.model.maxX - viewport.model.minX
    expect(visibleW).toBeLessThan(fullW * 0.5)
    expect(pass!.hit.width).toBeLessThanOrEqual(800)
    expect(pass!.hit.height).toBeLessThanOrEqual(600)
  })

  it('keeps the full DCS view box when the paper viewport is on-screen', () => {
    const twisted: AcExViewportSnapshot = {
      ...viewport,
      twist: Math.PI / 4
    }
    const cssVp = { x: 10, y: 20, width: 200, height: 100 }
    const pass = computeOnscreenPaperViewportPass(twisted, cssVp, {
      x: 0,
      y: 0,
      width: 800,
      height: 600
    })
    expect(pass).not.toBeNull()
    expect(pass!.hit).toEqual(cssVp)
    expect(pass!.model.minX).toBeCloseTo(viewport.model.minX)
    expect(pass!.model.minY).toBeCloseTo(viewport.model.minY)
    expect(pass!.model.maxX).toBeCloseTo(viewport.model.maxX)
    expect(pass!.model.maxY).toBeCloseTo(viewport.model.maxY)
  })

  it('returns null when the paper viewport is fully off-screen', () => {
    expect(
      computeOnscreenPaperViewportPass(
        viewport,
        { x: 2000, y: 2000, width: 100, height: 100 },
        { x: 0, y: 0, width: 800, height: 600 }
      )
    ).toBeNull()
  })

  it('detects paper layouts that carry viewports', () => {
    expect(
      snapshotHasPaperViewports([{ viewports: [viewport] }, { viewports: [] }])
    ).toBe(true)
    expect(snapshotHasPaperViewports([{ viewports: undefined }])).toBe(false)
  })
})
