import {
  decodeSnapshotBinary,
  encodeSnapshotBinary
} from './AcExSnapshotBinaryCodec'
import {
  type AcExEncodedSnapshot,
  type AcExSnapshotCompression,
  compressSnapshotBinary,
  decompressSnapshotBinary
} from './AcExSnapshotCompression'
import { ACEX_SNAPSHOT_VERSION, type AcExSnapshot } from './AcExSnapshotTypes'

const SNAPSHOT_MIME = 'application/vnd.mlightcad.acex-snapshot+binary'

export type { AcExEncodedSnapshot, AcExSnapshotCompression }

/**
 * Serializes a snapshot to a gzip-compressed base64 string for HTML embedding.
 *
 * @param snapshot - Snapshot to encode; {@link AcExSnapshot.version} must match
 *   {@link ACEX_SNAPSHOT_VERSION}.
 * @returns Base64 payload and the compression format written into the HTML.
 * @throws When the snapshot version is unsupported.
 */
export function encodeSnapshot(snapshot: AcExSnapshot): AcExEncodedSnapshot {
  if (snapshot.version !== ACEX_SNAPSHOT_VERSION) {
    throw new Error(`Unsupported snapshot version: ${snapshot.version}`)
  }
  const binary = encodeSnapshotBinary(snapshot)
  const compressed = compressSnapshotBinary(binary)
  return {
    payload: uint8ToBase64(compressed.bytes),
    compression: compressed.compression
  }
}

/**
 * Parses a gzip-compressed base64 snapshot payload from an exported HTML file.
 *
 * @param payload - Base64 text from the snapshot `<script>` element body.
 * @returns Parsed {@link AcExSnapshot} object.
 * @throws When decompression, parsing, or version validation fails.
 */
export function decodeSnapshot(payload: string): AcExSnapshot {
  return decodeSnapshotFromCompressedBytes(snapshotPayloadToCompressedBytes(payload))
}

/**
 * Decodes a gzip-compressed ACEX binary (no base64).
 * Prefer this when the runtime already retains compressed bytes for later
 * per-layout rehydration after CPU release.
 */
export function decodeSnapshotFromCompressedBytes(
  compressed: Uint8Array
): AcExSnapshot {
  const binary = decompressSnapshotBinary(compressed)
  return decodeSnapshotBinary(binary)
}

/**
 * Converts a monolithic snapshot `<script>` body to gzip bytes.
 */
export function snapshotPayloadToCompressedBytes(payload: string): Uint8Array {
  return base64ToUint8(payload.trim())
}

/**
 * MIME type stored on the snapshot `<script type="…">` attribute
 * (before the `+gzip;base64` suffix added by {@link packHtml}).
 */
export function snapshotMimeType(): string {
  return SNAPSHOT_MIME
}

function uint8ToBase64(bytes: Uint8Array): string {
  let binary = ''
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]!)
  }
  return btoa(binary)
}

function base64ToUint8(base64: string): Uint8Array {
  const binary = atob(base64)
  const bytes = new Uint8Array(binary.length)
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i)
  }
  return bytes
}
