import { accmYieldForPaint, FLOAT_TOL } from '@mlightcad/data-model'
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import { LineMaterial } from 'three/examples/jsm/lines/LineMaterial.js'
import { LineSegments2 } from 'three/examples/jsm/lines/LineSegments2.js'
import { LineSegmentsGeometry } from 'three/examples/jsm/lines/LineSegmentsGeometry.js'

import { decodeChunkGzip } from './AcExChunkBinaryCodec'
import {
  AcExCommandSessionPanel,
  type AcExCommandSessionUiState
} from './AcExCommandSessionPanel'
import { acexCssTopLeftRectToGl, acexWcsBoxToCssRect } from './AcExCssRect'
import { acexSetDocsBaseUrl } from './AcExDocsUrl'
import {
  createAcExHtmlAccessKey,
  decryptAcExHtmlSnapshotPayload,
  isAcExHtmlAccessExpired,
  parseAcExHtmlAccessManifest
} from './AcExHtmlAccess'
import {
  ACEX_HTML_MAX_PASSWORD_ATTEMPTS,
  lockAcExHtmlAccessGate,
  promptAcExHtmlAccessPassword,
  showAcExHtmlAccessExpired
} from './AcExHtmlAccessGate'
import {
  acexHtmlIsPhoneLayout,
  setupAcExHtmlDrawerSheets
} from './AcExHtmlDrawerSheet'
import {
  createAcExDomEmbeddedPackageFetch,
  decryptAcExEmbeddedManifest,
  parseAcExEmbeddedPackageConfig
} from './AcExHtmlEmbeddedPackage'
import { setupAcExHtmlExpiryMonitor } from './AcExHtmlExpiryUi'
import { AcExHtmlI18n, detectAcExHtmlLocale } from './AcExHtmlI18n'
import { AcExHtmlIcons } from './AcExHtmlIcons'
import {
  type AcExHtmlMainToolbarController,
  setupAcExHtmlMainToolbar
} from './AcExHtmlMainToolbar'
import { setupAcExHtmlMeasurePanel } from './AcExHtmlMeasurePanel'
import { setupAcExHtmlMeasureSettings } from './AcExHtmlMeasureSettings'
import { setupAcExHtmlNavTools } from './AcExHtmlNavTools'
import {
  ACEX_PACKAGE_DIRECTORY_ORIGIN,
  acexGlobalFetch,
  chooseInitialManifestHref,
  probePackageManifest,
  resolveViewerManifestUrl
} from './AcExHtmlPackageBootstrap'
import { promptAcExHtmlPackageSource } from './AcExHtmlPackageSourceGate'
import { setupAcExHtmlReviewPanel } from './AcExHtmlReviewPanel'
import { acexSyncHtmlShortCutSelection } from './AcExHtmlShortCutSelection'
import { setupAcExHtmlShortCutToolbar } from './AcExHtmlShortCutToolbar'
import {
  acedClearDomSelection,
  acedGuardCanvasTouchCallout
} from './AcExHtmlSimpleViewerUi'
import {
  type AcExIdlePointerHost,
  acexIdlePointerStrategy
} from './AcExIdlePointerStrategy'
import {
  type AcExBatchExtentEntry,
  collectLayoutBatchExtentEntries,
  computeIntelligentExtentsFromBatchEntries,
  computeLayerExtentsMap,
  resolveLayoutViewExtents} from './AcExLayerExtents'
import { AcExMarkupController } from './AcExMarkup'
import { AcExMeasureController } from './AcExMeasurement'
import {
  acexBindMobileSnapLoupe,
  acexHideMobileSnapLoupe,
  acexRefreshMobileSnapLoupe,
  acexSetMobileSnapLoupePreciseCapture
} from './AcExMobileSnapLoupe'
import {
  type AcExCircleOrArcNearHit,
  AcExOsnapIndex,
  estimateOsnapRebuildWork
} from './AcExOsnap'
import { AcExOsnapMarker } from './AcExOsnapMarker'
import {
  ACEX_GEOMETRY_CHUNK_FETCH_CONCURRENCY,
  createAcExOrderedBytePrefetcher,
  loadAcExPackageLayoutOsnap,
  resolveChunkUrl,
  snapshotSkeletonFromManifest
} from './AcExPackageLoader'
import type { AcExPackageManifest } from './AcExPackageTypes'
import {
  computeOnscreenPaperViewportPass,
  computeViewportCamera,
  findDrillThroughViewport,
  modelPointToPaper,
  paperPointToModel,
  snapshotHasPaperViewports,
  viewportPaperToModelScale
} from './AcExPaperViewport'
import {
  AcExCameraZoomUniform,
  createViewerLineMaterial,
  createViewerMeshMaterial,
  createViewerPointsMaterial
} from './AcExPatternSnapshot'
import { acexSelectionModeFromDrag } from './AcExSelectionBox'
import { setupAcExSessionDrawStyle } from './AcExSessionDrawStyle'
import { createAcExSessionHistory } from './AcExSessionHistory'
import {
  acexHideSimulatedMouseCursor,
  acexRefreshSimulatedMouseCursor
} from './AcExSimulatedMouseCursor'
import {
  ACEX_SNAP_LOUPE_INSET_PX,
  ACEX_SNAP_LOUPE_SIZE_PX,
  ACEX_SNAP_LOUPE_ZOOM,
  AcExSnapLoupe
} from './AcExSnapLoupe'
import {
  decodeSnapshotFromCompressedBytes,
  snapshotPayloadToCompressedBytes
} from './AcExSnapshotCodec'
import { ACEX_MAX_COMPRESSED_BYTES } from './AcExSnapshotCompression'
import type {
  AcExExtents,
  AcExLayoutSnapshot,
  AcExLineBatch,
  AcExMeshBatch,
  AcExSnapshot,
  AcExViewerMode
} from './AcExSnapshotTypes'
import {
  acexIsSimulatedMouseEnabled,
  type AcExTouchPickHudHost,
  acexTouchPickStrategy
} from './AcExTouchPickStrategy'
import {
  acexShouldIgnoreCompatMouse,
  acexSinkFollowingClick,
  AcExTouchPointSession
} from './AcExTouchPointSession'
import { acexMaybeShowTouchPointTutorial } from './AcExTouchPointTutorial'
import {
  assignLayoutGeometryFrom,
  layoutHasBatchGeometry,
  releaseInactiveLayoutBatchBuffers,
  releaseLayerGroupsGeometryCpuArrays,
  releaseLayoutBatchBuffers,
  releaseSnapshotBatchBuffers,
  releaseSnapshotOsnapCatalogs,
  removeSnapshotElement
} from './AcExViewerMemory'

/** Matches {@link AcTrBaseView} orthographic half-height in world units. */
const ACEX_CAMERA_FRUSTUM = 400
const ACEX_CAMERA_DISTANCE = 500

function hideLoading(): void {
  const loading = document.getElementById('mlcad-loading')
  if (!loading) return
  // Keep the node so the access/expiry gate can be shown again after open.
  loading.classList.add('mlcad-loading--done')
}

function showViewerError(message: string): void {
  const loading = document.getElementById('mlcad-loading')
  if (!loading) return
  loading.replaceChildren()
  const box = document.createElement('div')
  box.style.cssText =
    'padding:24px;color:#e8eaed;text-align:center;max-width:480px;line-height:1.5'
  box.textContent = message
  loading.appendChild(box)
  loading.classList.remove('mlcad-loading--done')
}

/**
 * Set by {@link bootstrap} once `render` exists so async IMAGE/OLE textures can
 * force a frame after decode (mesh materials start at opacity 0).
 */
let requestViewerTextureRepaint: (() => void) | null = null

/** Fallback when view mode omits the footer status bar. */
function createHiddenStatusSink(): HTMLElement {
  const el = document.createElement('div')
  el.hidden = true
  el.setAttribute('aria-hidden', 'true')
  return el
}

/** Keeps `#mlcad-status-bar` hidden when empty so it does not reserve chrome. */
function wireStatusBarVisibility(el: HTMLElement): void {
  const sync = () => {
    el.hidden = !el.textContent?.trim()
  }
  sync()
  const observer = new MutationObserver(sync)
  observer.observe(el, {
    characterData: true,
    childList: true,
    subtree: true
  })
}

const ACEX_HTML_THEME_STORAGE_KEY = 'mlcad-html-theme'

type AcExHtmlTheme = 'dark' | 'light'

function loadStoredTheme(): AcExHtmlTheme {
  try {
    const raw = localStorage.getItem(ACEX_HTML_THEME_STORAGE_KEY)
    if (raw === 'light' || raw === 'dark') return raw
  } catch {
    /* private mode */
  }
  return 'dark'
}

function applyHtmlTheme(theme: AcExHtmlTheme): void {
  document.documentElement.setAttribute('data-mlcad-theme', theme)
  try {
    localStorage.setItem(ACEX_HTML_THEME_STORAGE_KEY, theme)
  } catch {
    /* private mode */
  }
  const btn = document.getElementById('mlcad-theme-btn')
  if (!btn) return
  const icon = btn.querySelector('.mlcad-tool-btn-icon')
  const label = btn.querySelector('.mlcad-tool-btn-label')
  // Match cad-simple-ui-plugin: show the current theme icon; the label is the
  // action (switch to the other theme).
  const nextKey = theme === 'light' ? 'toolbar.themeLight' : 'toolbar.themeDark'
  const nextIcon =
    theme === 'light' ? AcExHtmlIcons.themeLight : AcExHtmlIcons.themeDark
  const nextTitle = theme === 'light' ? 'Light' : 'Dark'
  if (icon) icon.innerHTML = nextIcon
  btn.setAttribute('data-i18n-key', nextKey)
  btn.setAttribute('data-i18n-attr', 'title aria-label')
  btn.setAttribute('title', nextTitle)
  btn.setAttribute('aria-label', nextTitle)
  if (label) {
    label.setAttribute('data-i18n-key', nextKey)
    label.setAttribute('data-i18n-text', '')
  }
}

/**
 * Syncs the simulated-mouse settings button label / active class with the
 * persisted preference.
 *
 * @param enabled - Current preference value.
 * @param i18n - Active i18n instance used to refresh visible labels.
 */
function syncSimulatedMouseButton(enabled: boolean, i18n: AcExHtmlI18n): void {
  const btn = document.getElementById('mlcad-simulated-mouse-btn')
  if (!btn) return
  const key = enabled ? 'toolbar.simulatedMouseOn' : 'toolbar.simulatedMouseOff'
  btn.classList.toggle('active', enabled)
  btn.setAttribute('data-i18n-key', key)
  btn.setAttribute('data-i18n-attr', 'title aria-label')
  const title = i18n.t(key)
  btn.setAttribute('title', title)
  btn.setAttribute('aria-label', title)
  const label = btn.querySelector('.mlcad-tool-btn-label')
  if (label) {
    label.setAttribute('data-i18n-key', key)
    label.setAttribute('data-i18n-text', '')
    label.textContent = title
  }
}

/** Luminance heuristic matching live-viewer black/white background toggles. */
function isLightRgb(hex: number): boolean {
  const r = (hex >> 16) & 0xff
  const g = (hex >> 8) & 0xff
  const b = hex & 0xff
  return (r * 299 + g * 587 + b * 114) / 1000 >= 128
}

function invertNearBlackWhite(hex: number): number | null {
  const r = (hex >> 16) & 0xff
  const g = (hex >> 8) & 0xff
  const b = hex & 0xff
  const max = Math.max(r, g, b)
  const min = Math.min(r, g, b)
  // Near grayscale extremes only (ACI 7 / black ink).
  if (max - min > 16) return null
  if (max <= 40) return 0xffffff
  if (min >= 215) return 0x000000
  return null
}

function flipMaterialColor(material: THREE.Material): void {
  const colorMats = material as THREE.MeshBasicMaterial & {
    color?: THREE.Color
    uniforms?: { u_color?: { value: THREE.Color } }
  }
  if (colorMats.color?.getHex) {
    const next = invertNearBlackWhite(colorMats.color.getHex())
    if (next != null) colorMats.color.setHex(next)
  }
  const uniformColor = colorMats.uniforms?.u_color?.value
  if (uniformColor?.getHex) {
    const next = invertNearBlackWhite(uniformColor.getHex())
    if (next != null) uniformColor.setHex(next)
  }
}

function flipNearBlackWhiteMaterials(root: THREE.Object3D): void {
  root.traverse(obj => {
    const mat = (obj as THREE.Mesh).material
    if (!mat) return
    if (Array.isArray(mat)) {
      for (const m of mat) flipMaterialColor(m)
    } else {
      flipMaterialColor(mat)
    }
  })
}

/**
 * Opens a self-contained HTML that embeds progressive ACEX chunks
 * (`#mlcad-package` with `mode: "embedded"`).
 *
 * Chunk `<script>` nodes stay in the document; bytes are re-read on demand
 * so open does not decode every gzip payload into a resident Map / IndexedDB.
 */
async function openAcExHtmlEmbeddedPackageSession(
  packageEl: HTMLElement,
  i18n: AcExHtmlI18n
): Promise<{
  manifest: AcExPackageManifest
  decryptKey: CryptoKey | null
  expiresAt: number | null
} | null> {
  const config = parseAcExEmbeddedPackageConfig(packageEl.textContent)
  if (!config) {
    showViewerError(
      i18n.t('status.loadFailed', { error: 'Invalid embedded package.' })
    )
    return null
  }

  const accessEl = document.getElementById('mlcad-access')
  const access = parseAcExHtmlAccessManifest(accessEl?.textContent)
  const expiresAt = access?.expiresAt ?? null

  if (access && isAcExHtmlAccessExpired(access)) {
    showAcExHtmlAccessExpired(i18n, expiresAt)
    return null
  }

  let manifest: AcExPackageManifest | null = null
  let decryptKey: CryptoKey | null = null

  if (config.encrypted) {
    if (!access?.encrypted || !access.salt) {
      showViewerError(
        i18n.t('status.loadFailed', { error: 'Missing access metadata.' })
      )
      return null
    }

    let failedAttempts = 0
    let pendingError: 'access.wrongPassword' | undefined

    while (failedAttempts < ACEX_HTML_MAX_PASSWORD_ATTEMPTS) {
      try {
        const password = await promptAcExHtmlAccessPassword(i18n, {
          errorKey: pendingError,
          expiresAt
        })
        pendingError = undefined
        try {
          const { key } = await createAcExHtmlAccessKey(password, access.salt)
          manifest = await decryptAcExEmbeddedManifest(
            config.encryptedManifest,
            key
          )
          decryptKey = key
          break
        } catch {
          failedAttempts++
          if (failedAttempts >= ACEX_HTML_MAX_PASSWORD_ATTEMPTS) {
            lockAcExHtmlAccessGate(i18n)
            return null
          }
          pendingError = 'access.wrongPassword'
        }
      } catch {
        return null
      }
    }
    if (!manifest || !decryptKey) {
      return null
    }
  } else {
    manifest = config.manifest
  }

  return {
    manifest,
    decryptKey,
    expiresAt
  }
}

/**
 * Resolves a multi-file package session for generic `viewer.html`:
 * query `?manifest=` / `?acex=` → config → sibling `drawing.acex.json` →
 * folder / URL picker when the default file is missing.
 */
async function openAcExHtmlPackageSession(options: {
  pageUrl: string
  search: string
  configManifestUrl?: string
  i18n: AcExHtmlI18n
}): Promise<{
  manifest: AcExPackageManifest
  manifestUrl: string
  fetchImpl: typeof fetch
} | null> {
  const { i18n } = options
  const initial = chooseInitialManifestHref({
    search: options.search,
    configManifestUrl: options.configManifestUrl
  })

  const tryUrl = async (
    href: string,
    fetchImpl: typeof fetch = acexGlobalFetch
  ): Promise<
    | { ok: true; manifest: AcExPackageManifest; manifestUrl: string }
    | { ok: false; reason: 'not-found' | 'invalid' | 'network'; error: Error }
  > => {
    let manifestUrl: string
    try {
      manifestUrl = resolveViewerManifestUrl(href, options.pageUrl)
    } catch (error) {
      return {
        ok: false,
        reason: 'invalid',
        error: error instanceof Error ? error : new Error(String(error))
      }
    }
    const probed = await probePackageManifest(manifestUrl, fetchImpl)
    if (!probed.ok) {
      return { ok: false, reason: probed.reason, error: probed.error }
    }
    return { ok: true, manifest: probed.manifest, manifestUrl }
  }

  const first = await tryUrl(initial.href)
  if (first.ok) {
    return {
      manifest: first.manifest,
      manifestUrl: first.manifestUrl,
      fetchImpl: acexGlobalFetch
    }
  }

  // Query / explicit URL failures are fatal (show error, no picker).
  if (initial.fromQuery || first.reason === 'invalid') {
    const message =
      first.reason === 'invalid'
        ? i18n.t('package.invalidManifest', { error: first.error.message })
        : i18n.t('package.loadFailed', { error: first.error.message })
    showViewerError(message)
    return null
  }

  // Sibling default missing → let the user pick a folder or paste a URL.
  let gateErrorKey:
    | 'package.manifestNotFound'
    | 'package.invalidManifest'
    | 'package.folderMissingManifest'
    | 'package.loadFailed'
    | undefined = 'package.manifestNotFound'
  let gateErrorMessage: string | undefined

  for (;;) {
    let choice: Awaited<ReturnType<typeof promptAcExHtmlPackageSource>>
    try {
      choice = await promptAcExHtmlPackageSource(i18n, {
        errorKey: gateErrorKey,
        errorMessage: gateErrorMessage
      })
    } catch {
      showViewerError(i18n.t('package.manifestNotFound'))
      return null
    }

    if (choice.kind === 'url') {
      const loaded = await tryUrl(choice.href)
      if (loaded.ok) {
        return {
          manifest: loaded.manifest,
          manifestUrl: loaded.manifestUrl,
          fetchImpl: acexGlobalFetch
        }
      }
      gateErrorKey =
        loaded.reason === 'invalid'
          ? 'package.invalidManifest'
          : 'package.loadFailed'
      gateErrorMessage = i18n.t(gateErrorKey, {
        error: loaded.error.message
      })
      continue
    }

    const loaded = await tryUrl(choice.manifestUrl, choice.fetchImpl)
    if (loaded.ok) {
      return {
        manifest: loaded.manifest,
        manifestUrl: loaded.manifestUrl,
        fetchImpl: choice.fetchImpl
      }
    }
    gateErrorKey =
      loaded.reason === 'invalid'
        ? 'package.invalidManifest'
        : 'package.loadFailed'
    gateErrorMessage = i18n.t(gateErrorKey, {
      error: loaded.error.message
    })
  }
}

function bootstrap(): void {
  void accmYieldForPaint().then(() => startViewer())
}

async function resolveSnapshotPayload(
  snapshotEl: HTMLElement,
  i18n: AcExHtmlI18n
): Promise<{ payload: string; expiresAt: number | null } | null> {
  const accessEl = document.getElementById('mlcad-access')
  const manifest = parseAcExHtmlAccessManifest(accessEl?.textContent)
  const expiresAt = manifest?.expiresAt ?? null

  if (manifest && isAcExHtmlAccessExpired(manifest)) {
    showAcExHtmlAccessExpired(i18n, expiresAt)
    return null
  }

  const payload = snapshotEl.textContent?.trim() ?? ''

  if (!manifest?.encrypted) {
    return { payload, expiresAt }
  }

  if (!manifest.salt) {
    showViewerError(
      i18n.t('status.loadFailed', { error: 'Missing access metadata.' })
    )
    return null
  }

  let failedAttempts = 0
  let pendingError: 'access.wrongPassword' | undefined

  while (failedAttempts < ACEX_HTML_MAX_PASSWORD_ATTEMPTS) {
    try {
      const password = await promptAcExHtmlAccessPassword(i18n, {
        errorKey: pendingError,
        expiresAt
      })
      pendingError = undefined
      try {
        return {
          payload: await decryptAcExHtmlSnapshotPayload(
            password,
            payload,
            manifest.salt
          ),
          expiresAt
        }
      } catch {
        failedAttempts++
        if (failedAttempts >= ACEX_HTML_MAX_PASSWORD_ATTEMPTS) {
          lockAcExHtmlAccessGate(i18n)
          return null
        }
        pendingError = 'access.wrongPassword'
      }
    } catch {
      return null
    }
  }

  return null
}

async function startViewer(): Promise<void> {
  const root = document.getElementById('mlcad-root')
  const snapshotEl = document.getElementById('mlcad-snapshot')
  const packageEl = document.getElementById('mlcad-package')
  if (!root || (!snapshotEl && !packageEl)) {
    hideLoading()
    return
  }

  const i18n = new AcExHtmlI18n(detectAcExHtmlLocale())
  i18n.applyToDocument()

  const statusEl =
    document.getElementById('mlcad-status-bar') ?? createHiddenStatusSink()
  wireStatusBarVisibility(statusEl)

  let snapshot: AcExSnapshot
  let expiresAt: number | null = null
  /** Gzip ACEX retained for monolithic multi-layout CPU rehydrate after release. */
  let monolithicCompressed: Uint8Array | null = null
  let packageSession: {
    manifest: AcExPackageManifest
    manifestUrl: string
    fetchImpl: typeof fetch
    loadedLayouts: Set<string>
    loadedOsnapLayouts: Set<string>
  } | null = null
  /** Embedded progressive package pending fetch wiring after layout flags. */
  let pendingEmbedded: {
    manifest: AcExPackageManifest
    decryptKey: CryptoKey | null
    expiresAt: number | null
  } | null = null

  try {
    if (packageEl) {
      const rawConfig = packageEl.textContent?.trim() || '{}'
      let packageMode: string | undefined
      try {
        packageMode = (JSON.parse(rawConfig) as { mode?: string }).mode
      } catch {
        packageMode = undefined
      }

      if (packageMode === 'embedded') {
        const opened = await openAcExHtmlEmbeddedPackageSession(packageEl, i18n)
        if (!opened) {
          return
        }
        snapshot = snapshotSkeletonFromManifest(opened.manifest)
        expiresAt = opened.expiresAt
        pendingEmbedded = opened
        removeSnapshotElement(packageEl)
      } else {
        const config = JSON.parse(rawConfig) as {
          manifestUrl?: string
        }
        const opened = await openAcExHtmlPackageSession({
          pageUrl: window.location.href,
          search: window.location.search,
          configManifestUrl: config.manifestUrl,
          i18n
        })
        if (!opened) {
          return
        }
        snapshot = snapshotSkeletonFromManifest(opened.manifest)
        packageSession = {
          manifest: opened.manifest,
          manifestUrl: opened.manifestUrl,
          fetchImpl: opened.fetchImpl,
          loadedLayouts: new Set(),
          loadedOsnapLayouts: new Set()
        }
        removeSnapshotElement(packageEl)
      }
    } else if (snapshotEl) {
      const resolved = await resolveSnapshotPayload(snapshotEl, i18n)
      if (!resolved) {
        return
      }
      expiresAt = resolved.expiresAt
      // Retain gzip so layouts can be rehydrated after CPU release on switch.
      monolithicCompressed = snapshotPayloadToCompressedBytes(resolved.payload)
      snapshot = decodeSnapshotFromCompressedBytes(monolithicCompressed)
      removeSnapshotElement(snapshotEl)
    } else {
      hideLoading()
      return
    }
  } catch (error) {
    showViewerError(i18n.t('status.loadFailed', { error: String(error) }))
    return
  }

  const viewerMode: AcExViewerMode = snapshot.meta.viewerMode ?? 'measure'
  const measureEnabled = viewerMode === 'measure'

  if (snapshot.meta.docsBaseUrl) {
    acexSetDocsBaseUrl(snapshot.meta.docsBaseUrl)
  }

  const grip = snapshot.meta.grip
  root.style.setProperty('--ml-ui-grip-size', `${grip?.size ?? 8}px`)
  root.style.setProperty('--ml-ui-grip-normal', grip?.colorCss ?? '#0080ff')
  root.style.setProperty('--ml-ui-grip-hot', grip?.hotColorCss ?? '#ff0000')

  applyHtmlTheme(loadStoredTheme())
  syncSimulatedMouseButton(acexIsSimulatedMouseEnabled(), i18n)
  i18n.applyToDocument()

  const initialLayout =
    snapshot.layouts.find(l => l.btrId === snapshot.activeLayoutBtrId) ??
    snapshot.layouts[0]
  if (!initialLayout) {
    showViewerError(i18n.t('status.noLayout'))
    return
  }
  let layout = initialLayout

  const layerVisible = new Map(
    snapshot.layers.map(layer => [layer.name, layer.visible])
  )

  const canvasHost = document.getElementById('mlcad-canvas-host') ?? root
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  canvasHost.insertBefore(renderer.domElement, canvasHost.firstChild)
  // Block iOS Safari Copy / selection callout on long-press so the snap loupe wins.
  // Page-lifetime canvas: no dispose path; listeners end with document unload.
  acedGuardCanvasTouchCallout(renderer.domElement, canvasHost)

  const scene = new THREE.Scene()
  const originalBackground = snapshot.meta.background >>> 0
  let backgroundSwapped = false
  scene.background = new THREE.Color(originalBackground)

  const getCanvasSize = () => ({
    width: canvasHost.clientWidth || window.innerWidth,
    height: canvasHost.clientHeight || window.innerHeight
  })

  const { width: initialWidth, height: initialHeight } = getCanvasSize()
  const camera = new THREE.OrthographicCamera(
    -initialWidth / 2,
    initialWidth / 2,
    initialHeight / 2,
    -initialHeight / 2,
    0.1,
    1000
  )
  camera.position.set(0, 0, ACEX_CAMERA_DISTANCE)
  camera.up.set(0, 1, 0)
  camera.updateProjectionMatrix()

  const controls = createOrbitControls(camera, renderer.domElement)

  const modelLayout = snapshot.layouts.find(item => item.isModelSpace)
  const hasPaperViewports = snapshotHasPaperViewports(snapshot.layouts)

  if (pendingEmbedded) {
    const embeddedFetch = createAcExDomEmbeddedPackageFetch({
      manifest: pendingEmbedded.manifest,
      decryptKey: pendingEmbedded.decryptKey
    })
    packageSession = {
      manifest: pendingEmbedded.manifest,
      manifestUrl: embeddedFetch.manifestUrl,
      fetchImpl: embeddedFetch.fetchImpl,
      loadedLayouts: new Set(),
      loadedOsnapLayouts: new Set()
    }
    pendingEmbedded = null
  }

  const paperLayerGroups = new Map<string, THREE.Group>()
  const modelLayerGroups = new Map<string, THREE.Group>()
  const paperWideLineMaterials: LineMaterial[] = []
  const modelWideLineMaterials: LineMaterial[] = []
  const wideLineResolution = new THREE.Vector2(initialWidth, initialHeight)

  const paperRoot = new THREE.Group()
  paperRoot.name = 'paper-space'
  const modelRoot = new THREE.Group()
  modelRoot.name = 'model-space'
  const modelScene = new THREE.Scene()
  const viewportCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 1000)
  viewportCamera.up.set(0, 1, 0)
  /** Orthographic camera used only for the snap-loupe scissor pass. */
  const loupeCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 1000)
  loupeCamera.up.set(0, 1, 0)
  const savedViewportBox = new THREE.Vector4()
  /** DOM chrome (border and OSNAP glyph) for the snap loupe. */
  const snapLoupe = new AcExSnapLoupe(canvasHost)
  /** Last client sample while the loupe is visible; `null` when hidden. */
  let loupeSample: { clientX: number; clientY: number } | null = null

  const getOrCreateLayerGroup = (
    groups: Map<string, THREE.Group>,
    parent: THREE.Object3D,
    layerName: string
  ): THREE.Group => {
    let group = groups.get(layerName)
    if (!group) {
      group = new THREE.Group()
      group.name = layerName
      group.visible = layerVisible.get(layerName) !== false
      groups.set(layerName, group)
      parent.add(group)
    }
    return group
  }

  const appendBatchesToScene = (
    lineBatches: AcExLineBatch[],
    meshBatches: AcExMeshBatch[],
    groups: Map<string, THREE.Group>,
    parent: THREE.Object3D,
    materials: LineMaterial[]
  ) => {
    for (const batch of lineBatches) {
      const object = createLineObject(batch, materials, wideLineResolution)
      if (object) getOrCreateLayerGroup(groups, parent, batch.layer).add(object)
    }
    for (const batch of meshBatches) {
      const object = batch.points
        ? createPointObject(batch)
        : createMeshObject(batch)
      if (object) getOrCreateLayerGroup(groups, parent, batch.layer).add(object)
    }
  }

  const populateLayoutGeometry = (
    next: AcExLayoutSnapshot,
    groups: Map<string, THREE.Group>,
    parent: THREE.Object3D,
    materials: LineMaterial[]
  ) => {
    appendBatchesToScene(
      next.lineBatches,
      next.meshBatches,
      groups,
      parent,
      materials
    )
  }

  /** Set after {@link render} exists; paints each package chunk as it arrives. */
  let paintPackageChunk: (() => void) | null = null

  const disposeMaterial = (material: THREE.Material) => {
    const textured = material as THREE.MeshBasicMaterial & {
      map?: THREE.Texture | null
    }
    if (textured.map) {
      textured.map.dispose()
      textured.map = null
    }
    material.dispose()
  }

  const disposeObject3D = (object: THREE.Object3D) => {
    object.traverse(child => {
      const mesh = child as THREE.Mesh
      if (mesh.geometry) mesh.geometry.dispose()
      const material = mesh.material
      if (Array.isArray(material)) {
        material.forEach(item => disposeMaterial(item))
      } else if (material) {
        disposeMaterial(material)
      }
    })
  }

  /**
   * Drops CPU batches (+ optional GPU) for a package layout that is no longer
   * on screen so it can be re-fetched later. Model space is kept when paper
   * viewports still need it.
   */
  const unloadPackageLayout = (
    target: AcExLayoutSnapshot,
    options: { disposeGpu: boolean }
  ) => {
    if (!packageSession) return
    if (options.disposeGpu) {
      clearLayoutSceneGeometry(target)
    }
    releaseLayoutBatchBuffers(target)
    target.osnap = undefined
    packageSession.loadedLayouts.delete(target.btrId)
    packageSession.loadedOsnapLayouts.delete(target.btrId)
  }

  const layoutGpuResident = (target: AcExLayoutSnapshot): boolean => {
    if (target.isModelSpace) return modelLayerGroups.size > 0
    return paperLayerGroups.size > 0
  }

  const packageLayoutHasChunks = (btrId: string): boolean => {
    if (!packageSession) return false
    const ref = packageSession.manifest.layouts.find(
      item => item.btrId === btrId
    )
    return (ref?.chunkIds.length ?? 0) > 0
  }

  /**
   * True when the layout has no GPU and no CPU batches but a reload source exists.
   */
  const layoutNeedsGeometrySource = (target: AcExLayoutSnapshot): boolean => {
    if (layoutGpuResident(target) || layoutHasBatchGeometry(target)) {
      return false
    }
    if (packageSession) return packageLayoutHasChunks(target.btrId)
    return monolithicCompressed != null
  }

  const rehydrateMonolithicLayout = (target: AcExLayoutSnapshot): void => {
    if (!monolithicCompressed) return
    const full = decodeSnapshotFromCompressedBytes(monolithicCompressed)
    const source = full.layouts.find(item => item.btrId === target.btrId)
    if (!source) return
    assignLayoutGeometryFrom(target, source)
  }

  /**
   * Per-batch AABBs captured while CPU positions are resident. Intelligent fit
   * must use this after {@link releaseCpuAfterGpuUpload} clears batches —
   * including model space loaded as a paper-viewport sidecar.
   */
  const batchExtentsByLayout = new Map<string, AcExBatchExtentEntry[]>()
  const refreshBatchExtentCache = (target: AcExLayoutSnapshot) => {
    const entries = collectLayoutBatchExtentEntries(target)
    if (entries.length > 0) {
      batchExtentsByLayout.set(target.btrId, entries)
    }
  }

  /**
   * After GPU upload (+ hybrid OSNAP when measure is on), drop CPU typed arrays.
   * GPU buffers stay; layout switch reloads from package chunks or monolithic gzip.
   */
  const releaseCpuAfterGpuUpload = () => {
    // Snapshot every layout that still has CPU batches (active + sidecar model).
    for (const target of snapshot.layouts) {
      refreshBatchExtentCache(target)
    }
    releaseLayerGroupsGeometryCpuArrays(paperLayerGroups)
    releaseLayerGroupsGeometryCpuArrays(modelLayerGroups)
    releaseSnapshotBatchBuffers(snapshot)
    releaseSnapshotOsnapCatalogs(snapshot)
    // Force ACEO re-fetch when geometry is rehydrated for a later rebuild.
    packageSession?.loadedOsnapLayouts.clear()
  }

  const disposePaperGeometry = () => {
    for (const group of paperLayerGroups.values()) {
      paperRoot.remove(group)
      disposeObject3D(group)
    }
    paperLayerGroups.clear()
    paperWideLineMaterials.length = 0
  }

  const clearLayoutSceneGeometry = (target: AcExLayoutSnapshot) => {
    if (target.isModelSpace) {
      for (const group of modelLayerGroups.values()) {
        modelRoot.remove(group)
        disposeObject3D(group)
      }
      modelLayerGroups.clear()
      modelWideLineMaterials.length = 0
    } else {
      disposePaperGeometry()
    }
  }

  /**
   * Download window for package chunks. Remote packages fetch up to six
   * chunks in parallel so latency/bandwidth overlap; inflate + GPU upload +
   * paint still consume chunks strictly in `chunkIds` order below, so
   * progressive rendering is unchanged. Embedded / local-directory packages
   * resolve bytes from DOM nodes / an in-memory map (with synchronous base64
   * decode), where a wider window only adds startup jank — keep them serial.
   */
  const packageChunkFetchConcurrency = packageSession?.manifestUrl.startsWith(
    ACEX_PACKAGE_DIRECTORY_ORIGIN
  )
    ? 1
    : ACEX_GEOMETRY_CHUNK_FETCH_CONCURRENCY

  /**
   * Fetches package geometry chunks into `target` batches. When `uploadToGpu` is
   * true, paints each chunk; when false, only restores CPU arrays (hybrid OSNAP)
   * without touching an already-resident GPU scene.
   */
  const fetchPackageLayoutChunks = async (
    target: AcExLayoutSnapshot,
    options: { uploadToGpu: boolean }
  ): Promise<void> => {
    if (!packageSession) return
    const session = packageSession
    const layoutRef = session.manifest.layouts.find(
      item => item.btrId === target.btrId
    )
    if (!layoutRef) {
      session.loadedLayouts.add(target.btrId)
      return
    }

    const chunkById = new Map(
      session.manifest.chunks.map(chunk => [chunk.id, chunk])
    )
    const chunks = layoutRef.chunkIds
      .map(id => chunkById.get(id))
      .filter((chunk): chunk is NonNullable<typeof chunk> => chunk != null)

    // Parallel download window; bytes may arrive out of order but the
    // prefetcher hands them back in manifest (paint) order.
    const prefetcher = createAcExOrderedBytePrefetcher(
      chunks,
      packageChunkFetchConcurrency,
      async chunkRef => {
        const url = resolveChunkUrl(session.manifestUrl, chunkRef.href)
        const response = await session.fetchImpl(url)
        if (!response.ok) {
          throw new Error(`Failed to load geometry chunk (${response.status})`)
        }
        const contentLength = response.headers.get('content-length')
        if (contentLength != null) {
          const declared = Number(contentLength)
          if (
            Number.isFinite(declared) &&
            declared > ACEX_MAX_COMPRESSED_BYTES
          ) {
            throw new Error('Geometry chunk exceeds size limit')
          }
        }
        const buffer = await response.arrayBuffer()
        if (buffer.byteLength > ACEX_MAX_COMPRESSED_BYTES) {
          throw new Error('Geometry chunk exceeds size limit')
        }
        return new Uint8Array(buffer)
      }
    )

    let loadedChunks = 0
    for (;;) {
      const entry = await prefetcher.next()
      if (!entry) {
        break
      }
      statusEl.textContent = i18n.t('status.loadingChunks', {
        loaded: String(loadedChunks),
        total: String(chunks.length)
      })
      const decoded = decodeChunkGzip(entry.bytes)
      const lineStart = target.lineBatches.length
      const meshStart = target.meshBatches.length
      target.lineBatches.push(...decoded.lineBatches)
      target.meshBatches.push(...decoded.meshBatches)

      if (options.uploadToGpu) {
        const isModel = target.isModelSpace
        appendBatchesToScene(
          target.lineBatches.slice(lineStart),
          target.meshBatches.slice(meshStart),
          isModel ? modelLayerGroups : paperLayerGroups,
          isModel ? modelRoot : paperRoot,
          isModel ? modelWideLineMaterials : paperWideLineMaterials
        )
        // Show this chunk immediately — do not wait for remaining downloads.
        paintPackageChunk?.()
        await accmYieldForPaint()
      }

      loadedChunks += 1
      statusEl.textContent = i18n.t('status.loadingChunks', {
        loaded: String(loadedChunks),
        total: String(chunks.length)
      })
    }

    session.loadedLayouts.add(target.btrId)
  }

  const loadPackageLayoutGeometry = async (
    target: AcExLayoutSnapshot
  ): Promise<void> => {
    if (!packageSession) return
    // GPU still holds this layout (CPU was released after upload) — do not reload.
    if (
      packageSession.loadedLayouts.has(target.btrId) &&
      (layoutHasBatchGeometry(target) || layoutGpuResident(target))
    ) {
      return
    }
    // CPU was released and GPU torn down — allow a fresh fetch.
    packageSession.loadedLayouts.delete(target.btrId)
    const layoutRef = packageSession.manifest.layouts.find(
      item => item.btrId === target.btrId
    )
    if (!layoutRef) {
      packageSession.loadedLayouts.add(target.btrId)
      return
    }
    clearLayoutSceneGeometry(target)
    target.lineBatches.length = 0
    target.meshBatches.length = 0

    try {
      await fetchPackageLayoutChunks(target, { uploadToGpu: true })
    } catch (error) {
      // Drop partial batches and scene objects so a retry cannot duplicate geometry.
      target.lineBatches.length = 0
      target.meshBatches.length = 0
      clearLayoutSceneGeometry(target)
      throw error
    }
  }

  /**
   * Restores CPU line/mesh batches for hybrid OSNAP without disposing GPU meshes
   * that are already on screen (e.g. model space kept for paper viewports).
   */
  const ensureLayoutCpuBatches = async (
    target: AcExLayoutSnapshot
  ): Promise<void> => {
    if (layoutHasBatchGeometry(target)) return
    if (packageSession && packageLayoutHasChunks(target.btrId)) {
      target.lineBatches.length = 0
      target.meshBatches.length = 0
      try {
        await fetchPackageLayoutChunks(target, { uploadToGpu: false })
      } catch (error) {
        target.lineBatches.length = 0
        target.meshBatches.length = 0
        throw error
      }
      return
    }
    if (monolithicCompressed) {
      rehydrateMonolithicLayout(target)
    }
  }

  /**
   * Downloads OSNAP after geometry is already visible. Multiple ACEO chunks are
   * fetched in parallel; viewing does not depend on this data.
   */
  const loadPackageLayoutOsnap = async (
    target: AcExLayoutSnapshot
  ): Promise<void> => {
    if (!packageSession || !measureEnabled) {
      return
    }
    // Catalog may have been dropped after hybrid index build (CPU release).
    if (
      packageSession.loadedOsnapLayouts.has(target.btrId) &&
      target.osnap != null
    ) {
      return
    }
    packageSession.loadedOsnapLayouts.delete(target.btrId)
    await loadAcExPackageLayoutOsnap(
      packageSession.manifest,
      packageSession.manifestUrl,
      target.btrId,
      target,
      {
        fetchImpl: packageSession.fetchImpl,
        fetchConcurrency: packageChunkFetchConcurrency,
        yieldFn: async () => {
          paintPackageChunk?.()
          await accmYieldForPaint()
        },
        onChunk: progress => {
          statusEl.textContent = i18n.t('status.loadingOsnap', {
            loaded: String(progress.loadedChunks),
            total: String(progress.totalChunks)
          })
        }
      }
    )
    packageSession.loadedOsnapLayouts.add(target.btrId)
  }

  // Attach roots before any progressive fetch so appended batches are visible.
  if (layout.isModelSpace) {
    scene.add(modelRoot)
  } else {
    scene.add(paperRoot)
    if (hasPaperViewports) {
      modelScene.add(modelRoot)
    }
  }

  if (!packageSession) {
    if (modelLayout) {
      populateLayoutGeometry(
        modelLayout,
        modelLayerGroups,
        modelRoot,
        modelWideLineMaterials
      )
    }
    if (!layout.isModelSpace) {
      populateLayoutGeometry(
        layout,
        paperLayerGroups,
        paperRoot,
        paperWideLineMaterials
      )
    }
    // Drop CPU for layouts not needed for first paint (still in gzip).
    const keep = new Set<string>([layout.btrId])
    if (!layout.isModelSpace && hasPaperViewports && modelLayout) {
      keep.add(modelLayout.btrId)
    } else if (layout.isModelSpace && modelLayout) {
      keep.add(modelLayout.btrId)
    }
    releaseInactiveLayoutBatchBuffers(snapshot, keep)
  }

  const layerExtents = computeLayerExtentsMap(
    layout.lineBatches,
    layout.meshBatches
  )
  /** Per-layout layer extents kept after CPU batch release for layer-zoom. */
  const layerExtentsByLayout = new Map<
    string,
    Map<string, AcExExtents | null>
  >()
  layerExtentsByLayout.set(layout.btrId, new Map(layerExtents))
  refreshBatchExtentCache(layout)
  let layoutExtents = resolveLayoutViewExtents(
    layout,
    snapshot.meta.viewExtents ?? snapshot.meta.extents
  )

  let osnapIndex: AcExOsnapIndex | null = null
  let modelOsnapIndex: AcExOsnapIndex | null = null
  let osnapMarker: AcExOsnapMarker | null = null
  let osnapThresholdWcs = 0
  let snapCacheKey = 0
  const recomputeOsnapThresholdWcs = () => {
    if (!measureEnabled) return
    const a = screenToWcs(0, 0)
    const b = screenToWcs(osnapHitRadiusPx, 0)
    osnapThresholdWcs = Math.abs(b.x - a.x)
  }
  const bumpSnapCacheKey = () => {
    snapCacheKey++
  }

  const applyOsnapLayerVisibility = (index: AcExOsnapIndex | null) => {
    if (!index) return
    for (const layer of snapshot.layers) {
      if (!layer.visible) {
        index.setLayerHidden(layer.name, true)
      }
    }
  }

  const clearStatusBar = () => {
    statusEl.textContent = ''
    statusEl.hidden = true
  }

  const osnapIndexYield = (): Promise<void> =>
    // Prefer a macrotask over `accmYieldForPaint` / rAF: waiting a full frame
    // per slice turned million-edge hybrid indexes into multi-minute jobs.
    new Promise(resolve => {
      setTimeout(resolve, 0)
    })

  const rebuildOsnapForLoadedGeometry = async () => {
    if (!measureEnabled) return
    if (!osnapIndex) {
      osnapIndex = new AcExOsnapIndex()
      osnapMarker = new AcExOsnapMarker(root)
    }
    // Skip when CPU batches were released but GPU (and an existing index) remain.
    const canRebuildActive = layoutHasBatchGeometry(layout)
    const canRebuildModel =
      hasPaperViewports &&
      modelLayout != null &&
      layoutHasBatchGeometry(modelLayout)
    if (!canRebuildActive && !canRebuildModel) {
      return
    }
    const workEstimate =
      (canRebuildActive ? estimateOsnapRebuildWork(layout) : 0) +
      (canRebuildModel && modelLayout
        ? estimateOsnapRebuildWork(modelLayout)
        : 0)
    if (workEstimate > 8000) {
      statusEl.hidden = false
      statusEl.textContent = i18n.t('status.buildingOsnap')
      await accmYieldForPaint()
    }
    try {
      if (canRebuildActive) {
        await osnapIndex.rebuildAsync(layout, osnapIndexYield)
        applyOsnapLayerVisibility(osnapIndex)
      }
      if (canRebuildModel && modelLayout) {
        if (!modelOsnapIndex) {
          modelOsnapIndex = new AcExOsnapIndex()
        }
        await modelOsnapIndex.rebuildAsync(modelLayout, osnapIndexYield)
        applyOsnapLayerVisibility(modelOsnapIndex)
      }
      releaseSnapshotOsnapCatalogs(snapshot)
    } finally {
      clearStatusBar()
    }
  }

  // Create empty indexes now; hybrid rebuild runs after first paint so the
  // canvas is interactive while tessellated line snap is prepared.
  if (measureEnabled) {
    osnapIndex = new AcExOsnapIndex()
    osnapMarker = new AcExOsnapMarker(root)
  }

  const updateCameraFrustum = (width?: number, height?: number) => {
    const size = getCanvasSize()
    const w = width ?? size.width
    const h = height ?? size.height
    const aspect = w / h
    camera.left = -aspect * ACEX_CAMERA_FRUSTUM
    camera.right = aspect * ACEX_CAMERA_FRUSTUM
    camera.top = ACEX_CAMERA_FRUSTUM
    camera.bottom = -ACEX_CAMERA_FRUSTUM
    camera.updateProjectionMatrix()
    AcExCameraZoomUniform.value = camera.zoom
    controls.update()
  }

  const flyTo = (centerX: number, centerY: number, zoom?: number) => {
    const target = new THREE.Vector3(centerX, centerY, 0)
    camera.position.set(centerX, centerY, ACEX_CAMERA_DISTANCE)
    camera.lookAt(target)
    camera.setRotationFromEuler(new THREE.Euler(0, 0, 0))
    controls.target.copy(target)
    if (zoom != null) camera.zoom = zoom
    camera.updateProjectionMatrix()
    AcExCameraZoomUniform.value = camera.zoom
    controls.update()
    recomputeOsnapThresholdWcs()
    bumpSnapCacheKey()
  }

  const resize = () => {
    const { width, height } = getCanvasSize()
    renderer.setSize(width, height)
    wideLineResolution.set(width, height)
    for (const material of paperWideLineMaterials) {
      material.resolution.copy(wideLineResolution)
    }
    for (const material of modelWideLineMaterials) {
      material.resolution.copy(wideLineResolution)
    }
    updateCameraFrustum(width, height)
    // Keep OSNAP threshold and committed measure/markup overlays in sync when
    // the WebGL viewport / camera frustum change (window resize, tool strip, …).
    recomputeOsnapThresholdWcs()
    bumpSnapCacheKey()
  }

  const zoomToExtents = (extents: AcExExtents, margin = 0.9) => {
    const { width, height } = getCanvasSize()
    const spanX = Math.max(extents.maxX - extents.minX, FLOAT_TOL)
    const spanY = Math.max(extents.maxY - extents.minY, FLOAT_TOL)
    const centerX = (extents.minX + extents.maxX) / 2
    const centerY = (extents.minY + extents.maxY) / 2
    const zoom = Math.min(width / spanX, height / spanY) * margin
    flyTo(centerX, centerY, zoom)
    render()
  }

  const fit = () => {
    // Initial open and toolbar "Zoom extents" both use batch-derived layout bounds.
    zoomToExtents(layoutExtents)
  }

  const fitSmart = () => {
    const cached = batchExtentsByLayout.get(layout.btrId) ?? []
    const liveEntries =
      layout.lineBatches.length > 0 || layout.meshBatches.length > 0
        ? collectLayoutBatchExtentEntries(layout)
        : []
    const entries = liveEntries.length > 0 ? liveEntries : cached
    const smart = computeIntelligentExtentsFromBatchEntries(entries, {
      isLayerVisible: layerName => layerVisible.get(layerName) !== false,
      viewports: layout.viewports,
      sampleFromLayout:
        liveEntries.length > 0
          ? layout
          : undefined
    })
    zoomToExtents(smart ?? layoutExtents)
  }

  const captureViewState = () => ({
    centerX: controls.target.x,
    centerY: controls.target.y,
    zoom: camera.zoom
  })
  const originalByLayout = new Map<
    string,
    { centerX: number; centerY: number; zoom: number }
  >()
  const lastViewByLayout = new Map<
    string,
    { centerX: number; centerY: number; zoom: number }
  >()
  const restoreSavedView = () => {
    const savedExtents = layout.savedView
    if (savedExtents) {
      // Exact AutoCAD saved box — no extra 0.9 framing margin.
      zoomToExtents(savedExtents, 1)
      return
    }
    // Legacy snapshots without embedded savedView: fall back to the view
    // captured when the layout was first framed (previous "Original" behavior).
    const saved = originalByLayout.get(layout.btrId)
    if (saved) {
      flyTo(saved.centerX, saved.centerY, saved.zoom)
      render()
      return
    }
    fit()
  }

  let readyStatus = ''

  const switchDrawingBackground = () => {
    backgroundSwapped = !backgroundSwapped
    const next = backgroundSwapped
      ? isLightRgb(originalBackground)
        ? 0x000000
        : 0xffffff
      : originalBackground
    scene.background = new THREE.Color(next)
    flipNearBlackWhiteMaterials(scene)
    flipNearBlackWhiteMaterials(modelScene)
    render()
  }

  const screenToWcs = (clientX: number, clientY: number): THREE.Vector2 => {
    const rect = renderer.domElement.getBoundingClientRect()
    const ndc = new THREE.Vector3(
      ((clientX - rect.left) / rect.width) * 2 - 1,
      -(((clientY - rect.top) / rect.height) * 2 - 1),
      0
    )
    const wcs = ndc.unproject(camera)
    return new THREE.Vector2(wcs.x, wcs.y)
  }

  const wcsToScreen = (wcs: THREE.Vector2): { x: number; y: number } => {
    const rect = renderer.domElement.getBoundingClientRect()
    const ndc = new THREE.Vector3(wcs.x, wcs.y, 0).project(camera)
    return {
      x: rect.left + ((ndc.x + 1) / 2) * rect.width,
      y: rect.top + ((1 - ndc.y) / 2) * rect.height
    }
  }

  const formatLength = (value: number): string => {
    const prec = snapshot.meta.units.luprec
    return `${value.toFixed(prec)}`
  }

  const formatAngle = (valueDeg: number): string => {
    const prec = snapshot.meta.units.auprec
    return `${valueDeg.toFixed(prec)}°`
  }

  const osnapHitRadiusPx = 20
  if (measureEnabled) {
    recomputeOsnapThresholdWcs()
  }

  const resolveMeasurePoint = (clientX: number, clientY: number) => {
    const raw = screenToWcs(clientX, clientY)
    if (!osnapIndex) {
      return { point: raw, snap: null }
    }
    if (!layout.isModelSpace && modelOsnapIndex) {
      const viewport = findDrillThroughViewport(
        layout.viewports,
        raw.x,
        raw.y,
        osnapThresholdWcs
      )
      if (viewport) {
        const modelPt = paperPointToModel(viewport, raw.x, raw.y)
        const modelThresh =
          osnapThresholdWcs * viewportPaperToModelScale(viewport)
        const modelSnap = modelOsnapIndex.findSnap(
          modelPt.x,
          modelPt.y,
          modelThresh
        )
        if (modelSnap) {
          const paper = modelPointToPaper(viewport, modelSnap.x, modelSnap.y)
          return {
            point: new THREE.Vector2(paper.x, paper.y),
            snap: { ...modelSnap, x: paper.x, y: paper.y }
          }
        }
      }
    }
    const snap = osnapIndex.findSnap(raw.x, raw.y, osnapThresholdWcs)
    const point = snap ? new THREE.Vector2(snap.x, snap.y) : raw
    return { point, snap: snap ?? null }
  }

  /**
   * Hides the snap-loupe HUD and drops the last sample so the overlay pass
   * is skipped on the next frame.
   */
  const hideSnapLoupe = () => {
    loupeSample = null
    snapLoupe.hide()
  }

  /**
   * Positions the loupe HUD (and optional OSNAP glyph) around a client sample.
   * The sample is stored so the magnified overlay pass can draw on the next
   * frame.
   *
   * @param clientX - Sample X in client CSS pixels.
   * @param clientY - Sample Y in client CSS pixels.
   */
  const refreshSnapLoupeHud = (clientX: number, clientY: number) => {
    loupeSample = { clientX, clientY }
    const canvasRect = renderer.domElement.getBoundingClientRect()
    const canvasX = clientX - canvasRect.left
    const canvasY = clientY - canvasRect.top
    const { point, snap } = resolveMeasurePoint(clientX, clientY)
    if (snap) {
      const screen = wcsToScreen(point)
      snapLoupe.show(
        canvasX,
        canvasY,
        { x: screen.x - canvasRect.left, y: screen.y - canvasRect.top },
        snap.mode
      )
    } else {
      snapLoupe.show(canvasX, canvasY)
    }
  }

  let measure: AcExMeasureController | null = null
  let markup: AcExMarkupController | null = null
  const sessionHistory = createAcExSessionHistory()
  let measureSession: AcExCommandSessionUiState | null = null
  let markupSession: AcExCommandSessionUiState | null = null
  let sessionPanelVisible = false
  const sessionHost =
    document.getElementById('mlcad-canvas-host') ??
    document.getElementById('mlcad-root')
  const sessionPanel = sessionHost
    ? new AcExCommandSessionPanel(sessionHost, i18n)
    : null
  const drawerSheetsRef: {
    current: ReturnType<typeof setupAcExHtmlDrawerSheets> | null
  } = { current: null }
  const sessionDrawStyleRef: {
    current: ReturnType<typeof setupAcExSessionDrawStyle> | null
  } = { current: null }
  const shortCutToolbarRef: {
    current: ReturnType<typeof setupAcExHtmlShortCutToolbar> | null
  } = { current: null }

  const runSessionUndo = () => {
    if (measure?.canUndoLastVertex()) {
      measure.undoLastVertex()
      shortCutToolbarRef.current?.syncActionState()
      return
    }
    sessionHistory.undo()
    shortCutToolbarRef.current?.syncActionState()
  }
  const runSessionRedo = () => {
    sessionHistory.redo()
    shortCutToolbarRef.current?.syncActionState()
  }
  sessionHistory.subscribe(() => {
    shortCutToolbarRef.current?.syncActionState()
  })

  const syncHtmlShortCutSelection = () => {
    const toolbar = shortCutToolbarRef.current
    if (!toolbar) return
    acexSyncHtmlShortCutSelection({
      i18n,
      getKind: () => {
        if (measure?.isActive) return 'measure'
        if (markup?.isActive) return 'markup'
        if (measure?.hasSelection) return 'measure'
        if (markup?.hasSelection) return 'markup'
        return undefined
      },
      hasSelection: kind =>
        kind === 'measure'
          ? measure?.hasSelection === true
          : markup?.hasSelection === true,
      getStyle: kind => {
        const style =
          kind === 'measure' ? measure!.getDrawStyle() : markup!.getDrawStyle()
        return {
          color: style.color,
          fontSize: style.fontSize,
          textHeightMode: style.textHeightMode,
          textHeightWcs: style.textHeightWcs
        }
      },
      applyStyle: (kind, patch) => {
        if (kind === 'measure') measure!.setDrawStyle(patch)
        else markup!.setDrawStyle(patch)
      },
      wcsToScreen: p => wcsToScreen(new THREE.Vector2(p.x, p.y)),
      setExtensionItems: items => toolbar.setExtensionItems(items)
    })
    toolbar.syncActionState()
  }

  /** Saved side panels closed for canvas space during a draw session. */
  let chromeBeforeSession: {
    layerOpen: boolean
    reviewOpen: boolean
    measureOpen: boolean
  } | null = null
  const sessionChromeRef: {
    current: {
      hide: () => void
      restore: () => void
    }
  } = {
    current: {
      hide: () => undefined,
      restore: () => undefined
    }
  }
  const applySessionUi = () => {
    const state = measureSession ?? markupSession
    const nowVisible = state != null
    sessionPanel?.setState(state)
    sessionPanel?.setAccessory(
      state
        ? (sessionDrawStyleRef.current?.createSessionAccessory() ?? null)
        : null
    )
    drawerSheetsRef.current?.syncInset()
    if (nowVisible && !sessionPanelVisible) {
      sessionChromeRef.current.hide()
      void acexMaybeShowTouchPointTutorial(i18n)
    } else if (!nowVisible && sessionPanelVisible) {
      sessionChromeRef.current.restore()
    }
    sessionPanelVisible = nowVisible
    shortCutToolbarRef.current?.syncActionState()
  }
  sessionPanel?.setHandlers({
    onConfirm: () => {
      if (markup?.confirmSession(sessionPanel.getStringValue())) return
      measure?.confirmSession()
    },
    onCancel: () => {
      if (measure?.isActive) measure.cancelSession()
      else markup?.cancelSession()
    },
    onChip: id => {
      if (id === 'undo') runSessionUndo()
    }
  })
  const measureSettingsRef: {
    current: ReturnType<typeof setupAcExHtmlMeasureSettings> | null
  } = { current: null }
  const mainToolbarRef: {
    current: AcExHtmlMainToolbarController | null
  } = { current: null }
  const navToolsRef: {
    current: ReturnType<typeof setupAcExHtmlNavTools> | null
  } = { current: null }
  let expiryMonitor: ReturnType<typeof setupAcExHtmlExpiryMonitor> | null = null

  const isToolActive = () =>
    measure?.isActive === true || markup?.isActive === true

  /** True while the snap loupe is open; one-finger pan stays off until it closes. */
  let preciseCaptureActive = false

  /**
   * Wires OrbitControls pan for idle nav vs drawing tools.
   *
   * Drawing tools keep mouse left-click free for picks, but one-finger touch
   * pan stays on until precise capture (loupe) so the canvas can still be
   * dragged before a long-press — matches cad-simple-viewer.
   */
  const setLeftPanForTools = () => {
    if (isToolActive()) {
      navToolsRef.current?.cancelZoomWindow()
    }
    const idlePan = navToolsRef.current?.isPanEnabled() ?? !isToolActive()
    const drawing = isToolActive()
    const navMode = navToolsRef.current?.getMode()
    const idleTouchPan =
      navMode != null && acexIdlePointerStrategy().enablesIdleTouchPan(navMode)
    setOrbitPanButtons(controls, {
      leftMousePan: idlePan,
      oneFingerPan:
        (idlePan || drawing || idleTouchPan) && !preciseCaptureActive
    })
    controls.enabled = !preciseCaptureActive
    sessionDrawStyleRef.current?.refresh()
    navToolsRef.current?.syncButtons()
  }

  /**
   * Disables navigation while the snap loupe tracks a long-press, then
   * restores idle / drawing pan rules.
   *
   * @param active - True when precise capture (loupe) is visible.
   */
  const setPreciseCaptureActive = (active: boolean) => {
    preciseCaptureActive = active
    setLeftPanForTools()
  }

  acexBindMobileSnapLoupe({
    refresh: refreshSnapLoupeHud,
    hide: hideSnapLoupe,
    setPreciseCaptureActive
  })

  const paperWorldToScreen = (
    x: number,
    y: number,
    width: number,
    height: number
  ) => {
    const ndc = new THREE.Vector3(x, y, 0).project(camera)
    return {
      x: ((ndc.x + 1) / 2) * width,
      y: ((-ndc.y + 1) / 2) * height
    }
  }

  /**
   * Fits an orthographic camera so `extents` fills a CSS rectangle of
   * `vpW` × `vpH`, matching {@link computeViewportCamera}.
   *
   * @param target - Camera to update.
   * @param extents - World box to show.
   * @param vpW - Target CSS width in pixels.
   * @param vpH - Target CSS height in pixels.
   * @param twist - Optional DVIEW twist in radians.
   */
  const applyOrthoFit = (
    target: THREE.OrthographicCamera,
    extents: AcExExtents,
    vpW: number,
    vpH: number,
    twist = 0
  ) => {
    const fitted = computeViewportCamera(extents, vpW, vpH)
    target.left = -fitted.aspect * fitted.frustum
    target.right = fitted.aspect * fitted.frustum
    target.top = fitted.frustum
    target.bottom = -fitted.frustum
    target.position.set(fitted.centerX, fitted.centerY, ACEX_CAMERA_DISTANCE)
    target.lookAt(fitted.centerX, fitted.centerY, 0)
    target.up.set(-Math.sin(twist), Math.cos(twist), 0)
    target.setRotationFromEuler(new THREE.Euler(0, 0, twist))
    target.zoom = fitted.zoom
    target.updateProjectionMatrix()
    AcExCameraZoomUniform.value = fitted.zoom
  }

  const renderPaperViewports = () => {
    const viewports = layout.viewports
    if (
      layout.isModelSpace ||
      !viewports?.length ||
      modelRoot.children.length === 0
    ) {
      return
    }
    const { width, height } = getCanvasSize()
    if (width <= 0 || height <= 0) return

    const autoClear = renderer.autoClear
    renderer.autoClear = false
    renderer.getViewport(savedViewportBox)
    renderer.clearDepth()

    const canvasRect = { x: 0, y: 0, width, height }
    for (const viewport of viewports) {
      const pMin = paperWorldToScreen(
        viewport.paper.minX,
        viewport.paper.minY,
        width,
        height
      )
      const pMax = paperWorldToScreen(
        viewport.paper.maxX,
        viewport.paper.maxY,
        width,
        height
      )
      const minX = Math.min(pMin.x, pMax.x)
      const maxX = Math.max(pMin.x, pMax.x)
      const minY = Math.min(pMin.y, pMax.y)
      const maxY = Math.max(pMin.y, pMax.y)
      const pass = computeOnscreenPaperViewportPass(
        viewport,
        {
          x: minX,
          y: minY,
          width: maxX - minX,
          height: maxY - minY
        },
        canvasRect
      )
      if (!pass) continue

      const gl = acexCssTopLeftRectToGl(pass.hit, height)
      renderer.setViewport(gl.x, gl.y, gl.width, gl.height)
      renderer.setScissor(gl.x, gl.y, gl.width, gl.height)
      renderer.setScissorTest(true)
      applyOrthoFit(
        viewportCamera,
        pass.model,
        pass.hit.width,
        pass.hit.height,
        viewport.twist ?? 0
      )
      renderer.render(modelScene, viewportCamera)
      renderer.setScissorTest(false)
    }

    renderer.setViewport(
      savedViewportBox.x,
      savedViewportBox.y,
      savedViewportBox.z,
      savedViewportBox.w
    )
    renderer.autoClear = autoClear
    AcExCameraZoomUniform.value = camera.zoom
  }

  /**
   * Draws the magnified snap loupe into a screen-fixed scissor after the main
   * layout and paper viewports. Nested paper-space viewports that intersect
   * the loupe are scissor-clipped so model content stays visible inside it.
   */
  const renderSnapLoupe = () => {
    if (!loupeSample || !snapLoupe.isVisible) return
    const { width, height } = getCanvasSize()
    if (width <= 0 || height <= 0) return
    const half = ACEX_SNAP_LOUPE_SIZE_PX / ACEX_SNAP_LOUPE_ZOOM / 2
    const p1 = screenToWcs(
      loupeSample.clientX - half,
      loupeSample.clientY - half
    )
    const p2 = screenToWcs(
      loupeSample.clientX + half,
      loupeSample.clientY + half
    )
    const viewBox: AcExExtents = {
      minX: Math.min(p1.x, p2.x),
      minY: Math.min(p1.y, p2.y),
      maxX: Math.max(p1.x, p2.x),
      maxY: Math.max(p1.y, p2.y)
    }
    const loupeRect = {
      x: ACEX_SNAP_LOUPE_INSET_PX,
      y: snapLoupe.topInsetPx,
      width: ACEX_SNAP_LOUPE_SIZE_PX,
      height: ACEX_SNAP_LOUPE_SIZE_PX
    }
    const gl = acexCssTopLeftRectToGl(loupeRect, height)
    const autoClear = renderer.autoClear
    renderer.autoClear = false
    renderer.getViewport(savedViewportBox)
    renderer.setScissor(gl.x, gl.y, gl.width, gl.height)
    renderer.setScissorTest(true)
    renderer.setViewport(gl.x, gl.y, gl.width, gl.height)
    renderer.clear()
    applyOrthoFit(loupeCamera, viewBox, loupeRect.width, loupeRect.height)
    renderer.render(scene, loupeCamera)

    if (
      !layout.isModelSpace &&
      layout.viewports?.length &&
      modelRoot.children.length > 0
    ) {
      for (const viewport of layout.viewports) {
        const magRect = acexWcsBoxToCssRect(viewport.paper, viewBox, loupeRect)
        const pass = computeOnscreenPaperViewportPass(
          viewport,
          magRect,
          loupeRect
        )
        if (!pass) continue
        const nestedGl = acexCssTopLeftRectToGl(pass.hit, height)
        renderer.setScissor(
          nestedGl.x,
          nestedGl.y,
          nestedGl.width,
          nestedGl.height
        )
        renderer.setViewport(
          nestedGl.x,
          nestedGl.y,
          nestedGl.width,
          nestedGl.height
        )
        renderer.clearDepth()
        applyOrthoFit(
          loupeCamera,
          pass.model,
          pass.hit.width,
          pass.hit.height,
          viewport.twist ?? 0
        )
        renderer.render(modelScene, loupeCamera)
      }
    }

    renderer.setScissorTest(false)
    renderer.setViewport(
      savedViewportBox.x,
      savedViewportBox.y,
      savedViewportBox.z,
      savedViewportBox.w
    )
    renderer.autoClear = autoClear
    AcExCameraZoomUniform.value = camera.zoom
  }

  const render = () => {
    measure?.syncOverlays()
    markup?.syncOverlays()
    renderer.render(scene, camera)
    renderPaperViewports()
    renderSnapLoupe()
  }

  paintPackageChunk = () => {
    const next = computeLayerExtentsMap(layout.lineBatches, layout.meshBatches)
    layerExtents.clear()
    for (const [name, extents] of next) {
      layerExtents.set(name, extents)
    }
    layerExtentsByLayout.set(layout.btrId, new Map(layerExtents))
    refreshBatchExtentCache(layout)
    layoutExtents = resolveLayoutViewExtents(
      layout,
      snapshot.meta.viewExtents ?? snapshot.meta.extents
    )
    layerPanel?.syncLayerZoomButtons()
    render()
  }
  requestViewerTextureRepaint = () => {
    render()
  }

  if (measureEnabled) {
    measure = new AcExMeasureController({
      root,
      i18n,
      statusEl,
      getReadyStatus: () => readyStatus,
      drawingName: snapshot.meta.title,
      onOsnapMarker: (snap, screen) => {
        if (snap && screen) {
          osnapMarker?.show(screen.x, screen.y, snap.mode)
        } else {
          osnapMarker?.hide()
        }
      },
      getTrackingOptions: () =>
        measureSettingsRef.current?.getTrackingOptions() ?? null,
      onActiveChange: () => {
        setLeftPanForTools()
        markup?.setPeerToolActive(measure?.isActive === true)
      },
      onSessionUi: state => {
        measureSession = state
        applySessionUi()
      },
      onStyleChange: () => {
        sessionDrawStyleRef.current?.refresh()
        syncHtmlShortCutSelection()
      },
      getActiveLayoutId: () => layout.btrId,
      sessionHistory,
      view: {
        screenToWcs,
        wcsToScreen,
        render,
        getSnapCacheKey: () => snapCacheKey,
        getCameraZoom: () => camera.zoom,
        resolvePoint: resolveMeasurePoint,
        findCircleOrArcNear: (x, y) => {
          if (!layout.isModelSpace && modelOsnapIndex) {
            const viewport = findDrillThroughViewport(
              layout.viewports,
              x,
              y,
              osnapThresholdWcs
            )
            if (viewport) {
              const modelPt = paperPointToModel(viewport, x, y)
              const modelScale = viewportPaperToModelScale(viewport)
              const hit = modelOsnapIndex.findCircleOrArcNear(
                modelPt.x,
                modelPt.y,
                osnapThresholdWcs * modelScale
              )
              if (hit) {
                const onCurve = modelPointToPaper(viewport, hit.x, hit.y)
                const center = modelPointToPaper(viewport, hit.cx, hit.cy)
                const result: AcExCircleOrArcNearHit = {
                  cx: center.x,
                  cy: center.y,
                  r: modelScale === 0 ? hit.r : hit.r / modelScale,
                  x: onCurve.x,
                  y: onCurve.y
                }
                if (hit.arc) {
                  const start = modelPointToPaper(
                    viewport,
                    hit.arc.start.x,
                    hit.arc.start.y
                  )
                  const end = modelPointToPaper(
                    viewport,
                    hit.arc.end.x,
                    hit.arc.end.y
                  )
                  const through = modelPointToPaper(
                    viewport,
                    hit.arc.through.x,
                    hit.arc.through.y
                  )
                  result.arc = { start, end, through }
                }
                return result
              }
            }
          }
          if (!osnapIndex) return null
          return osnapIndex.findCircleOrArcNear(x, y, osnapThresholdWcs) ?? null
        },
        formatLength,
        formatAngle,
        zoomToExtents
      }
    })

    markup = new AcExMarkupController({
      root,
      i18n,
      statusEl,
      getReadyStatus: () => readyStatus,
      drawingName: snapshot.meta.title,
      onOsnapMarker: (snap, screen) => {
        if (snap && screen) {
          osnapMarker?.show(screen.x, screen.y, snap.mode)
        } else {
          osnapMarker?.hide()
        }
      },
      onBeforeActivate: () => {
        measure?.cancelMode()
      },
      onActiveChange: () => {
        setLeftPanForTools()
        measure?.setPeerToolActive(markup?.isActive === true)
      },
      onSessionUi: state => {
        markupSession = state
        applySessionUi()
      },
      onStyleChange: () => {
        sessionDrawStyleRef.current?.refresh()
        syncHtmlShortCutSelection()
      },
      getTrackingOptions: () =>
        measureSettingsRef.current?.getTrackingOptions() ?? null,
      getActiveLayoutId: () => layout.btrId,
      sessionHistory,
      view: {
        screenToWcs,
        wcsToScreen,
        render,
        getSnapCacheKey: () => snapCacheKey,
        getCameraZoom: () => camera.zoom,
        resolvePoint: resolveMeasurePoint,
        zoomToExtents
      }
    })

    measureSettingsRef.current = setupAcExHtmlMeasureSettings({
      i18n,
      measure,
      angbase: snapshot.meta.units.angbase,
      angdir: snapshot.meta.units.angdir
    })

    sessionDrawStyleRef.current = setupAcExSessionDrawStyle({
      i18n,
      getKind: () => {
        if (measure?.isActive) return 'measure'
        if (markup?.isActive) return 'markup'
        if (measure && measure.hasSelection) return 'measure'
        if (markup?.hasSelection) return 'markup'
        return undefined
      },
      getStyle: kind => {
        const style =
          kind === 'measure' ? measure!.getDrawStyle() : markup!.getDrawStyle()
        return {
          color: style.color,
          fontSize: style.fontSize,
          textHeightMode: style.textHeightMode,
          textHeightWcs: style.textHeightWcs
        }
      },
      applyStyle: (kind, patch) => {
        if (kind === 'measure') {
          measure!.setDrawStyle(patch)
        } else {
          markup!.setDrawStyle(patch)
        }
      },
      wcsToScreen: p => wcsToScreen(new THREE.Vector2(p.x, p.y))
    })
    applySessionUi()
    syncHtmlShortCutSelection()
  }

  if (!shortCutToolbarRef.current) {
    shortCutToolbarRef.current = setupAcExHtmlShortCutToolbar({
      i18n,
      container: root,
      statusEl,
      actions: {
        undo: () => runSessionUndo(),
        redo: () => runSessionRedo(),
        erase: () => {
          if (markup?.hasSelection) {
            markup.deleteSelected()
            return
          }
          if (measure?.hasSelection) {
            measure.handleSelectionKeyDown('Delete')
          }
        }
      },
      getActionState: () => ({
        undo: measure?.canUndoLastVertex() === true || sessionHistory.canUndo(),
        redo: sessionHistory.canRedo(),
        erase: markup?.hasSelection === true || measure?.hasSelection === true
      })
    })
    syncHtmlShortCutSelection()
    shortCutToolbarRef.current.syncActionState()
  }

  const closeLayerDrawer = () => {
    const layerDrawer = document.getElementById('mlcad-layer-drawer')
    const layersBtn = document.getElementById('mlcad-layers-btn')
    if (layerDrawer) layerDrawer.hidden = true
    layersBtn?.classList.remove('active')
    layersBtn?.setAttribute('aria-expanded', 'false')
  }

  let reviewPanel: ReturnType<typeof setupAcExHtmlReviewPanel> = null
  let measurePanel: ReturnType<typeof setupAcExHtmlMeasurePanel> = null
  let layerPanel: ReturnType<typeof setupLayerPanel> | null = null

  const drawerSheets = setupAcExHtmlDrawerSheets({
    closeStrips: () => {
      mainToolbarRef.current?.dismissOpenChildren()
    }
  })
  drawerSheetsRef.current = drawerSheets

  const dismissToolbarChrome = () => {
    mainToolbarRef.current?.dismissOpenChildren()
    measureSettingsRef.current?.close()
  }

  const onToolbarChromeChange = () => {
    // Layout rebuild may replace toolbar buttons; re-apply nav pressed state.
    navToolsRef.current?.syncButtons()
    drawerSheets.syncInset()
    resize()
    recomputeOsnapThresholdWcs()
    bumpSnapCacheKey()
    render()
  }

  const switchLayout = (btrId: string) => {
    void switchLayoutAsync(btrId)
  }

  const toolbarHost = document.getElementById('mlcad-toolbar')
  if (toolbarHost) {
    mainToolbarRef.current = setupAcExHtmlMainToolbar({
      host: toolbarHost,
      themeHost: root,
      i18n,
      viewerMode,
      exportLayouts: snapshot.meta.exportLayouts !== false,
      layouts: snapshot.layouts.map(item => ({
        btrId: item.btrId,
        name: item.name
      })),
      getActiveLayoutBtrId: () => layout.btrId,
      handlers: {
        setNavMode: mode => {
          navToolsRef.current?.setMode(mode)
        },
        fit: () => {
          navToolsRef.current?.cancelZoomWindow()
          measure?.cancelMode()
          markup?.cancelMode()
          fit()
        },
        fitSmart: () => {
          navToolsRef.current?.cancelZoomWindow()
          measure?.cancelMode()
          markup?.cancelMode()
          fitSmart()
        },
        restoreSavedView: () => {
          navToolsRef.current?.cancelZoomWindow()
          measure?.cancelMode()
          markup?.cancelMode()
          restoreSavedView()
        },
        cancelZoomWindow: () => navToolsRef.current?.cancelZoomWindow(),
        toggleLayerDrawer: () => {
          if (layerPanel) {
            layerPanel.setOpen(!layerPanel.isOpen())
            return
          }
          const drawer = document.getElementById('mlcad-layer-drawer')
          if (!drawer) return
          const open = drawer.hidden
          if (open) {
            reviewPanel?.close()
            measurePanel?.close()
            if (acexHtmlIsPhoneLayout()) drawerSheets.preparePhoneOpen(drawer)
          }
          drawer.hidden = !open
          const layersBtn = document.getElementById('mlcad-layers-btn')
          layersBtn?.classList.toggle('active', open)
          layersBtn?.setAttribute('aria-expanded', String(open))
        },
        switchLayout,
        setMeasureMode: mode => {
          markup?.cancelMode()
          measure?.setMode(mode)
        },
        toggleMeasurePanel: () => {
          measure?.cancelMode()
          markup?.cancelMode()
          const drawer = document.getElementById('mlcad-measure-drawer')
          measurePanel?.setOpen(Boolean(drawer?.hidden))
        },
        toggleMeasureVisibility: () => {
          measure?.toggleVisible()
        },
        isMeasureVisible: () => measure?.visible !== false,
        clearMeasurements: () => {
          measure?.clearAll()
        },
        importMeasurements: () => {
          measure?.importSidecar()
        },
        exportMeasurements: () => {
          measure?.exportSidecar()
        },
        setMarkupMode: mode => {
          measure?.cancelMode()
          markup?.setMode(mode)
        },
        toggleMarkupPanel: () => {
          measure?.cancelMode()
          markup?.cancelMode()
          const drawer = document.getElementById('mlcad-review-drawer')
          reviewPanel?.setOpen(Boolean(drawer?.hidden))
        },
        toggleMarkupVisibility: () => {
          markup?.toggleVisible()
        },
        isMarkupVisible: () => markup?.visible !== false,
        clearMarkups: () => {
          markup?.clearAll()
        },
        importMarkups: () => {
          markup?.importSidecar()
        },
        exportMarkups: () => {
          markup?.exportSidecar()
        },
        applyTheme: theme => {
          applyHtmlTheme(theme)
          i18n.applyToDocument()
          mainToolbarRef.current?.refresh()
        },
        getTheme: () =>
          (document.documentElement.getAttribute(
            'data-mlcad-theme'
          ) as AcExHtmlTheme | null) ?? 'dark',
        switchBackground: () => {
          switchDrawingBackground()
        },
        toggleOrtho: () => {
          measureSettingsRef.current?.toggleOrtho()
          mainToolbarRef.current?.refresh()
        },
        isOrtho: () => measureSettingsRef.current?.isOrtho() === true,
        togglePolarPanel: () => {
          const open = measureSettingsRef.current?.togglePolarPanel() ?? false
          mainToolbarRef.current?.refresh()
          return open
        },
        isPolarPanelOpen: () =>
          measureSettingsRef.current?.isPolarPanelOpen() === true,
        onChromeChange: onToolbarChromeChange,
        onExclusiveOpen: () => {
          if (!acexHtmlIsPhoneLayout()) return
          closeLayerDrawer()
          reviewPanel?.close()
          measurePanel?.close()
        },
        onCollapse: () => {
          dismissToolbarChrome()
          closeLayerDrawer()
          reviewPanel?.close()
          measurePanel?.close()
        }
      }
    })
  }

  const markGeometryReady = (ready: boolean) => {
    mainToolbarRef.current?.setGeometryReady(ready)
  }
  const markOsnapReady = (ready: boolean) => {
    // View-only HTML has no measure/annotation buttons; treat OSNAP as ready
    // whenever geometry is ready so readiness stays consistent.
    if (!measureEnabled) {
      mainToolbarRef.current?.setOsnapReady(true)
      return
    }
    mainToolbarRef.current?.setOsnapReady(ready)
  }

  layerPanel = setupLayerPanel({
    snapshot,
    layerVisible,
    layerGroupMaps: [paperLayerGroups, modelLayerGroups],
    layerExtents,
    statusEl,
    i18n,
    render,
    zoomToExtents,
    cancelZoomWindow: () => navToolsRef.current?.cancelZoomWindow(),
    osnapIndexes: [osnapIndex, modelOsnapIndex].filter(
      (index): index is AcExOsnapIndex => index != null
    ),
    sortedLayerNames: [
      ...new Set([
        ...snapshot.layers.map(layer => layer.name),
        ...paperLayerGroups.keys(),
        ...modelLayerGroups.keys()
      ])
    ].sort((a, b) => a.localeCompare(b, undefined, { numeric: true })),
    closeOtherDrawers: () => {
      reviewPanel?.close()
      measurePanel?.close()
    },
    onPhoneOpen: drawer => drawerSheets.preparePhoneOpen(drawer)
  })

  reviewPanel = setupAcExHtmlReviewPanel({
    i18n,
    getMarkup: () => markup,
    closeOtherDrawers: () => {
      closeLayerDrawer()
      measurePanel?.close()
    },
    onPhoneOpen: drawer => drawerSheets.preparePhoneOpen(drawer)
  })

  measurePanel = setupAcExHtmlMeasurePanel({
    i18n,
    getMeasure: () => measure,
    closeOtherDrawers: () => {
      closeLayerDrawer()
      reviewPanel?.close()
    },
    onPhoneOpen: drawer => drawerSheets.preparePhoneOpen(drawer)
  })

  // While measure/markup is active, hide the toolbar sidebar and any open
  // results / layer drawers so they do not compete with session chrome.
  // Do not resize the canvas — session UI floats over the existing viewport.
  sessionChromeRef.current = {
    hide: () => {
      if (chromeBeforeSession) return
      const reviewDrawer = document.getElementById('mlcad-review-drawer')
      const measureDrawer = document.getElementById('mlcad-measure-drawer')
      chromeBeforeSession = {
        layerOpen: layerPanel?.isOpen() === true,
        reviewOpen: reviewDrawer != null && !reviewDrawer.hidden,
        measureOpen: measureDrawer != null && !measureDrawer.hidden
      }
      dismissToolbarChrome()
      if (chromeBeforeSession.layerOpen) layerPanel?.close()
      if (chromeBeforeSession.reviewOpen) reviewPanel?.close()
      if (chromeBeforeSession.measureOpen) measurePanel?.close()
      render()
    },
    restore: () => {
      const saved = chromeBeforeSession
      chromeBeforeSession = null
      if (saved?.layerOpen) layerPanel?.setOpen(true)
      if (saved?.reviewOpen) reviewPanel?.setOpen(true)
      if (saved?.measureOpen) measurePanel?.setOpen(true)
      render()
    }
  }

  const remountLayoutRoots = (
    target: AcExLayoutSnapshot,
    rebuildPaper: boolean
  ) => {
    layout = target
    if (target.isModelSpace) {
      scene.add(modelRoot)
    } else {
      scene.add(paperRoot)
      if (rebuildPaper) {
        populateLayoutGeometry(
          target,
          paperLayerGroups,
          paperRoot,
          paperWideLineMaterials
        )
        if (backgroundSwapped) {
          flipNearBlackWhiteMaterials(paperRoot)
        }
      }
      if (hasPaperViewports) {
        modelScene.add(modelRoot)
      }
    }
  }

  const ensureLayoutGeometrySource = async (
    target: AcExLayoutSnapshot
  ): Promise<'package' | 'monolithic' | 'resident'> => {
    if (layoutGpuResident(target) || layoutHasBatchGeometry(target)) {
      return 'resident'
    }
    if (packageSession && packageLayoutHasChunks(target.btrId)) {
      await loadPackageLayoutGeometry(target)
      return 'package'
    }
    if (monolithicCompressed) {
      rehydrateMonolithicLayout(target)
      return 'monolithic'
    }
    return 'resident'
  }

  const switchLayoutAsync = async (btrId: string) => {
    if (btrId === layout.btrId) return
    const next = snapshot.layouts.find(item => item.btrId === btrId)
    if (!next) return

    const previousLayout = layout
    const previousWasPaper = !previousLayout.isModelSpace

    lastViewByLayout.set(layout.btrId, captureViewState())
    navToolsRef.current?.cancelZoomWindow()
    measure?.cancelMode()
    markup?.cancelMode()
    osnapMarker?.hide()

    if (!layout.isModelSpace) {
      disposePaperGeometry()
    }
    paperRoot.removeFromParent()
    modelRoot.removeFromParent()

    layout = next

    // Mount roots before any progressive fetch so each chunk can paint.
    // (First open already attaches roots before package load; switch used to
    // defer scene.add until after all chunks finished.)
    if (layout.isModelSpace) {
      scene.add(modelRoot)
    } else {
      scene.add(paperRoot)
      if (hasPaperViewports) {
        modelScene.add(modelRoot)
      }
    }

    // Frame the target layout BEFORE geometry / OSNAP reload. Otherwise the
    // camera stays on the previous paper/model view and progressive chunks
    // paint off-screen until load finishes.
    layoutExtents = resolveLayoutViewExtents(
      layout,
      snapshot.meta.viewExtents ?? snapshot.meta.extents
    )
    const cachedLayerExtents = layerExtentsByLayout.get(btrId)
    if (cachedLayerExtents) {
      layerExtents.clear()
      for (const [name, extents] of cachedLayerExtents) {
        layerExtents.set(name, extents)
      }
    } else {
      layerExtents.clear()
    }
    const savedBeforeLoad = lastViewByLayout.get(btrId)
    if (savedBeforeLoad) {
      flyTo(
        savedBeforeLoad.centerX,
        savedBeforeLoad.centerY,
        savedBeforeLoad.zoom
      )
    } else {
      fit()
      originalByLayout.set(btrId, captureViewState())
    }
    layerPanel?.syncLayerZoomButtons()
    render()

    let geometrySource: 'package' | 'monolithic' | 'resident' = 'resident'
    try {
      const needsActiveLoad = layoutNeedsGeometrySource(layout)
      const needsModelLoad =
        !layout.isModelSpace &&
        hasPaperViewports &&
        modelLayout != null &&
        layoutNeedsGeometrySource(modelLayout)
      if (needsActiveLoad || needsModelLoad) {
        markGeometryReady(false)
        if (measureEnabled) markOsnapReady(false)
        geometrySource = await ensureLayoutGeometrySource(layout)
        if (needsModelLoad && modelLayout) {
          await ensureLayoutGeometrySource(modelLayout)
        }
        markGeometryReady(true)
      }
    } catch (error) {
      statusEl.textContent = i18n.t('status.loadFailed', {
        error: String(error)
      })
      if (!next.isModelSpace) {
        disposePaperGeometry()
      }
      paperRoot.removeFromParent()
      modelRoot.removeFromParent()
      try {
        await ensureLayoutGeometrySource(previousLayout)
      } catch {
        // Fall through to remount whatever is left.
      }
      remountLayoutRoots(
        previousLayout,
        previousWasPaper &&
          (layoutHasBatchGeometry(previousLayout) ||
            layoutGpuResident(previousLayout))
      )
      const restored = lastViewByLayout.get(previousLayout.btrId)
      if (restored) {
        flyTo(restored.centerX, restored.centerY, restored.zoom)
      } else {
        fit()
      }
      const cachedPrevExtents = layerExtentsByLayout.get(previousLayout.btrId)
      if (cachedPrevExtents) {
        layerExtents.clear()
        for (const [name, extents] of cachedPrevExtents) {
          layerExtents.set(name, extents)
        }
      } else if (layoutHasBatchGeometry(previousLayout)) {
        const restoredExtents = computeLayerExtentsMap(
          previousLayout.lineBatches,
          previousLayout.meshBatches
        )
        layerExtents.clear()
        for (const [name, extents] of restoredExtents) {
          layerExtents.set(name, extents)
        }
      }
      layoutExtents = resolveLayoutViewExtents(previousLayout)
      layerPanel?.syncLayerZoomButtons()
      measure?.syncLayoutVisibility()
      markup?.syncLayoutVisibility()
      markGeometryReady(true)
      // Unlock measure even if snap rebuild is skipped; avoid leaving chrome gated.
      markOsnapReady(true)
      mainToolbarRef.current?.refresh()
      recomputeOsnapThresholdWcs()
      bumpSnapCacheKey()
      render()
      return
    }

    if (!layout.isModelSpace) {
      // Package load already uploaded batches; monolithic rehydrate needs populate.
      if (
        geometrySource !== 'package' &&
        paperLayerGroups.size === 0 &&
        layoutHasBatchGeometry(layout)
      ) {
        populateLayoutGeometry(
          layout,
          paperLayerGroups,
          paperRoot,
          paperWideLineMaterials
        )
      }
      if (backgroundSwapped) {
        flipNearBlackWhiteMaterials(paperRoot)
      }
    } else if (
      geometrySource === 'monolithic' &&
      modelLayerGroups.size === 0 &&
      layoutHasBatchGeometry(layout)
    ) {
      // Model root is already on the scene; rebuild GPU from rehydrated batches.
      populateLayoutGeometry(
        layout,
        modelLayerGroups,
        modelRoot,
        modelWideLineMaterials
      )
    }

    // Free the previous package layout only after the next one is on screen.
    if (packageSession) {
      if (!previousLayout.isModelSpace) {
        unloadPackageLayout(previousLayout, { disposeGpu: false })
      } else if (!hasPaperViewports && !layout.isModelSpace) {
        unloadPackageLayout(previousLayout, { disposeGpu: true })
      }
    } else if (!previousLayout.isModelSpace) {
      releaseLayoutBatchBuffers(previousLayout)
      previousLayout.osnap = undefined
    } else if (!hasPaperViewports && !layout.isModelSpace) {
      clearLayoutSceneGeometry(previousLayout)
      releaseLayoutBatchBuffers(previousLayout)
      previousLayout.osnap = undefined
    }

    // Hybrid OSNAP indexes lineBatches; restore CPU when GPU stayed resident
    // (e.g. model space kept under paper viewports) after releaseCpuAfterGpuUpload.
    if (measureEnabled) {
      try {
        await ensureLayoutCpuBatches(layout)
        if (!layout.isModelSpace && hasPaperViewports && modelLayout) {
          await ensureLayoutCpuBatches(modelLayout)
        }
      } catch (error) {
        statusEl.textContent = i18n.t('status.loadFailed', {
          error: String(error)
        })
      }
    }

    layoutExtents = resolveLayoutViewExtents(
      layout,
      snapshot.meta.viewExtents ?? snapshot.meta.extents
    )
    if (layoutHasBatchGeometry(layout)) {
      const nextLayerExtents = computeLayerExtentsMap(
        layout.lineBatches,
        layout.meshBatches
      )
      layerExtents.clear()
      for (const [name, extents] of nextLayerExtents) {
        layerExtents.set(name, extents)
      }
      layerExtentsByLayout.set(layout.btrId, new Map(layerExtents))
    }
    // Always attempt a refresh (same as paintPackageChunk). When CPU batches
    // were already released, collect yields nothing and the helper keeps the
    // pre-release cache so fitSmart still works.
    refreshBatchExtentCache(layout)
    layerPanel?.syncLayerZoomButtons()

    if (measureEnabled) {
      markOsnapReady(false)
    }

    if (osnapIndex && layoutHasBatchGeometry(layout)) {
      // Defer rebuild when ACEO sidecars are still pending — tessellating all
      // line/mesh batches first would freeze the UI and delay Network fetches.
      const layoutRef = packageSession?.manifest.layouts.find(
        item => item.btrId === layout.btrId
      )
      const pendingOsnap =
        packageSession != null &&
        measureEnabled &&
        (layout.osnap == null ||
          !packageSession.loadedOsnapLayouts.has(layout.btrId)) &&
        (layoutRef?.osnapChunkIds?.length ?? 0) > 0
      if (!pendingOsnap) {
        const workEstimate = estimateOsnapRebuildWork(layout)
        if (workEstimate > 8000) {
          statusEl.textContent = i18n.t('status.buildingOsnap')
          await accmYieldForPaint()
        }
        try {
          await osnapIndex.rebuildAsync(layout, osnapIndexYield)
          for (const [name, visible] of layerVisible) {
            osnapIndex.setLayerHidden(name, visible === false)
          }
          clearStatusBar()
        } catch (error) {
          statusEl.textContent = i18n.t('status.loadFailed', {
            error: String(error)
          })
        }
      }
    }

    // Camera was already restored before progressive load; keep the same view.

    measure?.syncLayoutVisibility()
    markup?.syncLayoutVisibility()
    mainToolbarRef.current?.refresh()
    recomputeOsnapThresholdWcs()
    bumpSnapCacheKey()
    render()

    // OSNAP last: geometry is already on screen.
    if (packageSession && measureEnabled) {
      try {
        await loadPackageLayoutOsnap(layout)
        if (!layout.isModelSpace && hasPaperViewports && modelLayout) {
          await loadPackageLayoutOsnap(modelLayout)
        }
        await rebuildOsnapForLoadedGeometry()
        bumpSnapCacheKey()
        render()
        measure?.refreshIdleStatus()
        markOsnapReady(true)
      } catch (error) {
        statusEl.textContent = i18n.t('status.loadFailed', {
          error: String(error)
        })
        markOsnapReady(true)
      }
    } else if (measureEnabled) {
      try {
        await rebuildOsnapForLoadedGeometry()
        markOsnapReady(true)
      } catch {
        markOsnapReady(true)
      }
    }

    // Drop CPU again now that the new layout is on GPU (+ snap index ready).
    releaseCpuAfterGpuUpload()
  }

  controls.addEventListener('change', () => {
    AcExCameraZoomUniform.value = camera.zoom
    recomputeOsnapThresholdWcs()
    bumpSnapCacheKey()
    render()
  })

  const navTools = setupAcExHtmlNavTools({
    root,
    i18n,
    screenToWcs,
    zoomToExtents,
    exitDrawingTools: () => {
      measure?.cancelMode()
      markup?.cancelMode()
    },
    isDrawingActive: isToolActive,
    onModeChange: () => setLeftPanForTools(),
    getReadyStatus: () => readyStatus,
    statusEl
  })
  navToolsRef.current = navTools
  setLeftPanForTools()

  setupToolPointerInput({
    domElement: renderer.domElement,
    root,
    screenToWcs,
    getMeasure: () => measure,
    getMarkup: () => markup,
    getNavTools: () => navToolsRef.current,
    render
  })

  setupPanCursorFeedback(
    renderer.domElement,
    () => navToolsRef.current?.isPanEnabled() ?? !isToolActive()
  )

  renderer.domElement.addEventListener('contextmenu', event => {
    event.preventDefault()
  })

  i18n.setOnChange(() => {
    readyStatus = ''
    if (!measure?.isActive && !markup?.isActive) {
      measure?.refreshIdleStatus()
      markup?.refreshIdleStatus()
    }
    layerPanel?.refreshLayerLabels()
    reviewPanel?.refreshLabels()
    measurePanel?.refreshLabels()
    sessionPanel?.refreshLabels()
    measureSettingsRef.current?.refreshLabels()
    sessionDrawStyleRef.current?.refreshLabels()
    mainToolbarRef.current?.refreshLabels()
    expiryMonitor?.refreshLabels()
    // Re-apply visibility button label after i18n DOM refresh.
    if (markup) {
      markup.setVisible(markup.visible)
    }
    if (measure) {
      measure.setVisible(measure.visible)
    }
    // Theme button keys may have been overwritten by applyToDocument; re-sync.
    applyHtmlTheme(
      (document.documentElement.getAttribute(
        'data-mlcad-theme'
      ) as AcExHtmlTheme | null) ?? 'dark'
    )
    i18n.applyToDocument()
    mainToolbarRef.current?.refresh()
    // Refresh rebuilds toolbar DOM; restore nav pressed state afterward.
    navToolsRef.current?.syncButtons()
    sessionDrawStyleRef.current?.refresh()
  })

  window.addEventListener('keydown', event => {
    // Don't steal keys from real text fields; markup inline edit uses
    // stopPropagation on its own keydown handler.
    const target = event.target as HTMLElement | null
    if (
      target instanceof HTMLInputElement ||
      target instanceof HTMLTextAreaElement ||
      (target?.isContentEditable &&
        target.closest('.mlcad-markup-text-editing'))
    ) {
      return
    }
    if (
      event.key === 'Escape' &&
      !isToolActive() &&
      navToolsRef.current?.getMode() === 'zoom-window'
    ) {
      event.preventDefault()
      navToolsRef.current.cancelZoomWindow()
      return
    }
    if (!measure || !markup) return
    if (
      measure.handleKeyDown(event.key, event) ||
      markup.handleKeyDown(event.key)
    ) {
      event.preventDefault()
      return
    }
    if (
      measure.handleSelectionKeyDown(event.key, event) ||
      markup.handleSelectionKeyDown(event.key, event)
    ) {
      event.preventDefault()
    }
  })

  window.addEventListener('resize', () => {
    resize()
    mainToolbarRef.current?.syncLayout()
    recomputeOsnapThresholdWcs()
    bumpSnapCacheKey()
    render()
  })

  window.addEventListener('pagehide', () => {
    mainToolbarRef.current?.destroy()
    mainToolbarRef.current = null
  })

  resize()
  if (snapshot.meta.initialView === 'current' && snapshot.meta.viewState) {
    const { centerX, centerY, zoom } = snapshot.meta.viewState
    flyTo(centerX, centerY, zoom)
    render()
  } else {
    fit()
  }
  const initialView = captureViewState()
  originalByLayout.set(layout.btrId, initialView)
  lastViewByLayout.set(layout.btrId, initialView)
  // Shared typed arrays back the snapshot and THREE attributes until hybrid
  // OSNAP (measure) finishes. After that, release CPU — GPU stays; switching
  // layouts rehydrates from package chunks or retained monolithic gzip.
  if (!packageSession && !measureEnabled) {
    releaseCpuAfterGpuUpload()
  }
  measure?.refreshIdleStatus()
  if (expiresAt != null) {
    expiryMonitor = setupAcExHtmlExpiryMonitor({
      expiresAt,
      i18n,
      onExpire: () => {
        // Keep the canvas mounted under the expired gate; interaction is blocked
        // by the loading overlay.
        shortCutToolbarRef.current?.syncTopOffset()
      }
    })
    shortCutToolbarRef.current?.syncTopOffset()
  }
  // Reveal the canvas before package chunks / OSNAP indexing finish so the
  // drawing paints while background work continues. Toolbar stays disabled
  // until geometry is ready; canvas wheel / pinch zoom still works.
  hideLoading()

  if (!packageSession) {
    markGeometryReady(true)
    if (measureEnabled) {
      markOsnapReady(false)
      try {
        await rebuildOsnapForLoadedGeometry()
        recomputeOsnapThresholdWcs()
        bumpSnapCacheKey()
        measure?.refreshIdleStatus()
        render()
        markOsnapReady(true)
      } catch (error) {
        showViewerError(i18n.t('status.loadFailed', { error: String(error) }))
        // Drawing is visible; allow measure/annotation without a full snap index.
        markOsnapReady(true)
      }
      releaseCpuAfterGpuUpload()
    } else {
      markOsnapReady(true)
    }
  }

  if (packageSession) {
    try {
      const firstPaintLayouts: AcExLayoutSnapshot[] = [layout]
      if (!layout.isModelSpace && hasPaperViewports && modelLayout) {
        firstPaintLayouts.push(modelLayout)
      }
      for (const target of firstPaintLayouts) {
        await loadPackageLayoutGeometry(target)
      }
      layoutExtents = resolveLayoutViewExtents(
        layout,
        snapshot.meta.viewExtents ?? snapshot.meta.extents
      )
      layerPanel?.syncLayerZoomButtons()
      recomputeOsnapThresholdWcs()
      bumpSnapCacheKey()
      measure?.refreshIdleStatus()
      render()
      markGeometryReady(true)

      // Cache per-layer extents while CPU batches are still resident.
      const paintedExtents = computeLayerExtentsMap(
        layout.lineBatches,
        layout.meshBatches
      )
      layerExtents.clear()
      for (const [name, extents] of paintedExtents) {
        layerExtents.set(name, extents)
      }
      layerExtentsByLayout.set(layout.btrId, new Map(layerExtents))
      refreshBatchExtentCache(layout)
      layerPanel?.syncLayerZoomButtons()

      // ACEO now holds curves/points only (lines come from geometry batches).
      // Load the small catalog first, then build a hybrid index while CPU
      // lineBatches are still resident — before releaseCpuAfterGpuUpload.
      if (measureEnabled) {
        markOsnapReady(false)
        for (const target of firstPaintLayouts) {
          await loadPackageLayoutOsnap(target)
        }
        await rebuildOsnapForLoadedGeometry()
        recomputeOsnapThresholdWcs()
        bumpSnapCacheKey()
        measure?.refreshIdleStatus()
        render()
        markOsnapReady(true)
      } else {
        markOsnapReady(true)
      }

      releaseCpuAfterGpuUpload()
    } catch (error) {
      showViewerError(i18n.t('status.loadFailed', { error: String(error) }))
      // Unlock chrome even when package geometry / OSNAP failed mid-stream so
      // the toolbar does not stay permanently disabled after the error gate.
      markGeometryReady(true)
      markOsnapReady(true)
    }
  }
}

interface AcExLayerRowRefs {
  /** Layer name shown in the row. */
  name: string
  /** Per-layer zoom button whose `title` / `aria-label` are retranslated. */
  zoomBtn: HTMLButtonElement
}

/** Dependencies passed into {@link setupLayerPanel}. */
interface AcExLayerPanelContext {
  /** Full snapshot (layer table and metadata). */
  snapshot: AcExSnapshot
  /** Mutable visibility map shared with the THREE layer groups. */
  layerVisible: Map<string, boolean>
  /** THREE groups keyed by layer name (paper and/or model space). */
  layerGroupMaps: Map<string, THREE.Group>[]
  /** Precomputed XY extents per layer for zoom-to-layer. */
  layerExtents: Map<string, AcExExtents | null>
  /** Footer status bar element. */
  statusEl: HTMLElement
  /** I18n instance for drawer strings. */
  i18n: AcExHtmlI18n
  /** Redraws the WebGL canvas after visibility changes. */
  render: () => void
  /** Fits the camera to the given extents and redraws. */
  zoomToExtents: (extents: AcExExtents) => void
  /** Clears an in-progress zoom-window rubber band / mode before layer zoom. */
  cancelZoomWindow: () => void
  /** Object-snap indexes updated when layer visibility changes. */
  osnapIndexes: AcExOsnapIndex[]
  /** Sorted layer names for bulk show/hide actions. */
  sortedLayerNames: string[]
  /** Close the review drawer when the layer drawer opens. */
  closeOtherDrawers?: () => void
  /** Phone: park the drawer and dismiss open strips. */
  onPhoneOpen?: (drawer: HTMLElement) => void
}

/** Handles returned by {@link setupLayerPanel} for locale-driven UI updates. */
interface AcExLayerPanelController {
  /** Reapplies `layers.zoomTo` labels on every per-layer zoom button. */
  refreshLayerLabels: () => void
  /** Enables/disables per-layer zoom after the active layout changes. */
  syncLayerZoomButtons: () => void
  /** Opens or closes the layer drawer. */
  setOpen: (open: boolean) => void
  /** Closes the layer drawer. */
  close: () => void
  /** Whether the layer drawer is currently open. */
  isOpen: () => boolean
}

function setupLayerPanel(
  ctx: AcExLayerPanelContext
): AcExLayerPanelController | null {
  const {
    snapshot,
    layerVisible,
    layerGroupMaps,
    layerExtents,
    statusEl,
    i18n,
    render,
    zoomToExtents,
    cancelZoomWindow,
    osnapIndexes,
    sortedLayerNames,
    closeOtherDrawers,
    onPhoneOpen
  } = ctx

  const layersBtn = document.getElementById('mlcad-layers-btn')
  const layerDrawer = document.getElementById('mlcad-layer-drawer')
  const layerList = document.getElementById('mlcad-layer-list')
  const layerClose = document.getElementById('mlcad-layer-close')
  const showAllBtn = document.getElementById('mlcad-layer-show-all')
  const hideAllBtn = document.getElementById('mlcad-layer-hide-all')
  if (!layerDrawer || !layerList) return null

  const layerRows: AcExLayerRowRefs[] = []

  const sortedLayers = sortedLayerNames

  const layerMeta = new Map(snapshot.layers.map(layer => [layer.name, layer]))

  const checkboxes: HTMLInputElement[] = []

  const setGroupsVisible = (name: string, visible: boolean) => {
    for (const groups of layerGroupMaps) {
      const group = groups.get(name)
      if (group) group.visible = visible
    }
  }

  const setLayerVisible = (name: string, visible: boolean) => {
    layerVisible.set(name, visible)
    setGroupsVisible(name, visible)
    for (const index of osnapIndexes) {
      index.setLayerHidden(name, !visible)
    }
  }

  const setAllLayersVisible = (visible: boolean) => {
    for (const name of sortedLayers) {
      layerVisible.set(name, visible)
      setGroupsVisible(name, visible)
    }
    if (visible) {
      for (const index of osnapIndexes) {
        index.showAllLayers()
      }
    } else {
      for (const index of osnapIndexes) {
        index.hideAllLayers(sortedLayers)
      }
    }
    for (const checkbox of checkboxes) {
      checkbox.checked = visible
    }
    render()
  }

  for (const name of sortedLayers) {
    const meta = layerMeta.get(name)
    const row = document.createElement('label')
    row.className = 'mlcad-layer-item'

    const checkbox = document.createElement('input')
    checkbox.type = 'checkbox'
    checkbox.checked = layerVisible.get(name) !== false
    checkbox.addEventListener('change', () => {
      setLayerVisible(name, checkbox.checked)
      render()
    })
    checkboxes.push(checkbox)

    const swatch = document.createElement('span')
    swatch.className = 'mlcad-layer-swatch'
    const color = meta?.color ?? 0xffffff
    swatch.style.background = `#${color.toString(16).padStart(6, '0')}`

    const nameEl = document.createElement('span')
    nameEl.className = 'mlcad-layer-name'
    nameEl.textContent = name
    nameEl.title = name

    const zoomBtn = document.createElement('button')
    zoomBtn.type = 'button'
    zoomBtn.className = 'mlcad-layer-zoom'
    const updateZoomLabels = () => {
      const label = i18n.t('layers.zoomTo', { name })
      zoomBtn.title = label
      zoomBtn.setAttribute('aria-label', label)
    }
    updateZoomLabels()
    zoomBtn.innerHTML = AcExHtmlIcons.zoomBox
    const extents = layerExtents.get(name)
    zoomBtn.disabled = !extents
    zoomBtn.addEventListener('click', event => {
      event.preventDefault()
      event.stopPropagation()
      const liveExtents = layerExtents.get(name)
      if (!liveExtents) return
      cancelZoomWindow()
      zoomToExtents(liveExtents)
      statusEl.textContent = i18n.t('status.zoomLayer', { name })
    })
    layerRows.push({ name, zoomBtn })

    row.append(checkbox, swatch, nameEl, zoomBtn)
    layerList.appendChild(row)
  }

  const setDrawerOpen = (open: boolean) => {
    if (open) {
      closeOtherDrawers?.()
      onPhoneOpen?.(layerDrawer)
    }
    layerDrawer.hidden = !open
    layersBtn?.classList.toggle('active', open)
    layersBtn?.setAttribute('aria-expanded', String(open))
  }

  // Layer open/close is driven by MainToolbar `layer` action via
  // {@link AcExHtmlMainToolbarHandlers.toggleLayerDrawer}; do not bind the
  // annotated `#mlcad-layers-btn` click here (would double-toggle).

  layerClose?.addEventListener('click', () => setDrawerOpen(false))
  layerDrawer
    .querySelector('.mlcad-drawer-sheet-close')
    ?.addEventListener('click', () => setDrawerOpen(false))

  showAllBtn?.addEventListener('click', () => setAllLayersVisible(true))
  hideAllBtn?.addEventListener('click', () => setAllLayersVisible(false))

  document.addEventListener('click', event => {
    if (layerDrawer.hidden) return
    const target = event.target
    if (!(target instanceof Node)) return
    const sidebar = document.getElementById('mlcad-sidebar')
    if (sidebar?.contains(target)) return
    setDrawerOpen(false)
  })

  return {
    refreshLayerLabels: () => {
      for (const row of layerRows) {
        const label = i18n.t('layers.zoomTo', { name: row.name })
        row.zoomBtn.title = label
        row.zoomBtn.setAttribute('aria-label', label)
      }
    },
    syncLayerZoomButtons: () => {
      for (const row of layerRows) {
        row.zoomBtn.disabled = !layerExtents.get(row.name)
      }
    },
    setOpen: setDrawerOpen,
    close: () => setDrawerOpen(false),
    isOpen: () => !layerDrawer.hidden
  }
}

function applyBatchPose(
  object: THREE.Object3D,
  batch: { offset: [number, number, number]; renderOrder?: number }
): void {
  object.position.set(batch.offset[0], batch.offset[1], batch.offset[2])
  if (batch.renderOrder != null) {
    object.renderOrder = batch.renderOrder
  }
}

/**
 * Hatch-tier fills sit below linework on the shared Z plane.
 * Prefer the exported `renderOrder` (from `drawOrder`); patterned/gradient
 * batches without that field still fall back to `-1`.
 */
function resolveMeshRenderOrder(batch: AcExMeshBatch): number | undefined {
  if (batch.renderOrder != null) {
    return batch.renderOrder
  }
  if (batch.hatchPattern || batch.gradientFill) {
    return -1
  }
  return undefined
}

function createLineObject(
  batch: AcExLineBatch,
  wideLineMaterials: LineMaterial[],
  wideLineResolution: THREE.Vector2
): THREE.Object3D | null {
  if (batch.positions.length < 6) return null

  if (batch.lineWidth != null && batch.lineWidth > 0) {
    const geometry = new LineSegmentsGeometry()
    geometry.setPositions(batch.positions)
    const material = createViewerLineMaterial(
      batch,
      wideLineResolution
    ) as LineMaterial
    wideLineMaterials.push(material)
    const object = new LineSegments2(geometry, material)
    applyBatchPose(object, batch)
    return object
  }

  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute(
    'position',
    new THREE.BufferAttribute(batch.positions, 3)
  )
  if (batch.indices && batch.indices.length > 0) {
    geometry.setIndex(new THREE.BufferAttribute(batch.indices, 1))
  }
  if (
    batch.linePattern &&
    batch.lineDistances &&
    batch.lineDistances.length > 0
  ) {
    geometry.setAttribute(
      'lineDistance',
      new THREE.BufferAttribute(batch.lineDistances, 1)
    )
  }
  const material = createViewerLineMaterial(batch)
  const object = new THREE.LineSegments(geometry, material)
  applyBatchPose(object, batch)
  return object
}

/** Same defaults as {@link AcTrBaseView#createCameraControls}, plus left-button pan
 * for mouse and macOS trackpad three-finger drag. */
function createOrbitControls(
  camera: THREE.OrthographicCamera,
  domElement: HTMLElement
): OrbitControls {
  const controls = new OrbitControls(camera, domElement)
  controls.enableDamping = false
  controls.autoRotate = false
  controls.enableRotate = false
  controls.zoomSpeed = 5
  controls.zoomToCursor = true
  setOrbitPanButtons(controls, { leftMousePan: true, oneFingerPan: true })
  controls.update()
  return controls
}

/**
 * Configures OrbitControls mouse and touch pan independently.
 *
 * Idle pan: left mouse + one-finger touch. Drawing tools: one-finger touch
 * pan until precise capture, but no left-mouse pan so clicks still pick.
 * Select / loupe: middle mouse and two-finger gestures only.
 */
function setOrbitPanButtons(
  controls: OrbitControls,
  options: { leftMousePan: boolean; oneFingerPan: boolean }
): void {
  controls.mouseButtons = options.leftMousePan
    ? {
        LEFT: THREE.MOUSE.PAN,
        MIDDLE: THREE.MOUSE.PAN
      }
    : {
        MIDDLE: THREE.MOUSE.PAN
      }
  controls.touches = options.oneFingerPan
    ? {
        ONE: THREE.TOUCH.PAN,
        TWO: THREE.TOUCH.DOLLY_PAN
      }
    : {
        TWO: THREE.TOUCH.DOLLY_PAN
      }
}

/** Grabbing cursor while middle-button or idle left-button pan is held. */
function setupPanCursorFeedback(
  domElement: HTMLElement,
  isLeftPanEnabled: () => boolean
): void {
  let panPointerId: number | null = null

  const clearPanCursor = (event: PointerEvent) => {
    if (panPointerId === null || event.pointerId !== panPointerId) return
    panPointerId = null
    domElement.style.cursor = ''
  }

  domElement.addEventListener('pointerdown', event => {
    const isMiddlePan = event.button === 1
    const isLeftPan = event.button === 0 && isLeftPanEnabled()
    if (!isMiddlePan && !isLeftPan) return
    panPointerId = event.pointerId
    domElement.style.cursor = 'grabbing'
  })
  // Capture release even when the pointer leaves the canvas.
  window.addEventListener('pointerup', clearPanCursor)
  window.addEventListener('pointercancel', clearPanCursor)
}

/**
 * Pointer wiring for {@link setupToolPointerInput}.
 */
interface AcExToolPointerInputOptions {
  /** Canvas (or host) that receives pointer events. */
  domElement: HTMLElement
  /** Overlay host for the selection rubber band. */
  root: HTMLElement
  /** Converts a client point to world XY. */
  screenToWcs: (clientX: number, clientY: number) => { x: number; y: number }
  /** Active measure controller, or `null` when measure is disabled. */
  getMeasure: () => AcExMeasureController | null
  /** Active markup controller, or `null` when markup is disabled. */
  getMarkup: () => AcExMarkupController | null
  /** Navigation tools (zoom-window, etc.), or `null` before they are created. */
  getNavTools: () => ReturnType<typeof setupAcExHtmlNavTools> | null
  /** Redraws the scene, overlays, paper viewports, and snap loupe. */
  render: () => void
}

/**
 * Left-button tool picking / selection on capture so selection can block
 * OrbitControls pan. While a drawing tool is active, mouse left-pan is off
 * (clicks pick) but one-finger touch pan stays on until the snap loupe opens.
 * Touch drawing tools defer commit until pointerup so a long-press can open
 * the loupe; jig preview also waits until that precise-capture phase.
 *
 * The snap loupe is driven through {@link acexRefreshMobileSnapLoupe} so
 * drawing picks and overlay grip drags share one implementation.
 *
 * @param options - Canvas, tool accessors, and render callback.
 */
function setupToolPointerInput(options: AcExToolPointerInputOptions): void {
  const {
    domElement,
    root,
    screenToWcs,
    getMeasure,
    getMarkup,
    getNavTools,
    render
  } = options
  let pendingMove: { clientX: number; clientY: number } | null = null
  let moveRaf = 0
  const touchSession = new AcExTouchPointSession()
  const touchPickHudHost: AcExTouchPickHudHost = {
    refreshSnapLoupe: (clientX, clientY) => {
      acexRefreshMobileSnapLoupe(clientX, clientY)
    },
    hideSnapLoupe: () => {
      acexHideMobileSnapLoupe()
    },
    refreshSimulatedCursor: (clientX, clientY) => {
      acexRefreshSimulatedMouseCursor(root, clientX, clientY)
    },
    hideSimulatedCursor: () => {
      acexHideSimulatedMouseCursor()
    }
  }
  const hideTouchPreciseHud = () => {
    acexHideMobileSnapLoupe()
    acexHideSimulatedMouseCursor()
  }
  const applyTouchPreciseSample = (fingerX: number, fingerY: number) => {
    const sample = acexTouchPickStrategy().mapFingerToSample(fingerX, fingerY)
    previewDrawingPoint(sample.x, sample.y)
    acexTouchPickStrategy().showPreciseHud(touchPickHudHost, sample.x, sample.y)
  }
  /** Idle box-select / zoom-window rubber band after a long-press or mouse down. */
  let boxGesture: {
    kind: 'select' | 'zoom-window'
    pointerId: number
    pointerType: string
    startX: number
    startY: number
    activated: boolean
  } | null = null
  const releaseBoxPointerCapture = (pointerId: number) => {
    try {
      if (domElement.hasPointerCapture(pointerId)) {
        domElement.releasePointerCapture(pointerId)
      }
    } catch {
      // Pointer may already be released.
    }
  }

  const selectionRect = document.createElement('div')
  selectionRect.id = 'mlcad-selection-rect'
  selectionRect.hidden = true
  root.appendChild(selectionRect)

  const hideSelectionRect = () => {
    selectionRect.hidden = true
  }

  const updateSelectionRect = (
    startX: number,
    startY: number,
    clientX: number,
    clientY: number,
    kind: 'select' | 'zoom-window'
  ) => {
    const left = Math.min(startX, clientX)
    const top = Math.min(startY, clientY)
    selectionRect.style.left = `${left}px`
    selectionRect.style.top = `${top}px`
    selectionRect.style.width = `${Math.abs(clientX - startX)}px`
    selectionRect.style.height = `${Math.abs(clientY - startY)}px`
    if (kind === 'select') {
      selectionRect.dataset.mode = acexSelectionModeFromDrag(startX, clientX)
    } else {
      delete selectionRect.dataset.mode
    }
    selectionRect.hidden = false
  }

  /**
   * Drops a coalesced pointer-move frame so it cannot revive OSNAP / jig
   * after a successful pick (or aborted touch gesture).
   */
  const cancelPendingPointerMove = () => {
    if (moveRaf !== 0) {
      cancelAnimationFrame(moveRaf)
      moveRaf = 0
    }
    pendingMove = null
  }

  /**
   * Whether measure or markup is currently drawing.
   *
   * @returns True when a drawing tool should receive the next pick.
   */
  const isDrawingToolActive = () =>
    getMeasure()?.isActive === true || getMarkup()?.isActive === true

  /**
   * Commits a measure or markup point at the given client sample.
   *
   * @param clientX - Sample X in client CSS pixels.
   * @param clientY - Sample Y in client CSS pixels.
   */
  const commitDrawingPoint = (clientX: number, clientY: number) => {
    // A move sample queued before this pick must not re-show the OSNAP glyph
    // after handlePointerDown clears it.
    cancelPendingPointerMove()
    const measure = getMeasure()
    const markup = getMarkup()
    if (measure?.isActive) {
      if (measure.handlePointerDown(clientX, clientY)) {
        if (measure.hasSelection) markup?.clearSelection()
        render()
      }
      return
    }
    if (markup?.isActive) {
      if (markup.handlePointerDown(clientX, clientY)) {
        if (markup.hasSelection) measure?.clearSelection()
        render()
      }
    }
  }

  /**
   * Updates the in-progress measure or markup preview without committing.
   *
   * @param clientX - Sample X in client CSS pixels.
   * @param clientY - Sample Y in client CSS pixels.
   */
  const previewDrawingPoint = (clientX: number, clientY: number) => {
    const measure = getMeasure()
    const markup = getMarkup()
    if (measure?.isActive) {
      measure.handlePointerMove(clientX, clientY)
      render()
      return
    }
    if (markup?.isActive) {
      markup.handlePointerMove(clientX, clientY)
      render()
    }
  }

  /**
   * Applies the latest coalesced pointer-move sample: tool preview, precise HUD
   * while long-pressing, or zoom-window rubber band.
   */
  const flushPointerMove = () => {
    moveRaf = 0
    const sample = pendingMove
    pendingMove = null
    if (!sample) return
    const measure = getMeasure()
    const markup = getMarkup()
    if (measure?.isActive) {
      if (touchSession.isLoupe) {
        applyTouchPreciseSample(sample.clientX, sample.clientY)
        render()
        return
      }
      measure.handlePointerMove(sample.clientX, sample.clientY)
      render()
      return
    }
    if (markup?.isActive) {
      if (touchSession.isLoupe) {
        applyTouchPreciseSample(sample.clientX, sample.clientY)
        render()
        return
      }
      markup.handlePointerMove(sample.clientX, sample.clientY)
      render()
      return
    }
    if (boxGesture?.activated) {
      if (boxGesture.kind === 'zoom-window') {
        getNavTools()?.handlePointerMove(sample.clientX, sample.clientY)
      } else {
        updateSelectionRect(
          boxGesture.startX,
          boxGesture.startY,
          sample.clientX,
          sample.clientY,
          boxGesture.kind
        )
      }
      return
    }
    getNavTools()?.handlePointerMove(sample.clientX, sample.clientY)
  }

  const idleNavMode = (): 'select' | 'pan' | 'zoom-window' | null => {
    if (isDrawingToolActive()) return null
    return getNavTools()?.getMode() ?? null
  }

  const applyClickSelect = (clientX: number, clientY: number): boolean => {
    const markup = getMarkup()
    const measure = getMeasure()
    if (markup?.handleSelectionPointerDown(clientX, clientY)) {
      if (markup.hasSelection) measure?.clearSelection()
      render()
      return true
    }
    if (measure?.handleSelectionPointerDown(clientX, clientY)) {
      if (measure.hasSelection) markup?.clearSelection()
      render()
      return true
    }
    return false
  }

  const applyBoxSelect = (
    startX: number,
    startY: number,
    endX: number,
    endY: number
  ) => {
    const a = screenToWcs(startX, startY)
    const b = screenToWcs(endX, endY)
    const box: AcExExtents = {
      minX: Math.min(a.x, b.x),
      minY: Math.min(a.y, b.y),
      maxX: Math.max(a.x, b.x),
      maxY: Math.max(a.y, b.y)
    }
    const mode = acexSelectionModeFromDrag(startX, endX)
    getMarkup()?.handleSelectionBox(box, mode)
    getMeasure()?.handleSelectionBox(box, mode)
    render()
  }

  const finishBoxGesture = (
    clientX: number,
    clientY: number,
    commit: boolean
  ) => {
    const gesture = boxGesture
    boxGesture = null
    hideSelectionRect()
    acexSetMobileSnapLoupePreciseCapture(false)
    if (gesture) releaseBoxPointerCapture(gesture.pointerId)
    // Compat mouse after touch, not a real mouse box-select.
    if (gesture?.pointerType === 'touch') acexSinkFollowingClick()
    if (!gesture) return
    if (!commit || !gesture.activated) {
      if (gesture.kind === 'zoom-window') {
        getNavTools()?.cancelZoomWindow()
      }
      return
    }
    const moved =
      Math.hypot(clientX - gesture.startX, clientY - gesture.startY) >= 8
    if (gesture.kind === 'zoom-window') {
      if (moved) {
        getNavTools()?.handlePointerDown(clientX, clientY)
      } else {
        getNavTools()?.cancelZoomWindow()
      }
      return
    }
    if (moved) {
      applyBoxSelect(gesture.startX, gesture.startY, clientX, clientY)
    } else {
      applyClickSelect(clientX, clientY)
    }
  }

  /**
   * Ends a touch pick. When `commit` is true, a short tap or loupe release
   * places the drawing point; otherwise the gesture is aborted.
   *
   * @param event - Pointer event that ended or cancelled the gesture.
   * @param commit - When false, abort without placing a point.
   */
  const endTouchPick = (event: PointerEvent, commit: boolean) => {
    if (event.pointerType !== 'touch') return
    if (touchSession.phase === 'idle') return
    if (event.pointerId !== touchSession.pointerId) return
    if (boxGesture) {
      const gesture = boxGesture
      const wasActivated = gesture.activated
      cancelPendingPointerMove()
      if (!commit) {
        if (!wasActivated && touchSession.isPicking) {
          return
        }
        touchSession.cancel()
        finishBoxGesture(event.clientX, event.clientY, false)
        render()
        return
      }
      const action = touchSession.end()
      if (action === 'ignore') {
        finishBoxGesture(event.clientX, event.clientY, false)
        render()
        return
      }
      if (!wasActivated) {
        boxGesture = null
        hideSelectionRect()
        acexSetMobileSnapLoupePreciseCapture(false)
        releaseBoxPointerCapture(gesture.pointerId)
        acexSinkFollowingClick()
        if (gesture.kind === 'select') {
          applyClickSelect(event.clientX, event.clientY)
        }
        return
      }
      finishBoxGesture(event.clientX, event.clientY, true)
      return
    }
    acexSetMobileSnapLoupePreciseCapture(false)
    // Loupe moves coalesce into RAF; cancel before commit/abort so a late
    // flush cannot set live pointer and bring the OSNAP glyph back.
    cancelPendingPointerMove()
    // Chrome synthesizes mouse pointerdown+click after touchup near the finger.
    // Without this, a two-point tool would commit the second point immediately
    // and clear the confirmed-point plus mark.
    acexSinkFollowingClick()
    if (!commit) {
      touchSession.cancel()
      hideTouchPreciseHud()
      render()
      return
    }
    const wasPrecise = touchSession.isLoupe
    const action = touchSession.end()
    hideTouchPreciseHud()
    if (action === 'commit') {
      if (wasPrecise) {
        const sample = acexTouchPickStrategy().mapFingerToSample(
          event.clientX,
          event.clientY
        )
        commitDrawingPoint(sample.x, sample.y)
      } else {
        commitDrawingPoint(event.clientX, event.clientY)
      }
    } else {
      render()
    }
  }

  const idlePointerHost: AcExIdlePointerHost = {
    navMode: () => idleNavMode(),
    shouldIgnoreCompatMouse: () => acexShouldIgnoreCompatMouse(),
    startTouchBox: (kind, event) => {
      // preventDefault only: do not stopImmediatePropagation so OrbitControls
      // still receives pointerdown and can pan if the finger moves first.
      event.preventDefault()
      boxGesture = {
        kind,
        pointerId: event.pointerId,
        pointerType: 'touch',
        startX: event.clientX,
        startY: event.clientY,
        activated: false
      }
      touchSession.start(event.pointerId, event.clientX, event.clientY, () => {
        if (!boxGesture || boxGesture.pointerId !== event.pointerId) return
        boxGesture.activated = true
        boxGesture.startX = touchSession.x
        boxGesture.startY = touchSession.y
        acedClearDomSelection()
        acexSetMobileSnapLoupePreciseCapture(true)
        if (kind === 'zoom-window') {
          getNavTools()?.handlePointerDown(touchSession.x, touchSession.y)
        } else {
          updateSelectionRect(
            touchSession.x,
            touchSession.y,
            touchSession.x,
            touchSession.y,
            kind
          )
        }
      })
      domElement.setPointerCapture(event.pointerId)
    },
    startMouseBox: event => {
      event.stopImmediatePropagation()
      boxGesture = {
        kind: 'select',
        pointerId: event.pointerId,
        pointerType: event.pointerType,
        startX: event.clientX,
        startY: event.clientY,
        activated: true
      }
      try {
        domElement.setPointerCapture(event.pointerId)
      } catch {
        // Capture is best-effort so the rubber band tracks off-canvas.
      }
      updateSelectionRect(
        event.clientX,
        event.clientY,
        event.clientX,
        event.clientY,
        'select'
      )
    },
    finishMouseBox: (event, commit) => {
      if (!boxGesture || event.pointerId !== boxGesture.pointerId) {
        return false
      }
      if (boxGesture.pointerType === 'touch') return false
      finishBoxGesture(event.clientX, event.clientY, commit)
      return true
    },
    handleNavPointerDown: event => {
      if (getNavTools()?.handlePointerDown(event.clientX, event.clientY)) {
        event.stopImmediatePropagation()
        return true
      }
      return false
    },
    applyClickSelect: event => {
      if (!applyClickSelect(event.clientX, event.clientY)) return false
      event.stopImmediatePropagation()
      return true
    }
  }

  domElement.addEventListener(
    'pointerdown',
    event => {
      if (event.button !== 0) return
      if (event.pointerType !== 'touch' && acexShouldIgnoreCompatMouse()) {
        event.stopImmediatePropagation()
        return
      }
      const measure = getMeasure()
      const markup = getMarkup()
      if (event.pointerType === 'touch' && isDrawingToolActive()) {
        // Match cad-simple-viewer: keep the OS from turning a still finger into
        // scroll / context-menu `pointercancel` before the precise timer fires.
        event.preventDefault()
        touchSession.start(
          event.pointerId,
          event.clientX,
          event.clientY,
          () => {
            // Precise capture only: lock pan and start jig / HUD preview.
            acedClearDomSelection()
            acexSetMobileSnapLoupePreciseCapture(true)
            applyTouchPreciseSample(touchSession.x, touchSession.y)
            render()
          }
        )
        domElement.setPointerCapture(event.pointerId)
        return
      }
      if (measure?.isActive) {
        cancelPendingPointerMove()
        if (measure.handlePointerDown(event.clientX, event.clientY)) {
          if (measure.hasSelection) markup?.clearSelection()
          render()
        }
        return
      }
      if (markup?.isActive) {
        cancelPendingPointerMove()
        if (markup.handlePointerDown(event.clientX, event.clientY)) {
          if (markup.hasSelection) measure?.clearSelection()
          render()
        }
        return
      }
      acexIdlePointerStrategy().onPointerDown(event, idlePointerHost)
    },
    true
  )
  domElement.addEventListener('pointermove', event => {
    const measure = getMeasure()
    const markup = getMarkup()
    const zoomWindow = getNavTools()?.getMode() === 'zoom-window'
    if (event.pointerType === 'touch' && touchSession.phase !== 'idle') {
      if (event.pointerId !== touchSession.pointerId) return
      // Movement before the loupe aborts the pick so OrbitControls can pan.
      const moved = touchSession.move(event.clientX, event.clientY, true)
      if (moved === 'panning') {
        if (boxGesture) {
          boxGesture = null
          hideSelectionRect()
        }
        return
      }
      if (!touchSession.isLoupe) return
    }
    if (boxGesture && event.pointerId === boxGesture.pointerId) {
      if (boxGesture.activated) {
        pendingMove = { clientX: event.clientX, clientY: event.clientY }
        if (moveRaf === 0) {
          moveRaf = requestAnimationFrame(flushPointerMove)
        }
      }
      return
    }
    if (!measure?.isActive && !markup?.isActive && !zoomWindow) return
    pendingMove = { clientX: event.clientX, clientY: event.clientY }
    if (moveRaf === 0) {
      moveRaf = requestAnimationFrame(flushPointerMove)
    }
  })
  window.addEventListener('pointerup', event => {
    if (acexIdlePointerStrategy().onPointerUp(event, idlePointerHost)) return
    endTouchPick(event, true)
  })
  window.addEventListener('pointercancel', event => {
    if (acexIdlePointerStrategy().onPointerCancel(event, idlePointerHost)) {
      return
    }
    endTouchPick(event, false)
  })
}

function createPointObject(batch: AcExMeshBatch): THREE.Points | null {
  if (batch.positions.length < 3) return null
  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute(
    'position',
    new THREE.BufferAttribute(batch.positions, 3)
  )
  const material = createViewerPointsMaterial(batch)
  const object = new THREE.Points(geometry, material)
  applyBatchPose(object, {
    offset: batch.offset,
    renderOrder: batch.renderOrder
  })
  return object
}

function createMeshObject(batch: AcExMeshBatch): THREE.Mesh | null {
  if (!batch.indices || batch.indices.length < 3) {
    return null
  }
  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute(
    'position',
    new THREE.BufferAttribute(batch.positions, 3)
  )
  geometry.setIndex(new THREE.BufferAttribute(batch.indices, 1))
  if (
    batch.gradientFill &&
    batch.gradientPositions &&
    batch.gradientPositions.length >= 2
  ) {
    geometry.setAttribute(
      'gradientPosition',
      new THREE.BufferAttribute(batch.gradientPositions, 2)
    )
  }
  if (batch.uvs && batch.uvs.length >= 2) {
    geometry.setAttribute('uv', new THREE.BufferAttribute(batch.uvs, 2))
  }
  const material = createViewerMeshMaterial(batch, {
    onTextureLoad: () => {
      requestViewerTextureRepaint?.()
    }
  })
  const object = new THREE.Mesh(geometry, material)
  applyBatchPose(object, {
    offset: batch.offset,
    renderOrder: resolveMeshRenderOrder(batch)
  })
  return object
}

bootstrap()
