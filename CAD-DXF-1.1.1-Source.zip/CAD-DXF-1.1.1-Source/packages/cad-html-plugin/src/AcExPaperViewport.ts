import {
  type AcExCssRect,
  acexCssRectToWcsBox,
  acexIntersectCssRects
} from './AcExCssRect'
import type { AcExExtents, AcExViewportSnapshot } from './AcExSnapshotTypes'

const EPS = 1e-12

/**
 * Returns `true` when `(x, y)` (paper WCS) lies inside the viewport frame.
 */
export function viewportContainsPaperPoint(
  viewport: AcExViewportSnapshot,
  x: number,
  y: number
): boolean {
  const box = viewport.paper
  return x >= box.minX && x <= box.maxX && y >= box.minY && y <= box.maxY
}

/**
 * Returns `true` when the paper point is within `tolerance` of any of the
 * four viewport edges. Used to keep frame clicks on the border instead of
 * drilling through to model space.
 */
export function viewportIsNearPaperBorder(
  viewport: AcExViewportSnapshot,
  x: number,
  y: number,
  tolerance: number
): boolean {
  if (!viewportContainsPaperPoint(viewport, x, y)) return false
  const box = viewport.paper
  const distLeft = Math.abs(x - box.minX)
  const distRight = Math.abs(x - box.maxX)
  const distBottom = Math.abs(y - box.minY)
  const distTop = Math.abs(y - box.maxY)
  return Math.min(distLeft, distRight, distBottom, distTop) <= tolerance
}

/**
 * View twist in radians, or `0` when omitted / non-finite.
 */
export function viewportTwist(viewport: AcExViewportSnapshot): number {
  const twist = viewport.twist
  return typeof twist === 'number' && Number.isFinite(twist) ? twist : 0
}

/**
 * Paper-space WCS → model-space WCS through a viewport.
 *
 * Maps the paper rectangle onto the DCS view (`model` size around its
 * center), then rotates by {@link AcExViewportSnapshot.twist} so a
 * non-zero DVIEW twist matches `AcGiViewport.dcsCenterToWcs`. Degenerate
 * paper boxes return the model view center.
 *
 * Inverse of {@link modelPointToPaper}.
 */
export function paperPointToModel(
  viewport: AcExViewportSnapshot,
  x: number,
  y: number
): { x: number; y: number } {
  const paper = viewport.paper
  const model = viewport.model
  const paperW = paper.maxX - paper.minX
  const paperH = paper.maxY - paper.minY
  const centerX = (model.minX + model.maxX) / 2
  const centerY = (model.minY + model.maxY) / 2
  if (paperW <= EPS || paperH <= EPS) {
    return { x: centerX, y: centerY }
  }
  const localX = ((x - paper.minX) / paperW - 0.5) * (model.maxX - model.minX)
  const localY = ((y - paper.minY) / paperH - 0.5) * (model.maxY - model.minY)
  return rotateOffset(centerX, centerY, localX, localY, viewportTwist(viewport))
}

/**
 * Model-space WCS → paper-space WCS through a viewport.
 *
 * Inverse of {@link paperPointToModel}. Degenerate model boxes return the
 * paper rectangle center.
 */
export function modelPointToPaper(
  viewport: AcExViewportSnapshot,
  x: number,
  y: number
): { x: number; y: number } {
  const paper = viewport.paper
  const model = viewport.model
  const modelW = model.maxX - model.minX
  const modelH = model.maxY - model.minY
  if (modelW <= EPS || modelH <= EPS) {
    return {
      x: (paper.minX + paper.maxX) / 2,
      y: (paper.minY + paper.maxY) / 2
    }
  }
  const centerX = (model.minX + model.maxX) / 2
  const centerY = (model.minY + model.maxY) / 2
  const local = unrotateOffset(
    x - centerX,
    y - centerY,
    viewportTwist(viewport)
  )
  const u = local.x / modelW + 0.5
  const v = local.y / modelH + 0.5
  return {
    x: paper.minX + u * (paper.maxX - paper.minX),
    y: paper.minY + v * (paper.maxY - paper.minY)
  }
}

function rotateOffset(
  centerX: number,
  centerY: number,
  localX: number,
  localY: number,
  twist: number
): { x: number; y: number } {
  if (Math.abs(twist) <= EPS) {
    return { x: centerX + localX, y: centerY + localY }
  }
  const cos = Math.cos(twist)
  const sin = Math.sin(twist)
  return {
    x: centerX + localX * cos - localY * sin,
    y: centerY + localX * sin + localY * cos
  }
}

function unrotateOffset(
  dx: number,
  dy: number,
  twist: number
): { x: number; y: number } {
  if (Math.abs(twist) <= EPS) {
    return { x: dx, y: dy }
  }
  const cos = Math.cos(twist)
  const sin = Math.sin(twist)
  return {
    x: dx * cos + dy * sin,
    y: -dx * sin + dy * cos
  }
}

/**
 * Scale from paper WCS to model WCS along X (used to convert a paper-space
 * snap aperture into model units).
 */
export function viewportPaperToModelScale(
  viewport: AcExViewportSnapshot
): number {
  const paperW = viewport.paper.maxX - viewport.paper.minX
  if (paperW <= EPS) return 1
  return (viewport.model.maxX - viewport.model.minX) / paperW
}

/**
 * Orthographic camera parameters that fill a CSS-pixel viewport rectangle
 * with `model` extents, matching `AcTrViewportView.zoomTo(viewBox, 1.0)`
 * where `_frustum = vpH / 2`.
 */
export function computeViewportCamera(
  model: AcExExtents,
  vpW: number,
  vpH: number
): {
  centerX: number
  centerY: number
  zoom: number
  frustum: number
  aspect: number
} {
  const spanX = Math.max(model.maxX - model.minX, EPS)
  const spanY = Math.max(model.maxY - model.minY, EPS)
  const frustum = Math.max(vpH, EPS) / 2
  const aspect = vpW / Math.max(vpH, EPS)
  const zoom = Math.min((2 * aspect * frustum) / spanX, (2 * frustum) / spanY)
  return {
    centerX: (model.minX + model.maxX) / 2,
    centerY: (model.minY + model.maxY) / 2,
    zoom,
    frustum,
    aspect
  }
}

/**
 * Clips a paper viewport's CSS rectangle to `clip` and returns the model-space
 * box that should fill the overlap.
 *
 * Zooming paper space can map a viewport to more CSS pixels than WebGL
 * `MAX_VIEWPORT_DIMS`. Clamping that rect shifts NDC (right-side content
 * appears in view) and further zoom draws nothing. The on-screen intersection
 * stays within GPU limits.
 *
 * The CSS clip is mapped onto the DCS view box. Do not send corners through
 * {@link paperPointToModel}: that applies twist, and the renderer already
 * applies twist after fitting the camera.
 *
 * @returns On-canvas CSS rect and matching model extents, or `null` when the
 *   viewport is fully outside `clip` or has an empty mapping.
 */
export function computeOnscreenPaperViewportPass(
  viewport: AcExViewportSnapshot,
  cssVp: AcExCssRect,
  clip: AcExCssRect
): { hit: AcExCssRect; model: AcExExtents } | null {
  const hit = acexIntersectCssRects(cssVp, clip)
  if (!hit) return null
  const model = acexCssRectToWcsBox(hit, viewport.model, cssVp)
  if (
    model.maxX - model.minX <= EPS ||
    model.maxY - model.minY <= EPS ||
    !Number.isFinite(model.minX) ||
    !Number.isFinite(model.minY) ||
    !Number.isFinite(model.maxX) ||
    !Number.isFinite(model.maxY)
  ) {
    return null
  }
  return { hit, model }
}

/**
 * Top-most viewport whose interior contains `(x, y)`, skipping the border
 * band used for frame selection. Search is last-to-first so later DXF
 * viewports (typically drawn on top) win.
 */
export function findDrillThroughViewport(
  viewports: readonly AcExViewportSnapshot[] | undefined,
  x: number,
  y: number,
  borderTolerance: number
): AcExViewportSnapshot | undefined {
  if (!viewports || viewports.length === 0) return undefined
  for (let i = viewports.length - 1; i >= 0; i--) {
    const viewport = viewports[i]!
    if (!viewportContainsPaperPoint(viewport, x, y)) continue
    if (viewportIsNearPaperBorder(viewport, x, y, borderTolerance)) continue
    return viewport
  }
  return undefined
}

/**
 * `true` when any exported paper layout has at least one user viewport.
 */
export function snapshotHasPaperViewports(
  layouts: ReadonlyArray<{ viewports?: AcExViewportSnapshot[] }>
): boolean {
  return layouts.some(
    layout => layout.viewports != null && layout.viewports.length > 0
  )
}
