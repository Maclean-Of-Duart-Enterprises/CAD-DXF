/**
 * Builds {@link AcExOsnapCatalog} from an open `AcDbDatabase`.
 *
 * Walks layout block table records recursively, expands `AcDbBlockReference`
 * (INSERT) with full insertion transforms, and emits compact analytic primitives
 * for the offline HTML viewer. Straight drawing-line edges are omitted (they
 * duplicate display {@link AcExLineBatch} data). Circle/arc/ellipse/spline/point
 * remain so measurement-grade analytic snap survives tessellation. Fill/frame
 * boundaries that are drawn as meshes (hatch, TRACE/SOLID, IMAGE clip, OLE,
 * and wide LWPOLYLINE centerlines) are stored as compact
 * {@link AcExOsnapPathPrimitive} records.
 *
 * @packageDocumentation
 */

import {
  AcDb2dPolyline,
  AcDb3dPolyline,
  AcDbArc,
  AcDbAttribute,
  AcDbBlockReference,
  type AcDbBlockTableRecord,
  AcDbCircle,
  type AcDbDatabase,
  AcDbDimension,
  AcDbEllipse,
  AcDbEntity,
  AcDbFace,
  AcDbHatch,
  AcDbLeader,
  AcDbLine,
  AcDbMLeader,
  type AcDbMLeaderLeader,
  type AcDbMLeaderLine,
  AcDbMLine,
  AcDbMText,
  type AcDbObjectId,
  AcDbOle2Frame,
  AcDbPoint,
  AcDbPolyline,
  AcDbRasterImage,
  AcDbRay,
  AcDbSolid,
  AcDbSpline,
  AcDbTable,
  AcDbText,
  AcDbTrace,
  AcDbXline,
  AcGeCircArc2d,
  AcGeEllipseArc2d,
  AcGeLine2d,
  AcGeLoop2d,
  type AcGeLoop2dType,
  type AcGeMatrix3d,
  type AcGePoint3dLike,
  AcGePolyline2d,
  AcGeTol,
  type AcGeVector3dLike,
  FLOAT_TOL,
  TAU
} from '@mlightcad/data-model'
import * as THREE from 'three'

import { wcsPointToOcsArcAngle } from './AcExOsnapPrimitiveToAcGe'
import type {
  AcExOsnapArcPrimitive,
  AcExOsnapCatalog,
  AcExOsnapCirclePrimitive,
  AcExOsnapEllipsePrimitive,
  AcExOsnapPrimitive,
  AcExOsnapSplinePrimitive
} from './AcExOsnapPrimitiveTypes'

/** Vertex used when packing a fill/frame {@link AcExOsnapPathPrimitive}. */
type AcExOsnapPathVertex = AcGePoint3dLike & { bulge?: number }

/** Maps entity extrusion normal to arc/circle winding sign. @internal */
function normalSignFromVector(normal: AcGeVector3dLike): 1 | -1 {
  return normal.z >= 0 ? 1 : -1
}

/**
 * Serializes a WCS circular arc using OCS angles expected by HTML snap.
 *
 * Clockwise `AcGeCircArc2d` getters Y-mirror public angles; HTML reconstruction
 * X-mirrors when `normalSign` is `-1`. Invert {@link wcsPointToOcsArcAngle}
 * from the actual endpoints so both CCW and CW bulges round-trip.
 */
function pushGeCircArc(
  out: AcExOsnapPrimitive[],
  layer: string,
  arc: AcGeCircArc2d
) {
  if (!(arc.radius > 0) || !Number.isFinite(arc.radius)) return
  const normalSign: 1 | -1 = arc.clockwise ? -1 : 1
  const cx = arc.center.x
  const cy = arc.center.y
  out.push({
    kind: 'arc',
    layer,
    cx,
    cy,
    r: arc.radius,
    startAngle: wcsPointToOcsArcAngle(
      cx,
      cy,
      arc.startPoint.x,
      arc.startPoint.y,
      normalSign
    ),
    endAngle: wcsPointToOcsArcAngle(
      cx,
      cy,
      arc.endPoint.x,
      arc.endPoint.y,
      normalSign
    ),
    normalSign
  })
}

/** Applies a 4×4 layout/block matrix to a 3D point; returns XY. @internal */
function transformPoint(
  matrix: THREE.Matrix4,
  p: AcGePoint3dLike
): { x: number; y: number } {
  const v = new THREE.Vector3(p.x, p.y, p.z ?? 0).applyMatrix4(matrix)
  return { x: v.x, y: v.y }
}

/**
 * Converts an {@link AcGeMatrix3d} (or compatible matrix) to `THREE.Matrix4`.
 *
 * Block and dimension transforms from `@mlightcad/data-model` are `AcGeMatrix3d`
 * instances. They share column-major `elements` with Three.js but are not
 * `THREE.Matrix4` subclasses, so they must be copied before use with Three APIs
 * that rely on matrix type checks.
 *
 * @internal
 */
function acGeMatrix3dToThree(matrix: AcGeMatrix3d): THREE.Matrix4 {
  const e = matrix.elements
  return new THREE.Matrix4(
    e[0],
    e[4],
    e[8],
    e[12],
    e[1],
    e[5],
    e[9],
    e[13],
    e[2],
    e[6],
    e[10],
    e[14],
    e[3],
    e[7],
    e[11],
    e[15]
  )
}

/** Composes parent and child layout / INSERT / dimension-block transforms. @internal */
function composeTransforms(
  parent: THREE.Matrix4,
  child: AcGeMatrix3d
): THREE.Matrix4 {
  return new THREE.Matrix4().multiplyMatrices(
    parent,
    acGeMatrix3dToThree(child)
  )
}

/** Applies a 4×4 matrix to a direction vector (no translation); returns normalized XY. @internal */
function transformVector(
  matrix: THREE.Matrix4,
  v: AcGeVector3dLike
): { x: number; y: number } {
  const out = new THREE.Vector3(v.x, v.y, v.z ?? 0)
    .transformDirection(matrix)
    .normalize()
  return { x: out.x, y: out.y }
}

/**
 * Returns whether the XY scale factors of `matrix` are equal.
 *
 * Circles/arcs stay circular only under uniform XY scale; otherwise they are
 * exported as {@link AcExOsnapEllipsePrimitive}.
 *
 * @internal
 */
function scaleIsUniform(matrix: THREE.Matrix4): boolean {
  const sx = new THREE.Vector3(
    matrix.elements[0],
    matrix.elements[1],
    matrix.elements[2]
  ).length()
  const sy = new THREE.Vector3(
    matrix.elements[4],
    matrix.elements[5],
    matrix.elements[6]
  ).length()
  return AcGeTol.equal(sx, sy, FLOAT_TOL * Math.max(sx, sy, 1))
}

/**
 * Resolves the block table record (BTR) that owns a layout's geometry.
 *
 * {@link buildOsnapCatalog} walks this BTR recursively to emit analytic snap
 * primitives. Lookup tries, in order:
 *
 * 1. {@link AcDbBlockTable.getIdAt} with `layoutBtrId`
 * 2. Linear scan of the block table comparing {@link AcDbObjectId}
 * 3. Model-space BTR when `layoutBtrId` matches {@link AcDbBlockTable.modelSpace}
 *
 * @param database - Open drawing whose block table is searched.
 * @param layoutBtrId - Object id of the layout's owning block table record
 *   (same value stored on {@link AcExLayoutSnapshot.btrId}).
 * @returns The matching BTR, or `undefined` when no block can be resolved.
 * @internal
 */
function resolveLayoutBlock(
  database: AcDbDatabase,
  layoutBtrId: string
): AcDbBlockTableRecord | undefined {
  const direct = database.tables.blockTable.getIdAt(layoutBtrId)
  if (direct) {
    return direct
  }
  for (const block of database.tables.blockTable.newIterator()) {
    if (block.objectId === layoutBtrId) {
      return block
    }
  }
  const modelSpace = database.tables.blockTable.modelSpace
  if (modelSpace.objectId === layoutBtrId) {
    return modelSpace
  }
  return undefined
}

/**
 * Type guard for CAD line entities across `@mlightcad/data-model` versions.
 *
 * Prefer {@link AcDbLine} via `instanceof` when available. Some runtime builds
 * expose LINE entities with `type === 'LINE'` (or `'Line'`) and `startPoint` /
 * `endPoint` fields without registering the `AcDbLine` constructor, which would
 * otherwise be skipped during catalog export.
 *
 * @param entity - Candidate entity from a layout BTR iterator.
 * @returns `true` when the entity carries two geometric endpoints suitable for
 *   {@link AcExOsnapLinePrimitive} export.
 * @internal
 */
function isLineLikeEntity(entity: AcDbEntity): entity is AcDbEntity & {
  startPoint: AcGePoint3dLike
  endPoint: AcGePoint3dLike
} {
  if (entity instanceof AcDbLine) {
    return true
  }
  const candidate = entity as {
    type?: string
    startPoint?: AcGePoint3dLike
    endPoint?: AcGePoint3dLike
  }
  return (
    (candidate.type === 'LINE' || candidate.type === 'Line') &&
    candidate.startPoint != null &&
    candidate.endPoint != null
  )
}

/**
 * Appends one {@link AcExOsnapLinePrimitive} from a line-like database entity.
 *
 * Transforms {@link AcDbLine.startPoint} / {@link AcDbLine.endPoint} (or equivalent
 * duck-typed fields) into WCS via `matrix`, then delegates to {@link pushLine}.
 *
 * @param out - Primitive array mutated by {@link visitEntity}.
 * @param layer - Effective layer after block layer-0 inheritance.
 * @param matrix - Accumulated layout / INSERT transform.
 * @param entity - Line entity validated by {@link isLineLikeEntity}.
 * @internal
 */
function pushLineEntity(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  entity: AcDbEntity & {
    startPoint: AcGePoint3dLike
    endPoint: AcGePoint3dLike
  }
) {
  pushLine(out, layer, matrix, entity.startPoint, entity.endPoint)
}

/** Block reference shape used for recursive osnap traversal. @internal */
type AcExBlockReferenceLike = AcDbEntity & {
  blockTableRecord: AcDbBlockTableRecord | undefined
  blockName?: string
  getFullInsertionTransform(): AcGeMatrix3d
  columnCount?: number
  rowCount?: number
  columnSpacing?: number
  rowSpacing?: number
  attributeIterator?: () => Iterable<AcDbEntity> & {
    toArray?: () => AcDbEntity[]
  }
}

/** Dimension entity shape whose geometry lives in an anonymous block. @internal */
type AcExDimensionLike = AcDbDimension & {
  getFullDimBlockTransform(): AcGeMatrix3d
}

/**
 * Resolves the block table record referenced by an INSERT entity.
 *
 * Prefer {@link AcExBlockReferenceLike.blockTableRecord} when the entity is
 * database-backed; fall back to `blockName` on the export database.
 *
 * @internal
 */
function resolveBlockReferenceBlock(
  entity: AcExBlockReferenceLike,
  database: AcDbDatabase
): AcDbBlockTableRecord | undefined {
  return (
    entity.blockTableRecord ??
    (entity.blockName
      ? database.tables.blockTable.getAt(entity.blockName)
      : undefined)
  )
}

/**
 * Resolves the anonymous block referenced by a dimension entity.
 *
 * @internal
 */
function resolveDimensionBlock(
  entity: AcExDimensionLike,
  database: AcDbDatabase
): AcDbBlockTableRecord | undefined {
  const dimBlockId = entity.dimBlockId
  return dimBlockId ? database.tables.blockTable.getAt(dimBlockId) : undefined
}

/**
 * Resolves the anonymous block referenced by a table entity.
 *
 * Prefers {@link AcDbBlockReference.blockTableRecord}; falls back to
 * {@link AcDbTable.owningBlockRecordId} from imported DXF/DWG files.
 *
 * @internal
 */
function resolveTableBlock(
  entity: AcDbTable,
  database: AcDbDatabase
): AcDbBlockTableRecord | undefined {
  const asBlockRef = entity as unknown as AcExBlockReferenceLike
  const resolved = resolveBlockReferenceBlock(asBlockRef, database)
  if (resolved) {
    return resolved
  }
  const owningBlockId = entity.owningBlockRecordId
  return owningBlockId
    ? database.tables.blockTable.getAt(owningBlockId)
    : undefined
}

/** Returns the full INSERT transform for block/table entities. @internal */
function blockInsertTransform(entity: AcDbBlockReference): AcGeMatrix3d {
  return (
    entity as unknown as AcExBlockReferenceLike
  ).getFullInsertionTransform()
}

/** Returns whether a block table record contains at least one entity. @internal */
function blockHasEntities(block: AcDbBlockTableRecord): boolean {
  for (const _entity of block.newIterator()) {
    return true
  }
  return false
}

/**
 * Raster image shape used to read {@link AcDbRasterImage.boundaryPath}.
 * @internal
 */
type AcExRasterImageLike = AcDbRasterImage & {
  boundaryPath(): AcGePoint3dLike[]
}

/**
 * Detects block references across data-model versions (`AcDbBlockReference`,
 * `AcDbBlockReference2`, etc.) without relying on `instanceof`.
 *
 * @internal
 */
function isBlockReferenceEntity(
  entity: AcDbEntity
): entity is AcExBlockReferenceLike {
  return (
    typeof (entity as { getFullInsertionTransform?: unknown })
      .getFullInsertionTransform === 'function' && 'blockTableRecord' in entity
  )
}

/**
 * Line primitives are intentionally not exported into the HTML OSNAP catalog.
 *
 * Straight edges duplicate {@link AcExLineBatch} geometry already shipped for
 * display. The offline viewer rebuilds line snap from those batches after
 * geometry loads (see {@link AcExOsnapIndex.rebuildAsync}).
 *
 * Curve entities (arc / circle / ellipse / spline) and points still go through
 * dedicated push helpers so measurement-grade analytic snap is preserved.
 *
 * @internal
 */
function pushLine(
  _out: AcExOsnapPrimitive[],
  _layer: string,
  _matrix: THREE.Matrix4,
  _start: AcGePoint3dLike,
  _end: AcGePoint3dLike
) {
  // no-op — see function doc
}

/**
 * Ray / xline extents are also omitted from the catalog; finite display
 * segments in lineBatches cover practical endpoint / nearest snap.
 *
 * @internal
 */
function pushDirectedLine(
  _out: AcExOsnapPrimitive[],
  _layer: string,
  _matrix: THREE.Matrix4,
  _base: AcGePoint3dLike,
  _unitDir: AcGeVector3dLike,
  _bidirectional: boolean
) {
  // no-op — see function doc
}

/**
 * Packs a fill/frame boundary as one {@link AcExOsnapPathPrimitive}.
 *
 * Mesh-drawn entities (hatch, TRACE/SOLID, IMAGE clip, OLE, wide LWPOLYLINE)
 * have no edges in {@link AcExLineBatch}; this keeps their outline / centerline
 * in ACEO without exploding every edge into a `line` primitive.
 *
 * Bulge is invariant only under similarity. Vertices are transformed first;
 * under reflection the bulge sign flips (`det2d < 0`). Under non-uniform
 * scale/shear a circular bulge becomes elliptical, so the edge degrades to a
 * chord — matching the former hatch circular-arc boundary fallback.
 *
 * @internal
 */
function pushCatalogPath(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  vertices: AcExOsnapPathVertex[],
  closed: boolean
) {
  if (vertices.length < 2) return
  const uniform = scaleIsUniform(matrix)
  const det2d =
    matrix.elements[0]! * matrix.elements[5]! -
    matrix.elements[4]! * matrix.elements[1]!
  const bulgeSign = det2d < 0 ? -1 : 1
  const packed: number[] = []
  for (const vertex of vertices) {
    const p = transformPoint(matrix, vertex)
    let bulge = vertex.bulge ?? 0
    if (AcGeTol.isPositive(Math.abs(bulge))) {
      bulge = uniform ? bulge * bulgeSign : 0
    }
    packed.push(p.x, p.y, bulge)
  }
  out.push({ kind: 'path', layer, closed, vertices: packed })
}

function samePoint2d(a: AcGePoint3dLike, b: AcGePoint3dLike): boolean {
  return AcGeTol.equal(a.x, b.x) && AcGeTol.equal(a.y, b.y)
}

function circArc2dBulge(arc: AcGeCircArc2d): number {
  return (arc.clockwise ? -1 : 1) * Math.tan(arc.deltaAngle / 4)
}

function appendPathEdge(
  verts: AcExOsnapPathVertex[],
  start: AcGePoint3dLike,
  end: AcGePoint3dLike,
  bulge: number
) {
  if (verts.length === 0) {
    verts.push({ x: start.x, y: start.y, z: start.z ?? 0, bulge })
    verts.push({ x: end.x, y: end.y, z: end.z ?? 0, bulge: 0 })
    return
  }
  const last = verts[verts.length - 1]!
  if (samePoint2d(last, start)) {
    last.bulge = bulge
  } else {
    last.bulge = 0
    verts.push({ x: start.x, y: start.y, z: start.z ?? 0, bulge })
  }
  verts.push({ x: end.x, y: end.y, z: end.z ?? 0, bulge: 0 })
}

function finalizePathVertices(verts: AcExOsnapPathVertex[]): AcExOsnapPathVertex[] {
  if (
    verts.length >= 2 &&
    samePoint2d(verts[0]!, verts[verts.length - 1]!)
  ) {
    verts.pop()
  }
  return verts
}

/**
 * Appends line segments connecting an ordered vertex path.
 *
 * @internal
 */
function pushVertexPath(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  vertices: AcGePoint3dLike[],
  closed: boolean
) {
  if (vertices.length < 2) return
  const segmentCount = closed ? vertices.length : vertices.length - 1
  for (let i = 0; i < segmentCount; i++) {
    pushLine(
      out,
      layer,
      matrix,
      vertices[i]!,
      vertices[(i + 1) % vertices.length]!
    )
  }
}

/**
 * Builds the MLINE reference path (`startPosition` + segment vertices).
 *
 * Matches {@link AcDbMLine.subGetOsnapPoints}, which snaps to the center path
 * rather than offset style-element geometry.
 *
 * @internal
 */
function pushMLine(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  entity: AcDbMLine
) {
  const path: AcGePoint3dLike[] = [entity.startPosition]
  for (const segment of entity.segments) {
    path.push(segment.position)
  }
  pushVertexPath(out, layer, matrix, path, entity.closed)
}

/**
 * Resolves drawable leader-line vertices the same way as
 * `AcDbMLeader.getLeaderLineDrawPoints`.
 *
 * @internal
 */
function resolveMLeaderLineDrawPoints(
  entity: AcDbMLeader,
  leader: AcDbMLeaderLeader,
  line: AcDbMLeaderLine
): AcGePoint3dLike[] {
  if (line.vertices.length >= 2) {
    return line.vertices
  }
  if (line.vertices.length === 0) {
    return []
  }
  const start = line.vertices[0]!
  const end =
    leader.lastLeaderLinePoint ??
    leader.landingPoint ??
    entity.landingPoint ??
    entity.contentBasePosition
  if (!end) {
    return line.vertices
  }
  const dx = start.x - end.x
  const dy = start.y - end.y
  const dz = (start.z ?? 0) - (end.z ?? 0)
  if (Math.hypot(dx, dy, dz) <= FLOAT_TOL) {
    return line.vertices
  }
  return [start, end]
}

/**
 * Exports multileader leader segments and annotation anchor points.
 *
 * Leader geometry follows {@link AcDbMLeader.subGetOsnapPoints}; anchor points
 * mirror insertion snaps on MText/block content.
 *
 * @internal
 */
function pushMLeader(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  entity: AcDbMLeader
) {
  for (const leader of entity.leaders) {
    for (const line of leader.leaderLines) {
      const drawPoints = resolveMLeaderLineDrawPoints(entity, leader, line)
      pushVertexPath(out, layer, matrix, drawPoints, false)
    }
  }

  const pushAnchor = (point: AcGePoint3dLike | undefined) => {
    if (!point) return
    const p = transformPoint(matrix, point)
    out.push({ kind: 'point', layer, x: p.x, y: p.y })
  }

  pushAnchor(entity.contentBasePosition)
  pushAnchor(entity.mtextContent?.anchorPoint)
  pushAnchor(entity.blockContent?.position)
}

/**
 * Decomposes `AcDb2dPolyline` into line and arc primitives (legacy POLYLINE).
 *
 * @internal
 */
function push2dPolyline(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  entity: AcDb2dPolyline
) {
  const count = entity.numberOfVertices
  if (count < 2) return

  const elevation = entity.elevation
  const segmentCount = entity.closed ? count : count - 1
  for (let i = 0; i < segmentCount; i++) {
    const start2d = entity.getPointAt(i)
    const end2d = entity.getPointAt((i + 1) % count)
    const bulge = entity.getBulgeAt(i)
    const start = { x: start2d.x, y: start2d.y, z: elevation }
    const end = { x: end2d.x, y: end2d.y, z: elevation }
    if (AcGeTol.isPositive(Math.abs(bulge))) {
      const startW = transformPoint(matrix, start)
      const endW = transformPoint(matrix, end)
      pushGeCircArc(out, layer, new AcGeCircArc2d(startW, endW, bulge))
    } else {
      pushLine(out, layer, matrix, start, end)
    }
  }
}

/** Appends a WCS circle primitive (uniform scale on radius). @internal */
function pushCircle(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  center: AcGePoint3dLike,
  radius: number,
  normal: AcGeVector3dLike
) {
  const c = transformPoint(matrix, center)
  const sx = new THREE.Vector3(
    matrix.elements[0],
    matrix.elements[1],
    matrix.elements[2]
  ).length()
  const prim: AcExOsnapCirclePrimitive = {
    kind: 'circle',
    layer,
    cx: c.x,
    cy: c.y,
    r: radius * sx,
    normalSign: normalSignFromVector(normal)
  }
  out.push(prim)
}

/** Appends a WCS arc primitive from `AcDbArc` (uniform XY scale). @internal */
function pushArc(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  entity: AcDbArc
) {
  const center = transformPoint(matrix, entity.center)
  const sx = new THREE.Vector3(
    matrix.elements[0],
    matrix.elements[1],
    matrix.elements[2]
  ).length()
  const prim: AcExOsnapArcPrimitive = {
    kind: 'arc',
    layer,
    cx: center.x,
    cy: center.y,
    r: entity.radius * sx,
    startAngle: entity.startAngle,
    endAngle: entity.endAngle,
    normalSign: normalSignFromVector(entity.normal)
  }
  out.push(prim)
}

/** Appends a WCS ellipse primitive from `AcDbEllipse`. @internal */
function pushEllipse(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  entity: AcDbEllipse
) {
  const center = transformPoint(matrix, entity.center)
  const geo = (entity as unknown as { _geo?: { majorAxis?: AcGeVector3dLike } })
    ._geo
  const majorAxis = geo?.majorAxis ?? { x: 1, y: 0, z: 0 }
  const axis = transformVector(matrix, majorAxis)
  const len = Math.hypot(axis.x, axis.y) || 1
  const sx = new THREE.Vector3(
    matrix.elements[0],
    matrix.elements[1],
    matrix.elements[2]
  ).length()
  const sy = new THREE.Vector3(
    matrix.elements[4],
    matrix.elements[5],
    matrix.elements[6]
  ).length()
  const prim: AcExOsnapEllipsePrimitive = {
    kind: 'ellipse',
    layer,
    cx: center.x,
    cy: center.y,
    majorX: axis.x / len,
    majorY: axis.y / len,
    majorR: entity.majorAxisRadius * sx,
    minorR: entity.minorAxisRadius * sy,
    startAngle: entity.startAngle,
    endAngle: entity.endAngle,
    closed: entity.closed,
    normalSign: normalSignFromVector(entity.normal)
  }
  out.push(prim)
}

/**
 * Appends a WCS spline primitive from `AcDbSpline` control/fit data.
 *
 * Reads internal `_geo` fields from the data model (control points, knots,
 * weights, degree). Skips the entity when no control points are available.
 *
 * @internal
 */
function pushSpline(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  entity: AcDbSpline
) {
  const geo = (
    entity as unknown as {
      _geo?: {
        degree?: number
        knots?: number[]
        weights?: number[]
        controlPoints?: AcGePoint3dLike[]
        fitPoints?: AcGePoint3dLike[]
        closed?: boolean
      }
    }
  )._geo
  if (!geo?.controlPoints?.length) return

  const controlPoints: number[] = []
  for (const cp of geo.controlPoints) {
    const p = transformPoint(matrix, cp)
    controlPoints.push(p.x, p.y)
  }

  const prim: AcExOsnapSplinePrimitive = {
    kind: 'spline',
    layer,
    controlPoints,
    degree: geo.degree ?? 3,
    knots: [...(geo.knots ?? [])],
    weights: [...(geo.weights ?? [])],
    closed: geo.closed ?? false
  }
  if (geo.fitPoints?.length) {
    prim.fitPoints = []
    for (const fp of geo.fitPoints) {
      const p = transformPoint(matrix, fp)
      prim.fitPoints.push(p.x, p.y)
    }
  }
  out.push(prim)
}

/**
 * Matches `AcDbPolyline` `WIDTH_EPSILON`: any start/end width above this
 * draws the whole LWPOLYLINE as a solid `area` mesh, not a `lineStrip`.
 */
const POLYLINE_WIDTH_EPSILON = 1e-6

type AcExLwPolylineVertex = AcExOsnapPathVertex & {
  startWidth?: number
  endWidth?: number
}

function readLwPolylineVertices(entity: AcDbPolyline): AcExLwPolylineVertex[] {
  const elevation = entity.elevation
  const runtimeVertices = (
    entity as unknown as {
      _geo?: {
        vertices?: Array<{
          x: number
          y: number
          bulge?: number
          startWidth?: number
          endWidth?: number
        }>
      }
    }
  )._geo?.vertices

  if (runtimeVertices && runtimeVertices.length > 1) {
    return runtimeVertices.map(vertex => ({
      x: vertex.x,
      y: vertex.y,
      z: elevation,
      bulge: vertex.bulge,
      startWidth: vertex.startWidth,
      endWidth: vertex.endWidth
    }))
  }

  return Array.from({ length: entity.numberOfVertices }, (_, i) => {
    const p = entity.getPoint2dAt(i)
    return { x: p.x, y: p.y, z: elevation, bulge: 0 as number | undefined }
  })
}

/**
 * True when the LWPOLYLINE is drawn as a wide mesh (`directBatchPrimitive`
 * `'area'`), matching {@link AcDbPolyline} `hasRenderableWidth`.
 */
function polylineHasRenderableWidth(vertices: AcExLwPolylineVertex[]): boolean {
  return vertices.some(vertex => {
    const startWidth = Math.max(0, vertex.startWidth ?? 0)
    const endWidth = Math.max(0, vertex.endWidth ?? 0)
    return (
      startWidth > POLYLINE_WIDTH_EPSILON || endWidth > POLYLINE_WIDTH_EPSILON
    )
  })
}

/**
 * Decomposes `AcDbPolyline` into ACEO primitives.
 *
 * Thin polylines (`lineStrip`) keep bulge arcs in ACEO and omit straight
 * edges (those duplicate {@link AcExLineBatch}). Wide polylines are drawn as
 * a filled mesh from the width profile, so they never appear in lineBatches —
 * their **centerline** (vertices + bulge, the same geometry
 * {@link AcDbPolyline.subGetOsnapPoints} snaps to) is stored as one
 * {@link AcExOsnapPathPrimitive}.
 *
 * @internal
 */
function pushPolyline(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  entity: AcDbPolyline
) {
  const vertices = readLwPolylineVertices(entity)
  const count = vertices.length
  if (count < 2) return

  if (polylineHasRenderableWidth(vertices)) {
    pushCatalogPath(out, layer, matrix, vertices, entity.closed)
    return
  }

  const segmentCount = entity.closed ? count : count - 1
  for (let i = 0; i < segmentCount; i++) {
    const start = vertices[i]!
    const end = vertices[(i + 1) % count]!
    const bulge = start.bulge ?? 0
    if (AcGeTol.isPositive(Math.abs(bulge))) {
      const startW = transformPoint(matrix, start)
      const endW = transformPoint(matrix, end)
      pushGeCircArc(out, layer, new AcGeCircArc2d(startW, endW, bulge))
    } else {
      pushLine(out, layer, matrix, start, end)
    }
  }
}

/** Appends a WCS ellipse arc from a 2D ellipse arc at a fixed elevation. @internal */
function pushEllipseArc2dBoundary(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  arc: AcGeEllipseArc2d,
  elevation: number
) {
  const center = transformPoint(matrix, {
    x: arc.center.x,
    y: arc.center.y,
    z: elevation
  })
  const majorDir = transformVector(matrix, {
    x: Math.cos(arc.rotation),
    y: Math.sin(arc.rotation),
    z: 0
  })
  const len = Math.hypot(majorDir.x, majorDir.y) || 1
  const sx = new THREE.Vector3(
    matrix.elements[0],
    matrix.elements[1],
    matrix.elements[2]
  ).length()
  const sy = new THREE.Vector3(
    matrix.elements[4],
    matrix.elements[5],
    matrix.elements[6]
  ).length()
  out.push({
    kind: 'ellipse',
    layer,
    cx: center.x,
    cy: center.y,
    majorX: majorDir.x / len,
    majorY: majorDir.y / len,
    majorR: arc.majorAxisRadius * sx,
    minorR: arc.minorAxisRadius * sy,
    startAngle: arc.startAngle,
    endAngle: arc.endAngle,
    closed: false,
    normalSign: arc.clockwise ? -1 : 1
  })
}

/**
 * Exports one hatch boundary polyline loop (bulge-aware).
 *
 * Matches {@link AcDbHatch.subGetOsnapPoints} boundary traversal.
 *
 * @internal
 */
function pushHatchPolyline2d(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  polyline: AcGePolyline2d,
  elevation: number
) {
  const vertexCount = polyline.numberOfVertices
  if (vertexCount < 2) return

  const vertices: AcExOsnapPathVertex[] = []
  for (let index = 0; index < vertexCount; index++) {
    const point = polyline.getPointAt(index)
    vertices.push({
      x: point.x,
      y: point.y,
      z: elevation,
      bulge: polyline.vertices[index]?.bulge ?? 0
    })
  }
  pushCatalogPath(out, layer, matrix, vertices, polyline.closed)
}

/** Exports one hatch boundary loop (polyline or edge loop). @internal */
function pushHatchLoop(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  loop: AcGeLoop2dType,
  elevation: number
) {
  if (loop instanceof AcGePolyline2d) {
    pushHatchPolyline2d(out, layer, matrix, loop, elevation)
    return
  }

  if (!(loop instanceof AcGeLoop2d)) return

  const verts: AcExOsnapPathVertex[] = []
  let splitByEllipse = false
  const flushOpen = () => {
    const packed = finalizePathVertices(verts)
    if (packed.length >= 2) {
      pushCatalogPath(out, layer, matrix, packed, false)
    }
    verts.length = 0
  }

  for (const curve of loop.curves) {
    if (curve instanceof AcGeLine2d) {
      appendPathEdge(
        verts,
        {
          x: curve.startPoint.x,
          y: curve.startPoint.y,
          z: elevation
        },
        {
          x: curve.endPoint.x,
          y: curve.endPoint.y,
          z: elevation
        },
        0
      )
    } else if (curve instanceof AcGeCircArc2d) {
      appendPathEdge(
        verts,
        {
          x: curve.startPoint.x,
          y: curve.startPoint.y,
          z: elevation
        },
        {
          x: curve.endPoint.x,
          y: curve.endPoint.y,
          z: elevation
        },
        circArc2dBulge(curve)
      )
    } else if (curve instanceof AcGeEllipseArc2d) {
      splitByEllipse = true
      flushOpen()
      pushEllipseArc2dBoundary(out, layer, matrix, curve, elevation)
    }
  }

  const packed = finalizePathVertices(verts)
  if (packed.length >= 2) {
    pushCatalogPath(out, layer, matrix, packed, !splitByEllipse)
  }
}

/**
 * Exports hatch boundary loops as compact path primitives (plus ellipse edges).
 *
 * Reads internal `_geo.loops` from the data model, mirroring
 * {@link AcDbHatch.subGetOsnapPoints}.
 *
 * @internal
 */
function pushHatch(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  entity: AcDbHatch
) {
  const loops = (
    entity as unknown as {
      _geo?: { loops?: ReadonlyArray<AcGeLoop2dType> }
    }
  )._geo?.loops
  if (!loops?.length) return

  const elevation = entity.elevation
  for (const loop of loops) {
    pushHatchLoop(out, layer, matrix, loop, elevation)
  }
}

/**
 * Exports procedural table grid lines when no anonymous block geometry exists.
 *
 * Grid layout follows {@link AcDbTable.subWorldDraw} local coordinates.
 *
 * @internal
 */
function pushTableGrid(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  entity: AcDbTable
) {
  const tableMatrix = composeTransforms(matrix, blockInsertTransform(entity))

  const columnXs = [0]
  for (let column = 0; column < entity.numColumns; column++) {
    columnXs.push(columnXs[column]! + entity.columnWidth(column))
  }

  const rowYs = [0]
  for (let row = 0; row < entity.numRows; row++) {
    rowYs.push(rowYs[row]! - entity.rowHeight(row))
  }

  const totalWidth = columnXs[columnXs.length - 1]!
  const totalHeight = rowYs[rowYs.length - 1]!

  for (const y of rowYs) {
    pushLine(
      out,
      layer,
      tableMatrix,
      { x: 0, y, z: 0 },
      { x: totalWidth, y, z: 0 }
    )
  }

  for (const x of columnXs) {
    pushLine(
      out,
      layer,
      tableMatrix,
      { x, y: 0, z: 0 },
      { x, y: totalHeight, z: 0 }
    )
  }
}

/**
 * Visits a table entity: anonymous block content when present, else grid lines.
 *
 * @internal
 */
function visitTableEntity(
  entity: AcDbTable,
  matrix: THREE.Matrix4,
  insertLayer: string,
  out: AcExOsnapPrimitive[],
  blockStack: Set<AcDbObjectId>,
  database: AcDbDatabase,
  includeLayer?: (layerName: string) => boolean,
  exportFillBoundaries = true
) {
  const layer = effectiveLayer(entity.layer, insertLayer)
  if (includeLayer && !includeLayer(layer)) {
    return
  }
  const block = resolveTableBlock(entity, database)
  if (block && !blockStack.has(block.objectId) && blockHasEntities(block)) {
    blockStack.add(block.objectId)
    const nested = composeTransforms(matrix, blockInsertTransform(entity))
    visitBlock(
      block,
      nested,
      layer,
      out,
      blockStack,
      database,
      includeLayer,
      exportFillBoundaries
    )
    blockStack.delete(block.objectId)
    return
  }

  pushTableGrid(out, layer, matrix, entity)
  const insertion = transformPoint(matrix, entity.position)
  out.push({ kind: 'point', layer, x: insertion.x, y: insertion.y })
}

/**
 * Exports raster image clip/frame boundary and insertion point.
 *
 * Uses {@link AcDbRasterImage.boundaryPath} to match live-viewer osnap behavior.
 *
 * @internal
 */
function pushRasterImage(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  entity: AcDbRasterImage
) {
  let boundary = (entity as AcExRasterImageLike).boundaryPath()
  if (boundary.length > 1) {
    const first = boundary[0]!
    const last = boundary[boundary.length - 1]!
    if (
      first.x === last.x &&
      first.y === last.y &&
      (first.z ?? 0) === (last.z ?? 0)
    ) {
      boundary = boundary.slice(0, -1)
    }
  }
  if (boundary.length >= 2) {
    pushCatalogPath(out, layer, matrix, boundary, true)
  }

  const insertion = transformPoint(matrix, entity.position)
  out.push({ kind: 'point', layer, x: insertion.x, y: insertion.y })
}

/**
 * Exports OLE2FRAME rectangle corners and insertion (upper-left) point.
 *
 * @internal
 */
function pushOle2Frame(
  out: AcExOsnapPrimitive[],
  layer: string,
  matrix: THREE.Matrix4,
  entity: AcDbOle2Frame
) {
  const rect = entity.position()
  pushCatalogPath(
    out,
    layer,
    matrix,
    [rect.upperLeft, rect.upperRight, rect.lowerRight, rect.lowerLeft],
    true
  )
  const insertion = transformPoint(matrix, entity.getLocation())
  out.push({ kind: 'point', layer, x: insertion.x, y: insertion.y })
}

function iterInsertAttributes(entity: AcExBlockReferenceLike): AcDbEntity[] {
  const iterator = entity.attributeIterator?.()
  if (!iterator) return []
  if (typeof iterator.toArray === 'function') {
    return iterator.toArray()
  }
  return [...iterator]
}

/**
 * Resolves AutoCAD layer-0 inheritance inside blocks.
 *
 * @param entityLayer - Layer name stored on the entity in the block definition.
 * @param insertLayer - Layer of the owning INSERT (or layout default).
 * @returns Layer name written onto exported primitives.
 * @internal
 */
function effectiveLayer(entityLayer: string, insertLayer: string): string {
  return entityLayer === '0' ? insertLayer : entityLayer
}

/**
 * Visits one database entity and appends zero or more WCS primitives.
 *
 * Recurses into {@link AcDbBlockReference} with accumulated transforms.
 * Skips invisible entities and breaks cycles via `blockStack`.
 *
 * @internal
 */
function visitEntity(
  entity: AcDbEntity,
  matrix: THREE.Matrix4,
  insertLayer: string,
  out: AcExOsnapPrimitive[],
  blockStack: Set<AcDbObjectId>,
  database: AcDbDatabase,
  includeLayer?: (layerName: string) => boolean,
  exportFillBoundaries = true
) {
  if (!entity.visibility) return

  const layer = effectiveLayer(entity.layer, insertLayer)
  if (includeLayer && !includeLayer(layer)) {
    return
  }

  if (entity instanceof AcDbTable) {
    visitTableEntity(
      entity,
      matrix,
      insertLayer,
      out,
      blockStack,
      database,
      includeLayer,
      exportFillBoundaries
    )
    return
  }

  if (isBlockReferenceEntity(entity)) {
    const block = resolveBlockReferenceBlock(entity, database)
    if (!block || blockStack.has(block.objectId)) return
    blockStack.add(block.objectId)
    const insertXform = entity.getFullInsertionTransform()
    const cols = Math.max(1, entity.columnCount ?? 1)
    const rows = Math.max(1, entity.rowCount ?? 1)
    const colSp = entity.columnSpacing ?? 0
    const rowSp = entity.rowSpacing ?? 0
    const blockInsertLayer = effectiveLayer(entity.layer, insertLayer)
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const nested = composeTransforms(matrix, insertXform)
        if (col !== 0 || row !== 0) {
          nested.multiply(
            new THREE.Matrix4().makeTranslation(col * colSp, row * rowSp, 0)
          )
        }
        const ins = transformPoint(nested, { x: 0, y: 0, z: 0 })
        out.push({
          kind: 'point',
          layer: blockInsertLayer,
          x: ins.x,
          y: ins.y
        })
        visitBlock(
          block,
          nested,
          blockInsertLayer,
          out,
          blockStack,
          database,
          includeLayer,
          exportFillBoundaries
        )
      }
    }
    for (const attrib of iterInsertAttributes(entity)) {
      if (
        attrib instanceof AcDbAttribute
          ? attrib.isInvisible
          : Boolean((attrib as { isInvisible?: boolean }).isInvisible)
      ) {
        continue
      }
      visitEntity(
        attrib,
        matrix,
        blockInsertLayer,
        out,
        blockStack,
        database,
        includeLayer,
        exportFillBoundaries
      )
    }
    blockStack.delete(block.objectId)
    return
  }

  if (entity instanceof AcDbDimension) {
    const dimension = entity as AcExDimensionLike
    const block = resolveDimensionBlock(dimension, database)
    if (!block || blockStack.has(block.objectId)) return
    blockStack.add(block.objectId)
    const nested = composeTransforms(
      matrix,
      dimension.getFullDimBlockTransform()
    )
    // Keep arrowhead vertices (SOLID / solid-fill HATCH) for snap. Extension
    // lines are still omitted because pushLine is a no-op for catalog export.
    visitBlock(
      block,
      nested,
      layer,
      out,
      blockStack,
      database,
      includeLayer,
      true
    )
    blockStack.delete(block.objectId)
    return
  }

  if (isLineLikeEntity(entity)) {
    pushLineEntity(out, layer, matrix, entity)
    return
  }

  if (entity instanceof AcDbCircle) {
    if (scaleIsUniform(matrix)) {
      pushCircle(
        out,
        layer,
        matrix,
        entity.center,
        entity.radius,
        entity.normal
      )
    } else {
      pushEllipse(out, layer, matrix, ellipseFromCircle(entity))
    }
    return
  }

  if (entity instanceof AcDbArc) {
    if (scaleIsUniform(matrix)) {
      pushArc(out, layer, matrix, entity)
    } else {
      pushEllipse(out, layer, matrix, ellipseFromArc(entity))
    }
    return
  }

  if (entity instanceof AcDbEllipse) {
    pushEllipse(out, layer, matrix, entity)
    return
  }

  if (entity instanceof AcDbSpline) {
    pushSpline(out, layer, matrix, entity)
    return
  }

  if (entity instanceof AcDbPolyline) {
    pushPolyline(out, layer, matrix, entity)
    return
  }

  if (entity instanceof AcDb2dPolyline) {
    push2dPolyline(out, layer, matrix, entity)
    return
  }

  if (entity instanceof AcDb3dPolyline) {
    const vertices: AcGePoint3dLike[] = []
    for (let i = 0; i < entity.numberOfVertices; i++) {
      vertices.push(entity.getPointAt(i))
    }
    pushVertexPath(out, layer, matrix, vertices, entity.closed)
    return
  }

  if (entity instanceof AcDbHatch) {
    if (exportFillBoundaries) {
      pushHatch(out, layer, matrix, entity)
    }
    return
  }

  if (entity instanceof AcDbRay) {
    pushDirectedLine(
      out,
      layer,
      matrix,
      entity.basePoint,
      entity.unitDir,
      false
    )
    return
  }

  if (entity instanceof AcDbXline) {
    pushDirectedLine(out, layer, matrix, entity.basePoint, entity.unitDir, true)
    return
  }

  if (entity instanceof AcDbSolid) {
    // Dimension arrowheads are SOLID entities inside anonymous dim blocks.
    // Always keep their vertices for endpoint / nearest snap — even when
    // visiting dim blocks with exportFillBoundaries=false (which skips TRACE
    // fills and other mesh boundaries that are not useful for snapping).
    pushCatalogPath(
      out,
      layer,
      matrix,
      [
        entity.getPointAt(0),
        entity.getPointAt(1),
        entity.getPointAt(3),
        entity.getPointAt(2)
      ],
      true
    )
    return
  }

  if (entity instanceof AcDbTrace) {
    if (exportFillBoundaries) {
      pushCatalogPath(
        out,
        layer,
        matrix,
        [
          entity.getPointAt(0),
          entity.getPointAt(1),
          entity.getPointAt(3),
          entity.getPointAt(2)
        ],
        true
      )
    }
    return
  }

  if (entity instanceof AcDbFace) {
    const vertices = entity.subGetGripPoints()
    if (vertices.length >= 2) {
      pushVertexPath(out, layer, matrix, vertices, vertices.length >= 3)
    }
    return
  }

  if (entity instanceof AcDbLeader) {
    const vertices = entity.vertices
    if (vertices.length >= 2) {
      pushVertexPath(out, layer, matrix, vertices, false)
    }
    return
  }

  if (entity instanceof AcDbMLine) {
    pushMLine(out, layer, matrix, entity)
    return
  }

  if (entity instanceof AcDbMLeader) {
    pushMLeader(out, layer, matrix, entity)
    return
  }

  if (entity instanceof AcDbText) {
    const p = transformPoint(matrix, entity.position)
    out.push({ kind: 'point', layer, x: p.x, y: p.y })
    return
  }

  if (entity instanceof AcDbMText) {
    const p = transformPoint(matrix, entity.location)
    out.push({ kind: 'point', layer, x: p.x, y: p.y })
    return
  }

  if (entity instanceof AcDbOle2Frame) {
    if (exportFillBoundaries) {
      pushOle2Frame(out, layer, matrix, entity)
    }
    return
  }

  if (entity instanceof AcDbRasterImage) {
    if (exportFillBoundaries) {
      pushRasterImage(out, layer, matrix, entity)
    }
    return
  }

  if (entity instanceof AcDbPoint) {
    const p = transformPoint(matrix, entity.position)
    out.push({ kind: 'point', layer, x: p.x, y: p.y })
  }
}

/** Iterates all entities in a block BTR. @internal */
function visitBlock(
  block: AcDbBlockTableRecord,
  matrix: THREE.Matrix4,
  insertLayer: string,
  out: AcExOsnapPrimitive[],
  blockStack: Set<AcDbObjectId>,
  database: AcDbDatabase,
  includeLayer?: (layerName: string) => boolean,
  exportFillBoundaries = true
) {
  for (const entity of block.newIterator()) {
    visitEntity(
      entity,
      matrix,
      insertLayer,
      out,
      blockStack,
      database,
      includeLayer,
      exportFillBoundaries
    )
  }
}

/** Converts a circle to a temporary ellipse for non-uniform block transforms. @internal */
function ellipseFromCircle(entity: AcDbCircle): AcDbEllipse {
  return new AcDbEllipse(
    entity.center,
    entity.normal,
    { x: 1, y: 0, z: 0 },
    entity.radius,
    entity.radius,
    0,
    TAU
  )
}

/** Converts an arc to a temporary ellipse for non-uniform block transforms. @internal */
function ellipseFromArc(entity: AcDbArc): AcDbEllipse {
  return new AcDbEllipse(
    entity.center,
    entity.normal,
    { x: 1, y: 0, z: 0 },
    entity.radius,
    entity.radius,
    entity.startAngle,
    entity.endAngle
  )
}

/**
 * Builds the object-snap catalog for one layout (model space or paper space).
 *
 * Traverses the layout's block table record (`layoutBtrId`), including all nested
 * `AcDbBlockReference` entities with full WCS transforms. Entities on layer `0`
 * inside blocks inherit the INSERT layer per AutoCAD rules.
 *
 * Supported entity types: `AcDbLine`, `AcDbCircle`, `AcDbArc`, `AcDbEllipse`,
 * `AcDbSpline`, `AcDbPolyline`, `AcDb2dPolyline`, `AcDb3dPolyline`, `AcDbHatch`,
 * `AcDbRay`, `AcDbXline`, `AcDbTrace`, `AcDbFace`, `AcDbLeader`, `AcDbMLine`,
 * `AcDbMLeader`, `AcDbText`, `AcDbMText`, `AcDbPoint`, `AcDbRasterImage`,
 * `AcDbOle2Frame`, `AcDbTable`, INSERT / MINSERT (with ATTRIB), and dimension
 * entities (`AcDbDimension` and subclasses via anonymous dim blocks). Hatch /
 * TRACE / SOLID / IMAGE / OLE fills are stored as `path` primitives. Dimension
 * arrowheads (SOLID entities or solid-fill HATCH inserts) keep their vertices
 * so tips remain snappable; straight dim lines still omit `line` kinds.
 *
 * @param database - Open drawing database (same instance used for HTML export).
 * @param layoutBtrId - Object id of the layout's owning block table record
 *   (e.g. model space BTR id from the renderer scene).
 * @returns Catalog of analytic curve/point/path primitives in WCS (no `line` kinds).
 *   Empty when the BTR id is unknown or the layout has no snap-capable curves.
 *
 * @example
 * ```ts
 * const osnap = buildOsnapCatalog(database, scene.modelSpaceBtrId)
 * layoutSnapshot.osnap = osnap
 * ```
 */
export interface AcExOsnapCatalogOptions {
  /** When set, only entities on layers for which this returns `true` are exported. */
  includeLayer?: (layerName: string) => boolean
}

export function buildOsnapCatalog(
  database: AcDbDatabase,
  layoutBtrId: string,
  options: AcExOsnapCatalogOptions = {}
): AcExOsnapCatalog {
  const block = resolveLayoutBlock(database, layoutBtrId)
  if (!block) {
    return { primitives: [] }
  }

  const primitives: AcExOsnapPrimitive[] = []
  const identity = new THREE.Matrix4()
  visitBlock(
    block,
    identity,
    '0',
    primitives,
    new Set(),
    database,
    options.includeLayer
  )
  // Belt-and-suspenders: never ship line kinds (they duplicate lineBatches).
  // Also drop non-finite coords so a single NaN polyline cannot poison the
  // offline RBush index the way it did in the main viewer.
  return {
    primitives: primitives.filter(
      primitive => primitive.kind !== 'line' && isFiniteOsnapPrimitive(primitive)
    )
  }
}

function isFiniteOsnapPrimitive(primitive: AcExOsnapPrimitive): boolean {
  switch (primitive.kind) {
    case 'line':
      return (
        Number.isFinite(primitive.x0) &&
        Number.isFinite(primitive.y0) &&
        Number.isFinite(primitive.x1) &&
        Number.isFinite(primitive.y1)
      )
    case 'circle':
      return (
        Number.isFinite(primitive.cx) &&
        Number.isFinite(primitive.cy) &&
        Number.isFinite(primitive.r)
      )
    case 'arc':
      return (
        Number.isFinite(primitive.cx) &&
        Number.isFinite(primitive.cy) &&
        Number.isFinite(primitive.r) &&
        Number.isFinite(primitive.startAngle) &&
        Number.isFinite(primitive.endAngle)
      )
    case 'ellipse':
      return (
        Number.isFinite(primitive.cx) &&
        Number.isFinite(primitive.cy) &&
        Number.isFinite(primitive.majorX) &&
        Number.isFinite(primitive.majorY) &&
        Number.isFinite(primitive.majorR) &&
        Number.isFinite(primitive.minorR) &&
        Number.isFinite(primitive.startAngle) &&
        Number.isFinite(primitive.endAngle)
      )
    case 'spline':
      return (
        primitive.controlPoints.every(value => Number.isFinite(value)) &&
        primitive.knots.every(knot => Number.isFinite(knot)) &&
        primitive.weights.every(weight => Number.isFinite(weight))
      )
    case 'point':
      return Number.isFinite(primitive.x) && Number.isFinite(primitive.y)
    case 'path':
      return (
        primitive.vertices.length >= 6 &&
        primitive.vertices.length % 3 === 0 &&
        primitive.vertices.every(value => Number.isFinite(value))
      )
    default: {
      const _exhaustive: never = primitive
      return _exhaustive
    }
  }
}
