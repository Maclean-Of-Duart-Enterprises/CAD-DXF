<template>
  <div class="file-upload-container">
    <div class="upload-panel">
      <div class="upload-main">
        <section class="upload-hero">
          <div class="upload-icon">
            <el-icon :size="20">
              <UploadFilled />
            </el-icon>
          </div>
          <div class="upload-hero-text">
            <h1 class="upload-title">
              {{ t('example.fileUpload.title') }}
            </h1>
            <p class="upload-subtitle">
              {{ t('example.fileUpload.subtitle') }}
            </p>
          </div>
        </section>

        <p class="font-cdn-notice">
          {{ t('example.fileUpload.fontCdnNotice') }}
        </p>
        <a class="license-link" href="./licenses/index.html">
          Open-source licenses
        </a>

        <div class="upload-actions">
          <button
            type="button"
            class="new-drawing-button"
            @click="handleNewDrawing"
          >
            {{ t('example.fileUpload.newDrawing') }}
          </button>

          <p class="upload-divider" aria-hidden="true">
            <span>{{ t('example.fileUpload.or') }}</span>
          </p>

          <el-upload
            class="upload-dropzone"
            drag
            :auto-upload="false"
            accept=".dxf,application/dxf,image/vnd.dxf"
            :on-change="handleFileChange"
            :before-upload="beforeUpload"
          >
            <div class="dropzone-content">
              <p class="dropzone-title">
                {{ t('example.fileUpload.dropFile') }}
                <span class="dropzone-link">
                  {{ t('example.fileUpload.browse') }}
                </span>
              </p>
              <div class="format-tags">
                <span class="format-tag">DXF</span>
              </div>
            </div>
          </el-upload>
        </div>
      </div>

      <section
        class="settings-section"
        :class="{ 'is-expanded': isSettingsExpanded }"
      >
        <button
          type="button"
          class="settings-header"
          :aria-expanded="isSettingsExpanded"
          aria-controls="open-options-panel"
          @click="toggleSettings"
        >
          <h2 class="settings-title">
            {{ t('example.fileUpload.openOptions') }}
          </h2>
          <span class="settings-chevron" aria-hidden="true">&#x25BC;</span>
        </button>

        <div
          id="open-options-panel"
          class="settings-grid"
          :hidden="!isSettingsExpanded"
        >
          <div class="setting-block setting-block--full">
            <h3 class="setting-label">
              {{ t('example.fileUpload.initialView') }}
            </h3>
            <div
              class="pill-segment"
              role="radiogroup"
              :aria-label="t('example.fileUpload.initialView')"
            >
              <button
                v-for="option in openViewModes"
                :key="option.value"
                type="button"
                class="pill-option"
                :class="{ 'is-active': selectedOpenViewMode === option.value }"
                role="radio"
                :aria-checked="selectedOpenViewMode === option.value"
                :title="option.description"
                @click="selectedOpenViewMode = option.value"
              >
                {{ option.label }}
              </button>
            </div>
          </div>

          <div class="setting-block setting-block--full">
            <h3 class="setting-label">
              {{ t('example.fileUpload.accessMode') }}
            </h3>
            <div
              class="pill-segment"
              role="radiogroup"
              :aria-label="t('example.fileUpload.accessMode')"
            >
              <button
                v-for="mode in accessModes"
                :key="mode.value"
                type="button"
                class="pill-option"
                :class="{ 'is-active': selectedMode === mode.value }"
                role="radio"
                :aria-checked="selectedMode === mode.value"
                :title="mode.description"
                @click="selectedMode = mode.value"
              >
                {{ mode.label }}
              </button>
            </div>
          </div>

          <div class="setting-block setting-block--full">
            <h3 class="setting-label">
              {{ t('example.fileUpload.curveQuality') }}
            </h3>
            <div
              class="pill-segment"
              role="radiogroup"
              :aria-label="t('example.fileUpload.curveQuality')"
            >
              <button
                v-for="option in curveQualityOptions"
                :key="option.value"
                type="button"
                class="pill-option"
                :class="{ 'is-active': selectedCircleSides === option.value }"
                role="radio"
                :aria-checked="selectedCircleSides === option.value"
                :title="option.description"
                @click="selectedCircleSides = option.value"
              >
                {{ option.label }}
              </button>
            </div>
          </div>

          <div class="setting-block">
            <h3 class="setting-label">
              {{ t('example.fileUpload.textRendering') }}
            </h3>
            <div
              class="pill-segment"
              role="radiogroup"
              :aria-label="t('example.fileUpload.textRendering')"
            >
              <button
                type="button"
                class="pill-option"
                :class="{ 'is-active': !useMainThreadDraw }"
                role="radio"
                :aria-checked="!useMainThreadDraw"
                :title="t('example.fileUpload.workerHint')"
                @click="useMainThreadDraw = false"
              >
                {{ t('example.fileUpload.worker') }}
              </button>
              <button
                type="button"
                class="pill-option"
                :class="{ 'is-active': useMainThreadDraw }"
                role="radio"
                :aria-checked="useMainThreadDraw"
                :title="t('example.fileUpload.mainThreadHint')"
                @click="useMainThreadDraw = true"
              >
                {{ t('example.fileUpload.mainThread') }}
              </button>
            </div>
          </div>

          <div class="setting-block">
            <h3 class="setting-label">
              {{ t('example.fileUpload.progressive') }}
            </h3>
            <div
              class="pill-segment"
              role="radiogroup"
              :aria-label="t('example.fileUpload.progressiveRendering')"
            >
              <button
                type="button"
                class="pill-option"
                :class="{ 'is-active': progressiveRendering }"
                role="radio"
                :aria-checked="progressiveRendering"
                :title="t('example.fileUpload.progressiveOnHint')"
                @click="progressiveRendering = true"
              >
                {{ t('example.fileUpload.on') }}
              </button>
              <button
                type="button"
                class="pill-option"
                :class="{ 'is-active': !progressiveRendering }"
                role="radio"
                :aria-checked="!progressiveRendering"
                :title="t('example.fileUpload.progressiveOffHint')"
                @click="progressiveRendering = false"
              >
                {{ t('example.fileUpload.off') }}
              </button>
            </div>
          </div>

          <div class="setting-block">
            <h3 class="setting-label">
              {{ t('example.fileUpload.nonPlottable') }}
            </h3>
            <div
              class="pill-segment"
              role="radiogroup"
              :aria-label="t('example.fileUpload.nonPlottableLayers')"
            >
              <button
                type="button"
                class="pill-option"
                :class="{ 'is-active': !drawNoPlotLayers }"
                role="radio"
                :aria-checked="!drawNoPlotLayers"
                :title="t('example.fileUpload.hideHint')"
                @click="drawNoPlotLayers = false"
              >
                {{ t('example.fileUpload.hide') }}
              </button>
              <button
                type="button"
                class="pill-option"
                :class="{ 'is-active': drawNoPlotLayers }"
                role="radio"
                :aria-checked="drawNoPlotLayers"
                :title="t('example.fileUpload.showHint')"
                @click="drawNoPlotLayers = true"
              >
                {{ t('example.fileUpload.show') }}
              </button>
            </div>
          </div>

          <div class="setting-block setting-block--half">
            <h3 class="setting-label">
              {{ t('example.fileUpload.export') }}
            </h3>
            <div
              class="pill-segment"
              role="radiogroup"
              :aria-label="t('example.fileUpload.export')"
            >
              <button
                type="button"
                class="pill-option"
                :class="{ 'is-active': !disableExport }"
                role="radio"
                :aria-checked="!disableExport"
                :title="t('example.fileUpload.exportEnableHint')"
                @click="disableExport = false"
              >
                {{ t('example.fileUpload.exportEnable') }}
              </button>
              <button
                type="button"
                class="pill-option"
                :class="{ 'is-active': disableExport }"
                role="radio"
                :aria-checked="disableExport"
                :title="t('example.fileUpload.exportDisableHint')"
                @click="disableExport = true"
              >
                {{ t('example.fileUpload.exportDisable') }}
              </button>
            </div>
          </div>

          <div class="setting-block setting-block--half">
            <h3 class="setting-label">
              {{ t('example.fileUpload.paperSpaceBackground') }}
            </h3>
            <div
              class="pill-segment"
              role="radiogroup"
              :aria-label="t('example.fileUpload.paperSpaceBackground')"
            >
              <button
                type="button"
                class="pill-option"
                :class="{
                  'is-active':
                    paperSpaceBackground === ACGI_PAPER_SPACE_BACKGROUND
                }"
                role="radio"
                :aria-checked="
                  paperSpaceBackground === ACGI_PAPER_SPACE_BACKGROUND
                "
                :title="t('example.fileUpload.paperSpaceWhiteHint')"
                @click="paperSpaceBackground = ACGI_PAPER_SPACE_BACKGROUND"
              >
                {{ t('example.fileUpload.paperSpaceWhite') }}
              </button>
              <button
                type="button"
                class="pill-option"
                :class="{
                  'is-active':
                    paperSpaceBackground === ACGI_MODEL_SPACE_BACKGROUND
                }"
                role="radio"
                :aria-checked="
                  paperSpaceBackground === ACGI_MODEL_SPACE_BACKGROUND
                "
                :title="t('example.fileUpload.paperSpaceBlackHint')"
                @click="paperSpaceBackground = ACGI_MODEL_SPACE_BACKGROUND"
              >
                {{ t('example.fileUpload.paperSpaceBlack') }}
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>

<script setup lang="ts">
import { UploadFilled } from '@element-plus/icons-vue'
import { AcApOpenViewMode, AcEdOpenMode } from '@mlightcad/cad-simple-viewer'
import {
  ACDB_DRAW_CIRCLE_SIDES_DRAFT,
  ACDB_DRAW_CIRCLE_SIDES_HIGH,
  ACDB_DRAW_CIRCLE_SIDES_STANDARD,
  ACGI_MODEL_SPACE_BACKGROUND,
  ACGI_PAPER_SPACE_BACKGROUND,
  log
} from '@mlightcad/data-model'
import type { UploadFile, UploadProps } from 'element-plus'
import { ElIcon, ElUpload } from 'element-plus'
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useI18n } from 'vue-i18n'

interface Props {
  onFileSelect: (
    file: File,
    mode: AcEdOpenMode,
    useMainThreadDraw: boolean,
    drawNoPlotLayers: boolean,
    progressiveRendering: boolean,
    openViewMode: AcApOpenViewMode | undefined,
    circleSides: number,
    paperSpaceBackground: number,
    disableExport: boolean
  ) => void
  onNewDrawing?: (
    mode: AcEdOpenMode,
    useMainThreadDraw: boolean,
    drawNoPlotLayers: boolean,
    progressiveRendering: boolean,
    openViewMode: AcApOpenViewMode | undefined,
    circleSides: number,
    paperSpaceBackground: number,
    disableExport: boolean
  ) => void
}

const props = defineProps<Props>()
const { t } = useI18n({ useScope: 'global' })

type OpenViewModeChoice = 'auto' | AcApOpenViewMode

const MOBILE_MAX_WIDTH = '(max-width: 768px)'

const getIsMobileLayout = () =>
  typeof window !== 'undefined' && window.matchMedia(MOBILE_MAX_WIDTH).matches

const isMobileLayout = ref(getIsMobileLayout())
const settingsExpanded = ref(!getIsMobileLayout())
const isSettingsExpanded = computed(
  () => !isMobileLayout.value || settingsExpanded.value
)

const selectedMode = ref<AcEdOpenMode>(AcEdOpenMode.Write)
const selectedOpenViewMode = ref<OpenViewModeChoice>('auto')
const selectedCircleSides = ref(ACDB_DRAW_CIRCLE_SIDES_DRAFT)
const useMainThreadDraw = ref(true)
const drawNoPlotLayers = ref(false)
const progressiveRendering = ref(false)
const paperSpaceBackground = ref(ACGI_PAPER_SPACE_BACKGROUND)
const disableExport = ref(false)

let mobileMediaQuery: MediaQueryList | null = null

const syncMobileLayout = () => {
  const matches = mobileMediaQuery?.matches ?? false
  const wasMobile = isMobileLayout.value
  isMobileLayout.value = matches
  if (matches && !wasMobile) {
    settingsExpanded.value = false
  } else if (!matches) {
    settingsExpanded.value = true
  }
}

const toggleSettings = () => {
  if (!isMobileLayout.value) return
  settingsExpanded.value = !settingsExpanded.value
}

onMounted(() => {
  mobileMediaQuery = window.matchMedia(MOBILE_MAX_WIDTH)
  syncMobileLayout()
  mobileMediaQuery.addEventListener('change', syncMobileLayout)
})

onUnmounted(() => {
  mobileMediaQuery?.removeEventListener('change', syncMobileLayout)
  mobileMediaQuery = null
})

const openViewModes = computed(
  () =>
    [
      {
        value: 'auto' as const,
        label: t('example.fileUpload.auto'),
        description: t('example.fileUpload.autoHint')
      },
      {
        value: AcApOpenViewMode.Extents,
        label: t('example.fileUpload.extents'),
        description: t('example.fileUpload.extentsHint')
      },
      {
        value: AcApOpenViewMode.Saved,
        label: t('example.fileUpload.saved'),
        description: t('example.fileUpload.savedHint')
      }
    ] as const
)

const resolveOpenViewMode = (): AcApOpenViewMode | undefined =>
  selectedOpenViewMode.value === 'auto' ? undefined : selectedOpenViewMode.value

const curveQualityOptions = computed(
  () =>
    [
      {
        value: ACDB_DRAW_CIRCLE_SIDES_DRAFT,
        label: t('example.fileUpload.curveDraft'),
        description: t('example.fileUpload.curveDraftHint')
      },
      {
        value: ACDB_DRAW_CIRCLE_SIDES_STANDARD,
        label: t('example.fileUpload.curveStandard'),
        description: t('example.fileUpload.curveStandardHint')
      },
      {
        value: ACDB_DRAW_CIRCLE_SIDES_HIGH,
        label: t('example.fileUpload.curveHigh'),
        description: t('example.fileUpload.curveHighHint')
      }
    ] as const
)

const accessModes = computed(
  () =>
    [
      {
        value: AcEdOpenMode.Read,
        label: t('example.fileUpload.read'),
        description: t('example.fileUpload.readHint')
      },
      {
        value: AcEdOpenMode.Review,
        label: t('example.fileUpload.review'),
        description: t('example.fileUpload.reviewHint')
      },
      {
        value: AcEdOpenMode.Write,
        label: t('example.fileUpload.write'),
        description: t('example.fileUpload.writeHint')
      }
    ] as const
)

const handleFileChange: UploadProps['onChange'] = (uploadFile: UploadFile) => {
  if (uploadFile.raw) {
    if (isValidFile(uploadFile.raw)) {
      props.onFileSelect(
        uploadFile.raw,
        selectedMode.value,
        useMainThreadDraw.value,
        drawNoPlotLayers.value,
        progressiveRendering.value,
        resolveOpenViewMode(),
        selectedCircleSides.value,
        paperSpaceBackground.value,
        disableExport.value
      )
    }
  }
}

const handleNewDrawing = () => {
  props.onNewDrawing?.(
    selectedMode.value,
    useMainThreadDraw.value,
    drawNoPlotLayers.value,
    progressiveRendering.value,
    resolveOpenViewMode(),
    selectedCircleSides.value,
    paperSpaceBackground.value,
    disableExport.value
  )
}

const beforeUpload: UploadProps['beforeUpload'] = (rawFile: File) => {
  if (!isValidFile(rawFile)) {
    log.warn(t('example.fileUpload.invalidFileType'))
    return false
  }
  return true
}

const isValidFile = (file: File): boolean => {
  const validExtensions = ['.dxf']
  const fileName = file.name.toLowerCase()
  return validExtensions.some(ext => fileName.endsWith(ext))
}
</script>

<style scoped>
.file-upload-container {
  display: flex;
  justify-content: center;
  width: 100%;
  max-width: 820px;
  padding: 12px 16px;
  box-sizing: border-box;
}

.upload-panel {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  grid-template-rows: auto;
  width: 100%;
  border-radius: 14px;
  background: #ffffff;
  box-shadow:
    0 20px 40px rgba(15, 23, 42, 0.16),
    0 0 0 1px rgba(255, 255, 255, 0.08);
  overflow: hidden;
}

.upload-main {
  display: flex;
  flex-direction: column;
  min-height: 0;
  padding: 18px 20px;
}

.upload-hero {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 14px;
}

.upload-icon {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  border-radius: 10px;
  background: linear-gradient(135deg, #667eea 0%, #5b6fd6 100%);
  color: #ffffff;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.28);
}

.upload-hero-text {
  min-width: 0;
}

.upload-title {
  margin: 0;
  font-size: 17px;
  font-weight: 700;
  letter-spacing: -0.02em;
  color: #0f172a;
  line-height: 1.25;
}

.upload-subtitle {
  margin: 2px 0 0;
  font-size: 12px;
  color: #64748b;
  line-height: 1.35;
}

.font-cdn-notice {
  margin: 0 0 12px;
  padding: 8px 10px;
  border-radius: 8px;
  border: 1px solid #fde68a;
  background: #fffbeb;
  color: #92400e;
  font-size: 11px;
  line-height: 1.45;
}

.license-link {
  align-self: flex-end;
  margin: -6px 0 10px;
  color: #475569;
  font-size: 11px;
  text-decoration: underline;
}

.upload-actions {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-height: 0;
  gap: 0;
}

.new-drawing-button {
  display: block;
  width: 100%;
  padding: 10px 14px;
  border: none;
  border-radius: 10px;
  background: linear-gradient(135deg, #667eea 0%, #5b6fd6 100%);
  color: #ffffff;
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 0.02em;
  cursor: pointer;
  box-shadow: 0 6px 14px rgba(102, 126, 234, 0.26);
  transition:
    transform 0.15s ease,
    box-shadow 0.2s ease,
    filter 0.2s ease;
}

.new-drawing-button:hover {
  filter: brightness(1.03);
  box-shadow: 0 8px 18px rgba(102, 126, 234, 0.32);
}

.new-drawing-button:active {
  transform: translateY(1px);
}

.upload-divider {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 10px 0;
  font-size: 11px;
  font-weight: 600;
  color: #94a3b8;
  text-transform: uppercase;
  letter-spacing: 0.06em;
}

.upload-divider::before,
.upload-divider::after {
  content: '';
  flex: 1;
  height: 1px;
  background: #e2e8f0;
}

.upload-dropzone {
  display: flex;
  flex: 1;
  flex-direction: column;
  width: 100%;
  min-height: 120px;
  box-sizing: border-box;
}

.upload-dropzone :deep(.el-upload) {
  display: flex;
  flex: 1;
  flex-direction: column;
  width: 100%;
  height: 100%;
}

.upload-dropzone :deep(.el-upload-dragger) {
  display: flex;
  flex: 1;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  padding: 14px 12px;
  border: 1.5px dashed #c7d2fe;
  border-radius: 10px;
  background: #f8faff;
  transition:
    border-color 0.2s ease,
    background-color 0.2s ease,
    box-shadow 0.2s ease;
}

.upload-dropzone :deep(.el-upload-dragger:hover) {
  border-color: #667eea;
  background: #f1f5ff;
  box-shadow: inset 0 0 0 1px rgba(102, 126, 234, 0.08);
}

.dropzone-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
}

.dropzone-title {
  margin: 0;
  font-size: 13px;
  font-weight: 600;
  color: #1e293b;
}

.dropzone-link {
  color: #667eea;
  font-weight: 600;
}

.format-tags {
  display: flex;
  gap: 6px;
}

.format-tag {
  padding: 1px 7px;
  border-radius: 999px;
  background: #e8edff;
  color: #4f5fd0;
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.04em;
}

.settings-section {
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 18px 20px;
  background: #f8fafc;
  border-left: 1px solid #e8edf5;
}

.settings-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  width: 100%;
  margin: 0 0 10px;
  padding: 0;
  border: none;
  background: transparent;
  text-align: left;
  cursor: default;
}

.settings-title {
  margin: 0;
  font-size: 12px;
  font-weight: 600;
  color: #334155;
}

.settings-chevron {
  display: none;
  flex-shrink: 0;
  font-size: 0.65rem;
  color: #94a3b8;
  line-height: 1;
  transition: transform 0.2s ease;
}

.settings-section.is-expanded .settings-chevron {
  transform: rotate(180deg);
}

.settings-grid {
  display: grid;
  /* Six tracks so a row of three options is thirds and a row of two is halves. */
  grid-template-columns: repeat(6, minmax(0, 1fr));
  gap: 10px 12px;
}

.settings-grid[hidden] {
  display: none;
}

.setting-block {
  display: flex;
  flex-direction: column;
  gap: 4px;
  grid-column: span 2;
}

.setting-block--full {
  grid-column: 1 / -1;
}

.setting-block--half {
  grid-column: span 3;
}

.setting-label {
  margin: 0;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: #94a3b8;
}

.pill-segment {
  display: flex;
  gap: 0;
  border: 1.5px solid #e2e8f0;
  border-radius: 7px;
  background: #ffffff;
  overflow: hidden;
}

.pill-option {
  flex: 1;
  padding: 6px 8px;
  border: none;
  background: transparent;
  font-size: 11px;
  font-weight: 600;
  color: #64748b;
  cursor: pointer;
  text-align: center;
  white-space: nowrap;
  transition:
    background-color 0.15s ease,
    color 0.15s ease;
}

.pill-option:not(:last-child) {
  border-right: 1px solid #e2e8f0;
}

.pill-option:hover:not(.is-active) {
  background: #f8fafc;
  color: #475569;
}

.pill-option.is-active {
  background: #f1f5ff;
  color: #4f5fd0;
}

/* Narrow viewports: stack upload + settings as two vertical rows */
@media (max-width: 768px) {
  .file-upload-container {
    max-width: 100%;
    padding: 12px;
  }

  .upload-panel {
    grid-template-columns: 1fr;
    grid-template-rows: auto auto;
  }

  .settings-section {
    border-left: none;
    border-top: 1px solid #e8edf5;
    padding-top: 12px;
    padding-bottom: 12px;
  }

  .settings-header {
    margin-bottom: 0;
    cursor: pointer;
  }

  .settings-section.is-expanded .settings-header {
    margin-bottom: 10px;
  }

  .settings-chevron {
    display: inline-block;
  }

  .settings-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .setting-block,
  .setting-block--half {
    grid-column: auto;
  }

  .setting-block--full {
    grid-column: 1 / -1;
  }
}

@media (max-width: 400px) {
  .upload-main,
  .settings-section {
    padding-left: 14px;
    padding-right: 14px;
  }

  .settings-grid {
    grid-template-columns: 1fr;
  }

  .setting-block,
  .setting-block--half,
  .setting-block--full {
    grid-column: auto;
  }
}
</style>
