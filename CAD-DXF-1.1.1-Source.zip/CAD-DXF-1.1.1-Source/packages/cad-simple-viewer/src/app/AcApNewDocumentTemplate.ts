/** Filename used for format detection when the embedded template is opened. */
export const ACAP_DEFAULT_NEW_DRAWING_FILE = 'templates/acadiso.dxf'

/** Minimal, standards-compatible DXF R2000 drawing used for offline QNEW. */
const ACAP_DEFAULT_NEW_DRAWING_DXF = `0
SECTION
2
HEADER
9
$ACADVER
1
AC1015
0
ENDSEC
0
SECTION
2
TABLES
0
TABLE
2
LAYER
70
1
0
LAYER
2
0
70
0
62
7
6
CONTINUOUS
0
ENDTAB
0
ENDSEC
0
SECTION
2
BLOCKS
0
ENDSEC
0
SECTION
2
ENTITIES
0
ENDSEC
0
EOF
`

/** Returns a fresh buffer containing the built-in offline DXF template. */
export function acapNewDocumentTemplateBuffer(): ArrayBuffer {
  const bytes = new TextEncoder().encode(ACAP_DEFAULT_NEW_DRAWING_DXF)
  return bytes.buffer.slice(
    bytes.byteOffset,
    bytes.byteOffset + bytes.byteLength
  ) as ArrayBuffer
}
