package com.macleanofduartenterprises.caddxf;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.MimeTypeMap;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int REQUEST_OPEN_DXF = 4101;
    private static final int REQUEST_SAVE_DXF = 4102;
    private static final int MAX_INTENT_FILE_BYTES = 64 * 1024 * 1024;
    private static final String LOCAL_HOST = "appassets.androidplatform.net";
    private static final String START_PAGE =
            "https://appassets.androidplatform.net/assets/web/index.html";

    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private byte[] pendingSaveBytes;
    private String pendingSaveName;
    private Uri pendingViewUri;
    private boolean pageReady;

    @Override
    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(16, 16, 16));
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        configureSystemBars(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        // Keep WebView's default network blocking. This app deliberately has
        // no INTERNET permission; packaged HTTPS requests are satisfied by
        // shouldInterceptRequest() below before any network access is needed.
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidCadDxf");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("https".equalsIgnoreCase(scheme)
                        && LOCAL_HOST.equalsIgnoreCase(uri.getHost())) {
                    return false;
                }
                return scheme != null && (scheme.equalsIgnoreCase("http")
                        || scheme.equalsIgnoreCase("https"));
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view,
                    WebResourceRequest request) {
                return openPackagedWebAsset(request.getUrl());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                deliverPendingViewIntent();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileChooserCallback != null) {
                    fileChooserCallback.onReceiveValue(null);
                }
                fileChooserCallback = callback;
                Intent intent = params.createIntent();
                intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(intent, REQUEST_OPEN_DXF);
                return true;
            }
        });

        captureViewIntent(getIntent());
        webView.loadUrl(START_PAGE);
    }

    /**
     * Keeps the editor below status/cutout areas and above gesture navigation.
     * Android 15 enforces edge-to-edge for target SDK 35, so relying only on
     * legacy fitsSystemWindows places ribbon and status controls under system UI.
     */
    private void configureSystemBars(FrameLayout root) {
        getWindow().setStatusBarColor(Color.rgb(18, 18, 18));
        getWindow().setNavigationBarColor(Color.rgb(18, 18, 18));

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }

        root.setOnApplyWindowInsetsListener((view, windowInsets) -> {
            int left;
            int top;
            int right;
            int bottom;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets bars = windowInsets.getInsets(
                        WindowInsets.Type.systemBars()
                                | WindowInsets.Type.displayCutout());
                left = bars.left;
                top = bars.top;
                right = bars.right;
                bottom = bars.bottom;
            } else {
                left = windowInsets.getSystemWindowInsetLeft();
                top = windowInsets.getSystemWindowInsetTop();
                right = windowInsets.getSystemWindowInsetRight();
                bottom = windowInsets.getSystemWindowInsetBottom();
            }
            view.setPadding(left, top, right, bottom);
            return windowInsets;
        });

        // Some Android 15 vendor builds do not create PhoneWindow's DecorView
        // insets controller until after setContentView() has attached the root.
        // Looking it up synchronously can throw inside PhoneWindow even though
        // the public API is nullable. Defer the lookup to the attached view and
        // keep the theme's dark-system-bar defaults if the controller is absent.
        root.post(() -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    WindowInsetsController controller = root.getWindowInsetsController();
                    if (controller != null) {
                        controller.setSystemBarsAppearance(
                                0,
                                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
                    }
                } catch (RuntimeException ignored) {
                    // A vendor window implementation may still be initializing.
                    // Insets padding remains functional and the theme supplies
                    // dark bars with light icons, so startup must continue.
                }
            }
            root.requestApplyInsets();
        });
    }

    private WebResourceResponse openPackagedWebAsset(Uri uri) {
        if (!"https".equalsIgnoreCase(uri.getScheme())
                || !LOCAL_HOST.equalsIgnoreCase(uri.getHost())) {
            return null;
        }
        String path = uri.getPath();
        if (path == null || !path.startsWith("/assets/web/") || path.contains("..")) {
            return null;
        }
        String assetPath = path.substring("/assets/".length());
        String extension = MimeTypeMap.getFileExtensionFromUrl(path);
        String mimeType = MimeTypeMap.getSingleton()
                .getMimeTypeFromExtension(extension.toLowerCase(Locale.ROOT));
        if (mimeType == null) {
            if ("dxf".equalsIgnoreCase(extension)) {
                mimeType = "application/dxf";
            } else {
                mimeType = "application/octet-stream";
            }
        }
        try {
            return new WebResourceResponse(
                    mimeType,
                    mimeType.startsWith("text/") || mimeType.contains("javascript")
                            || mimeType.contains("json") ? "UTF-8" : null,
                    getAssets().open(assetPath));
        } catch (IOException ignored) {
            return null;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        captureViewIntent(intent);
        deliverPendingViewIntent();
    }

    private void captureViewIntent(Intent intent) {
        if (intent != null && Intent.ACTION_VIEW.equals(intent.getAction())) {
            pendingViewUri = intent.getData();
        }
    }

    private void deliverPendingViewIntent() {
        final Uri uri = pendingViewUri;
        if (!pageReady || uri == null) {
            return;
        }
        pendingViewUri = null;
        new Thread(() -> {
            try {
                String name = getDisplayName(uri);
                if (!name.toLowerCase(Locale.ROOT).endsWith(".dxf")) {
                    throw new IOException("Only DXF files are supported");
                }
                byte[] bytes = readLimited(uri, MAX_INTENT_FILE_BYTES);
                String encoded = Base64.encodeToString(bytes, Base64.NO_WRAP);
                String script = "window.receiveDxfFromAndroid && window.receiveDxfFromAndroid("
                        + JSONObject.quote(name) + "," + JSONObject.quote(encoded) + ");";
                runOnUiThread(() -> webView.evaluateJavascript(script, null));
            } catch (Exception error) {
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "Unable to open DXF: " + error.getMessage(),
                        Toast.LENGTH_LONG).show());
            }
        }, "cad-dxf-open").start();
    }

    private String getDisplayName(Uri uri) {
        if (ContentResolver.SCHEME_CONTENT.equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(
                    uri,
                    new String[]{OpenableColumns.DISPLAY_NAME},
                    null,
                    null,
                    null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (index >= 0) {
                        String value = cursor.getString(index);
                        if (value != null && !value.trim().isEmpty()) {
                            return value;
                        }
                    }
                }
            }
        }
        String segment = uri.getLastPathSegment();
        return segment == null || segment.trim().isEmpty() ? "drawing.dxf" : segment;
    }

    private byte[] readLimited(Uri uri, int byteLimit) throws IOException {
        try (InputStream input = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            if (input == null) {
                throw new IOException("The selected file is unavailable");
            }
            byte[] buffer = new byte[64 * 1024];
            int total = 0;
            int count;
            while ((count = input.read(buffer)) != -1) {
                total += count;
                if (total > byteLimit) {
                    throw new IOException("The file is larger than 64 MiB");
                }
                output.write(buffer, 0, count);
            }
            return output.toByteArray();
        }
    }

    private void beginSave(String fileName, byte[] bytes) {
        pendingSaveName = sanitizeDxfName(fileName);
        pendingSaveBytes = bytes;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/dxf");
        intent.putExtra(Intent.EXTRA_TITLE, pendingSaveName);
        startActivityForResult(intent, REQUEST_SAVE_DXF);
    }

    private static String sanitizeDxfName(String value) {
        String safe = value == null ? "drawing.dxf" : value.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (!safe.toLowerCase(Locale.ROOT).endsWith(".dxf")) {
            safe += ".dxf";
        }
        return safe;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OPEN_DXF) {
            ValueCallback<Uri[]> callback = fileChooserCallback;
            fileChooserCallback = null;
            if (callback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
                callback.onReceiveValue(result);
            }
            return;
        }
        if (requestCode == REQUEST_SAVE_DXF) {
            final byte[] bytes = pendingSaveBytes;
            final String name = pendingSaveName;
            pendingSaveBytes = null;
            pendingSaveName = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || bytes == null) {
                return;
            }
            final Uri destination = data.getData();
            new Thread(() -> {
                try (OutputStream output = getContentResolver().openOutputStream(destination, "w")) {
                    if (output == null) {
                        throw new IOException("The destination is unavailable");
                    }
                    output.write(bytes);
                    output.flush();
                    runOnUiThread(() -> Toast.makeText(
                            MainActivity.this,
                            "Saved " + name,
                            Toast.LENGTH_SHORT).show());
                } catch (IOException error) {
                    runOnUiThread(() -> Toast.makeText(
                            MainActivity.this,
                            "Unable to save DXF: " + error.getMessage(),
                            Toast.LENGTH_LONG).show());
                }
            }, "cad-dxf-save").start();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidCadDxf");
            webView.destroy();
        }
        super.onDestroy();
    }

    private final class AndroidBridge {
        @JavascriptInterface
        public void saveDxfFile(String fileName, String base64) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                runOnUiThread(() -> beginSave(fileName, bytes));
            } catch (IllegalArgumentException error) {
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "Unable to prepare the DXF for saving",
                        Toast.LENGTH_LONG).show());
            }
        }
    }
}
