#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$SCRIPT_DIR/app"
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"

if [[ -z "$SDK_ROOT" || ! -d "$SDK_ROOT" ]]; then
  echo "Set ANDROID_SDK_ROOT to an installed Android SDK." >&2
  exit 1
fi

if [[ -n "${ANDROID_BUILD_TOOLS_DIR:-}" ]]; then
  BUILD_TOOLS_DIR="$ANDROID_BUILD_TOOLS_DIR"
else
  BUILD_TOOLS_DIR="$(find "$SDK_ROOT/build-tools" -mindepth 1 -maxdepth 1 -type d -print | sort -V | tail -n 1)"
fi

if [[ -n "${ANDROID_PLATFORM_JAR:-}" ]]; then
  PLATFORM_JAR="$ANDROID_PLATFORM_JAR"
elif [[ -f "$SDK_ROOT/platforms/android-35/android.jar" ]]; then
  PLATFORM_JAR="$SDK_ROOT/platforms/android-35/android.jar"
else
  PLATFORM_JAR="$(find "$SDK_ROOT/platforms" -type f -name android.jar -print | sort -V | tail -n 1)"
fi

for required in aapt2 d8 zipalign apksigner; do
  if [[ ! -x "$BUILD_TOOLS_DIR/$required" ]]; then
    echo "Missing Android build tool: $BUILD_TOOLS_DIR/$required" >&2
    exit 1
  fi
done

if [[ ! -f "$PLATFORM_JAR" ]]; then
  echo "Android platform android.jar was not found." >&2
  exit 1
fi

: "${CAD_DXF_STORE_FILE:?Set CAD_DXF_STORE_FILE to the release keystore path}"
: "${CAD_DXF_STORE_PASSWORD:?Set CAD_DXF_STORE_PASSWORD}"
: "${CAD_DXF_KEY_ALIAS:?Set CAD_DXF_KEY_ALIAS}"
: "${CAD_DXF_KEY_PASSWORD:?Set CAD_DXF_KEY_PASSWORD}"

WEB_ASSETS="$APP_DIR/src/main/assets/web"
if [[ ! -f "$WEB_ASSETS/index.html" ]]; then
  echo "Missing bundled web app at $WEB_ASSETS. Run the web build and sync assets first." >&2
  exit 1
fi

OUT_DIR="$APP_DIR/build/manual"
COMPILED_RES="$OUT_DIR/compiled-res.zip"
UNSIGNED_APK="$OUT_DIR/CAD-DXF-unsigned.apk"
ALIGNED_APK="$OUT_DIR/CAD-DXF-aligned.apk"
FINAL_DIR="$APP_DIR/build/outputs/apk/manual"
FINAL_APK="$FINAL_DIR/CAD-DXF-v1.1.1.apk"

rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR/generated" "$OUT_DIR/classes" "$OUT_DIR/dex" "$FINAL_DIR"

"$BUILD_TOOLS_DIR/aapt2" compile \
  --dir "$APP_DIR/src/main/res" \
  -o "$COMPILED_RES"

"$BUILD_TOOLS_DIR/aapt2" link \
  -o "$UNSIGNED_APK" \
  -I "$PLATFORM_JAR" \
  --manifest "$APP_DIR/src/main/AndroidManifest.xml" \
  --java "$OUT_DIR/generated" \
  --min-sdk-version 26 \
  --target-sdk-version 35 \
  --version-code 4 \
  --version-name 1.1.1 \
  --auto-add-overlay \
  -A "$APP_DIR/src/main/assets" \
  -R "$COMPILED_RES"

mapfile -d '' JAVA_SOURCES < <(find "$APP_DIR/src/main/java" "$OUT_DIR/generated" -type f -name '*.java' -print0)
javac \
  -encoding UTF-8 \
  --release 8 \
  -classpath "$PLATFORM_JAR" \
  -d "$OUT_DIR/classes" \
  "${JAVA_SOURCES[@]}"

mapfile -d '' CLASS_FILES < <(find "$OUT_DIR/classes" -type f -name '*.class' -print0)
"$BUILD_TOOLS_DIR/d8" \
  --lib "$PLATFORM_JAR" \
  --min-api 26 \
  --output "$OUT_DIR/dex" \
  "${CLASS_FILES[@]}"

(cd "$OUT_DIR/dex" && zip -q -j "$UNSIGNED_APK" classes.dex)
"$BUILD_TOOLS_DIR/zipalign" -f -p 4 "$UNSIGNED_APK" "$ALIGNED_APK"

rm -f "$FINAL_APK" "$FINAL_APK.idsig"
"$BUILD_TOOLS_DIR/apksigner" sign \
  --ks "$CAD_DXF_STORE_FILE" \
  --ks-key-alias "$CAD_DXF_KEY_ALIAS" \
  --ks-pass env:CAD_DXF_STORE_PASSWORD \
  --key-pass env:CAD_DXF_KEY_PASSWORD \
  --v1-signing-enabled true \
  --v2-signing-enabled true \
  --v3-signing-enabled true \
  --v4-signing-enabled false \
  --out "$FINAL_APK" \
  "$ALIGNED_APK"

"$BUILD_TOOLS_DIR/apksigner" verify --verbose "$FINAL_APK"
"$BUILD_TOOLS_DIR/zipalign" -c -p 4 "$FINAL_APK"

echo "$FINAL_APK"
