import {
  AcGiMTextData,
  AcGiSubEntityTraits,
  AcGiTextStyle
} from '@mlightcad/data-model'
import { MTextData } from '@mlightcad/mtext-renderer'

import { AcTrMTextRenderer } from '../renderer/AcTrMTextRenderer'
import { AcTrRenderContext } from '../renderer/AcTrRenderContext'
import { AcTrGlyphEntity } from './AcTrGlyphEntity'

/**
 * Display object for a CAD MTEXT entity rendered through the mtext-renderer.
 */
export class AcTrMText extends AcTrGlyphEntity {
  /** Source MTEXT data from the CAD database. */
  private _text: AcGiMTextData

  /**
   * Creates an MTEXT display object.
   *
   * @param text MTEXT content and placement from the CAD database.
   * @param traits CAD sub-entity traits used to resolve color and layer behavior.
   * @param style Text style applied by the mtext-renderer.
   * @param context Active renderer context that owns style and batching policy.
   * @param delay When `true`, skips the initial draw so callers can finish setup first.
   */
  constructor(
    text: AcGiMTextData,
    traits: AcGiSubEntityTraits,
    style: AcGiTextStyle,
    context: AcTrRenderContext,
    _delay: boolean = false
  ) {
    super(context, traits, { ...style })
    this._text = text
    // Geometry is built by syncDraw/asyncDraw in AcTrView2d / AcTrGroup so
    // font-awaiting asyncDraw can run without blocking other entity converts.
  }

  /**
   * Builds renderer input with Z flattened for the 2D plan-view camera.
   *
   * Orthographic views use a narrow near/far band around the camera. MTEXT
   * often carries large DWG elevations while linework/symbols on the same
   * layer may sit at Z=0, so preserving insertion Z would depth-clip glyphs
   * even though the label's XY is inside the viewport.
   *
   * @returns MTEXT payload suitable for the mtext-renderer.
   */
  private toPlanViewMTextData(): MTextData {
    const source = this._text as MTextData
    const position = source.position
    return {
      ...source,
      position: {
        x: position.x,
        y: position.y,
        z: 0
      }
    }
  }

  /**
   * Key for sharing mesh buffers across identical complex-linetype TEXT labels.
   * Placement is applied via this object's transform, not baked into the key.
   */
  get linetypeGlyphShareKey(): string {
    return [
      this._text.text,
      this._text.height,
      this._style.font ?? '',
      this._style.extendedFont ?? '',
      this._style.widthFactor ?? 1,
      this._text.widthFactor ?? 1
    ].join('\0')
  }

  /** @inheritdoc */
  protected override contentShareKey(): string {
    return this.linetypeGlyphShareKey
  }

  /**
   * @inheritdoc
   */
  protected override getDrawPosition() {
    // Complex-linetype labels store WCS placement on this.position.
    const textPos = this._text.position
    if (
      textPos &&
      textPos.x === 0 &&
      textPos.y === 0 &&
      textPos.z === 0 &&
      (this.position.x !== 0 || this.position.y !== 0 || this.position.z !== 0)
    ) {
      return {
        x: this.position.x,
        y: this.position.y,
        z: this.position.z
      }
    }
    return textPos
  }

  /**
   * @inheritdoc
   */
  protected override renderSync(renderer: AcTrMTextRenderer) {
    return renderer.syncRenderMText(
      this.toPlanViewMTextData(),
      this._style,
      this._colorSettings
    )
  }

  /**
   * @inheritdoc
   */
  protected override async renderAsync(renderer: AcTrMTextRenderer) {
    const rendered = await renderer.asyncRenderMText(
      this.toPlanViewMTextData(),
      this._style,
      this._colorSettings
    )
    return rendered
  }

  /**
   * @inheritdoc
   */
  protected override describeRenderFailure() {
    return `mtext '${this._text.text}'`
  }

  /**
   * Preserves MTEXT payload across INSERT template clones.
   *
   * {@link AcTrEntity.fastDeepClone} would otherwise create a plain
   * {@link AcTrEntity} shell that can no longer {@link asyncDraw} glyphs.
   */
  override fastDeepClone(shareGeometry: boolean = false) {
    const cloned = new AcTrMText(
      {
        ...this._text,
        position: { ...this._text.position }
      },
      this.traitsForClone(),
      { ...this._style },
      this.renderContext
    )
    cloned.copyGlyphIdentity(this)
    this.copyGeometry(this, cloned, shareGeometry)
    return cloned
  }
}
