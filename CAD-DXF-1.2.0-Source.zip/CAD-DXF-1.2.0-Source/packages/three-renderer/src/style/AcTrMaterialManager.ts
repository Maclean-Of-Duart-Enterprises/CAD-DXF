import {
  AcCmColor,
  acgiForegroundColorForBackground,
  AcGiLineWeight,
  acgiResolveSubEntityTraitsRgbFromBackground,
  AcGiSubEntityTraits,
  deepClone
} from '@mlightcad/data-model'
import * as THREE from 'three'

import { AcTrCommonUtil, AcTrMaterialUtil } from '../util'
import {
  AcTrByLayerBindingFlags,
  getMaterialMetadata,
  hasByLayerBinding,
  setMaterialMetadata
} from './AcTrMaterialMetadata'
import { AcTrStyleManagerOptions } from './AcTrStyleManagerOptions'

/** Diagnostic snapshot of one material cache. */
export interface AcTrMaterialCacheStats {
  /** Number of cached materials. */
  count: number
  /** Approximate JS-heap bytes (sampled × count). */
  estimatedBytes: number
}

/**
 * Valid material side values for cache partitioning.
 *
 * - `'front'` — default; culls back-faces (CW winding after CCW input).
 * - `'back'`  — culls front-faces; used for meshes whose winding was
 *   reversed by a mirrored transform (negative determinant).
 *
 * `DoubleSide` is intentionally excluded: in 2-D CAD every fill has a
 * deterministic winding after the matrix bake, so one of the two
 * single-side values always suffices with zero fillrate overhead.
 */
export type AcTrMaterialSide = 'front' | 'back'

/**
 * Base class for all material managers (line, fill, point).
 *
 * This class implements:
 * - caching
 * - key → traits storage
 * - getMaterial()
 * - updateLayerMaterial()
 * - dispose()
 *
 * Subclasses must implement:
 * - buildKey()
 * - createMaterialImpl()
 */
export abstract class AcTrMaterialManager<T> {
  /** Materials share this uniform */
  static CameraZoomUniform = { value: 1.0 }

  /** Material cache indexed by key. */
  protected cache: Record<string, THREE.Material> = {}

  /** Original cloned traits for each key (needed for layer updates). */
  protected keyToTraits: Record<string, AcGiSubEntityTraits & T> = {}

  /** Options shared with subclasses (viewport scale, zoom uniforms, etc.) */
  protected options: AcTrStyleManagerOptions

  constructor(options: AcTrStyleManagerOptions) {
    this.options = options
  }

  /**
   * Returns cache cardinality and a sampled memory estimate for diagnostics.
   */
  getStats(): AcTrMaterialCacheStats {
    const keys = Object.keys(this.cache)
    const count = keys.length
    if (count === 0) {
      return { count: 0, estimatedBytes: 0 }
    }
    const sampleKey = keys[0]
    const sampleBytes = AcTrCommonUtil.estimateObjectSize(this.cache[sampleKey])
    const traitsBytes = AcTrCommonUtil.estimateObjectSize(
      this.keyToTraits[sampleKey]
    )
    return {
      count,
      estimatedBytes: (sampleBytes + traitsBytes) * count
    }
  }

  /**
   * Returns (or creates) a material matching traits.
   * Subclasses provide buildKey() and createMaterialImpl().
   *
   * @param layerColorRgb - Optional resolved layer swatch for ByLayer traits
   *   (e.g. MText `\C256`). When omitted, ByLayer materials fall back to white
   *   until a later {@link updateLayerMaterial} refresh.
   * @param layerColor - Optional full layer colour (ACI-7 / foreground tracking).
   */
  getMaterial(
    traits: AcGiSubEntityTraits,
    options: T,
    layerColorRgb?: number,
    layerColor?: AcCmColor
  ): THREE.Material {
    const key = this.buildKey(traits, options)

    // cache original traits
    if (!this.keyToTraits[key]) {
      this.keyToTraits[key] = this.cloneTraits({
        ...traits,
        ...options
      } as AcGiSubEntityTraits & T)
    }

    // hit cache
    if (this.cache[key]) {
      const cached = this.cache[key]
      // First ByLayer create without a swatch leaves white fallback. When a
      // later caller (e.g. MText `\C256`) supplies the layer RGB, paint the
      // shared layer material in place — it is keyed by layer name, so only
      // that layer's ByLayer glyphs are affected.
      if (
        traits.color.isByLayer &&
        typeof layerColorRgb === 'number' &&
        getMaterialMetadata(cached).isForeground !== true
      ) {
        const swatch =
          layerColor ?? new AcCmColor().setRGBValue(layerColorRgb)
        this.refreshMaterialResolvedColor(cached, { color: swatch })
      }
      return cached
    }

    // otherwise create
    return this.createMaterial(
      key,
      traits,
      options,
      undefined,
      layerColorRgb,
      layerColor
    )
  }

  /**
   * Updates all materials belonging to a given layer and whose style is
   * partially or fully ByLayer.
   *
   * A material qualifies for replacement if:
   *   metadata.layer === layerName &&
   *   one of {isByLayerColor,isByLayerLineType,isByLayerLineWeight,isByLayerTransparency} is true
   *
   * For each qualifying material:
   * 1. Rebuild merged traits (old traits + new layer-level traits)
   * 2. Compute a NEW material key
   * 3. When the key is unchanged (typical for ByLayer colour-only updates),
   *    refresh the cached material colour in place and keep the same id
   * 4. Otherwise dispose the old material, create a new one, and remap ids
   * 5. Update cache/keyToTraits
   * 6. Return mapping { oldMaterialId → newMaterial }
   */
  updateLayerMaterial(
    layerName: string,
    newTraits: Partial<AcGiSubEntityTraits>
  ): Record<number, THREE.Material> {
    const idMap: Record<number, THREE.Material> = {}

    // iterate all cached materials and check userData
    for (const oldKey of Object.keys(this.cache)) {
      const oldMaterial = this.cache[oldKey]
      const metadata = getMaterialMetadata(oldMaterial)
      const oldTraits = this.keyToTraits[oldKey]
      if (!oldTraits) continue

      const byLayerBindings = this.resolveByLayerBindings(
        oldTraits,
        oldMaterial
      )

      const isTarget =
        metadata.layer === layerName &&
        (hasByLayerBinding(metadata) ||
          hasByLayerBinding(byLayerBindings) ||
          this.shouldInheritLayerColor(oldTraits, byLayerBindings, oldMaterial))
      if (!isTarget) continue

      // Step 1: merged traits (only mutate traits that are actually ByLayer)
      const mergedTraits = this.cloneTraits(oldTraits)
      this.applyInheritedLayerTraits(
        mergedTraits,
        newTraits,
        byLayerBindings,
        oldMaterial
      )
      if (newTraits.layer != null) {
        mergedTraits.layer = newTraits.layer
      }

      // Step 2: build new key
      const newKey = this.buildKey(mergedTraits, mergedTraits)

      const oldMaterialId = oldMaterial.id

      if (newKey === oldKey) {
        if (byLayerBindings.isByLayerColor && newTraits.color) {
          this.refreshMaterialResolvedColor(oldMaterial, newTraits)
        }
        this.keyToTraits[oldKey] = mergedTraits
        idMap[oldMaterialId] = oldMaterial
        continue
      }

      // Step 3: dispose old
      oldMaterial.dispose()
      delete this.cache[oldKey]
      delete this.keyToTraits[oldKey]

      // Step 4: create new material
      const layerRgb = newTraits.color?.RGB
      const newMaterial = this.createMaterial(
        newKey,
        mergedTraits,
        mergedTraits,
        byLayerBindings,
        typeof layerRgb === 'number' ? layerRgb : undefined,
        newTraits.color
      )

      // Step 5: store merged traits
      this.keyToTraits[newKey] = mergedTraits

      // Step 6: id mapping
      idMap[oldMaterialId] = newMaterial
    }

    return idMap
  }

  /**
   * Changes material color to the specified color if its userData 'isForeground' is true.
   * Generally this function is used to change rendering color of entities whose color is
   * ACI 7.
   * @param color - New rendering color.
   */
  changeForeground(color: number) {
    // iterate all cached materials and check userData
    for (const oldKey of Object.keys(this.cache)) {
      const oldMaterial = this.cache[oldKey]
      const metadata = getMaterialMetadata(oldMaterial)

      const isTarget = metadata.isForeground === true
      if (!isTarget) continue

      const oldTraits = this.keyToTraits[oldKey]
      if (!oldTraits) continue

      AcTrMaterialUtil.setMaterialColor(oldMaterial, new THREE.Color(color))
    }
  }

  /**
   * Changes material color to the specified color if its userData
   * 'isBackgroundFill' is true — i.e. fills that should fuse with the
   * canvas background instead of carrying an absolute RGB.
   *
   * This path is reserved for fill styles that should track the canvas
   * colour itself rather than the foreground colour. Managers opt in via
   * `shouldTrackBackground`; the default is a no-op.
   *
   * @param color - New rendering color (typically the canvas background).
   */
  changeBackground(color: number) {
    for (const oldKey of Object.keys(this.cache)) {
      const oldMaterial = this.cache[oldKey]
      const metadata = getMaterialMetadata(oldMaterial)

      const isTarget = metadata.isBackgroundFill === true
      if (!isTarget) continue

      const oldTraits = this.keyToTraits[oldKey]
      if (!oldTraits) continue

      AcTrMaterialUtil.setMaterialColor(oldMaterial, new THREE.Color(color))
    }
  }

  /**
   * Clears all cached materials.
   */
  dispose(): void {
    Object.values(this.cache).forEach(m => m.dispose())
    this.cache = {}
    this.keyToTraits = {}
  }

  /**
   * Returns a `BackSide` variant of the given material.
   *
   * The default implementation returns the material unchanged — only
   * subclasses whose primitives are affected by face culling (i.e.
   * meshes / fills) override this to produce a cached `BackSide` clone.
   *
   * @param material - A material previously obtained from this manager.
   */
  getBackSideVariant(material: THREE.Material): THREE.Material {
    return material
  }

  /**
   * Returns a cached material bound to the specified effective layer.
   *
   * This is primarily used for block contents that are authored on layer `0` but inherit the
   * layer of the INSERT that owns them. The returned material preserves visual traits and
   * cache semantics, but future layer updates will target the effective layer instead of the
   * original source layer.
   *
   * @param material - Existing cached material to bind.
   * @param layerName - Effective layer name that should own the returned material.
   * @returns The layer-bound cached material, or `undefined` when the input material is not owned
   * by this manager.
   */
  getLayerBoundMaterial(
    material: THREE.Material,
    layerName: string,
    layerTraits?: Partial<AcGiSubEntityTraits>
  ): THREE.Material | undefined {
    const metadata = getMaterialMetadata(material)
    const key = metadata.materialKey
    if (!key) return undefined

    const traits = this.keyToTraits[key]
    if (!traits) return undefined

    if (traits.layer === layerName && !layerTraits) {
      return material
    }

    const remappedTraits: AcGiSubEntityTraits & T = {
      ...this.cloneTraits(traits),
      layer: layerName
    }
    const byLayerBindings = this.resolveByLayerBindings(traits, material)
    this.applyInheritedLayerTraits(
      remappedTraits,
      layerTraits,
      byLayerBindings,
      material
    )
    const remappedKey = this.buildKey(remappedTraits, remappedTraits)

    if (this.cache[remappedKey]) {
      const cached = this.cache[remappedKey]
      if (
        remappedTraits.color.isByLayer &&
        layerTraits?.color &&
        getMaterialMetadata(cached).isByLayerColor
      ) {
        this.refreshMaterialResolvedColor(cached, layerTraits)
      }
      return cached
    }

    this.keyToTraits[remappedKey] = remappedTraits
    const layerRgb = layerTraits?.color?.RGB
    return this.createMaterial(
      remappedKey,
      remappedTraits,
      remappedTraits,
      byLayerBindings,
      typeof layerRgb === 'number' ? layerRgb : undefined,
      layerTraits?.color
    )
  }

  /**
   * Clones render traits while preserving class-based color/transparency values.
   *
   * {@link deepClone} only copies enumerable fields, so `AcCmColor` /
   * `AcCmTransparency` instances would degrade into plain objects and later
   * resolve to white during material rebuilds.
   */
  protected cloneTraits<U extends AcGiSubEntityTraits & Partial<T>>(
    traits: U
  ): U {
    const cloned = deepClone(traits) as U
    if (traits.color?.clone) {
      cloned.color = traits.color.clone()
    }
    if (traits.transparency?.clone) {
      cloned.transparency = traits.transparency.clone()
    }
    return cloned
  }

  /**
   * Applies target-layer traits only to attributes that are actually ByLayer on this entity.
   *
   * This preserves explicit per-entity settings while resolving inherited values during
   * block layer-0 remapping.
   */
  private applyInheritedLayerTraits(
    traits: AcGiSubEntityTraits & T,
    layerTraits?: Partial<AcGiSubEntityTraits>,
    byLayerBindings?: AcTrByLayerBindingFlags,
    material?: THREE.Material
  ) {
    if (!layerTraits) return

    const isByLayerLineType = byLayerBindings?.isByLayerLineType === true
    const isByLayerLineWeight = byLayerBindings?.isByLayerLineWeight === true
    const isByLayerTransparency =
      byLayerBindings?.isByLayerTransparency === true

    if (
      this.shouldInheritLayerColor(traits, byLayerBindings, material) &&
      layerTraits.color &&
      !traits.color.isByLayer
    ) {
      traits.color = layerTraits.color.clone()
    }

    if (isByLayerLineType && layerTraits.lineType) {
      traits.lineType = deepClone(layerTraits.lineType)
    }

    if (isByLayerLineWeight && layerTraits.lineWeight != null) {
      traits.lineWeight = layerTraits.lineWeight
    }

    if (isByLayerTransparency && layerTraits.transparency) {
      traits.transparency = deepClone(layerTraits.transparency)
    }
  }

  /**
   * Returns whether a cached material should follow live layer colour updates.
   */
  protected shouldInheritLayerColor(
    traits: AcGiSubEntityTraits,
    byLayerBindings?: AcTrByLayerBindingFlags,
    material?: THREE.Material
  ): boolean {
    const metadata = material ? getMaterialMetadata(material) : undefined

    if (byLayerBindings?.isByLayerColor === true) {
      return true
    }
    if (traits.color?.isByLayer === true) {
      return true
    }
    if (metadata?.isByLayerColor === true) {
      return true
    }
    if (metadata?.isByLayerColor === false) {
      return !!traits.color?.isByLayer
    }
    if (metadata?.isForeground === true) {
      return false
    }
    return this.hasByLayerKeyTraits(traits)
  }

  /**
   * Resolves ByLayer binding flags from explicit metadata first, then falls back
   * to symbolic traits when metadata is unavailable.
   */
  private resolveByLayerBindings(
    traits: AcGiSubEntityTraits,
    material?: THREE.Material
  ): AcTrByLayerBindingFlags {
    const metadata = material ? getMaterialMetadata(material) : undefined
    const inferredTransparencyByLayer =
      (traits.transparency as Partial<{ isByLayer: boolean }>)?.isByLayer ===
      true

    return {
      isByLayerColor:
        metadata?.isByLayerColor === true ||
        (traits.color.isByLayer === true && metadata?.isForeground !== true),
      isByLayerLineType:
        metadata?.isByLayerLineType ?? traits.lineType.type === 'ByLayer',
      isByLayerLineWeight:
        metadata?.isByLayerLineWeight ??
        traits.lineWeight === AcGiLineWeight.ByLayer,
      isByLayerTransparency:
        metadata?.isByLayerTransparency ?? inferredTransparencyByLayer
    }
  }

  /**
   * Creates a THREE.js material and stores metadata in userData:
   *   - layer
   *   - isByLayerColor/isByLayerLineType/isByLayerLineWeight/isByLayerTransparency
   *   - isForeground      (inverts with layout background when tracked)
   *   - isBackgroundFill  (follows canvas bg when tracked by manager)
   *   - drawOrder         (batch/render-order tier for same-plane meshes)
   *   - materialKey (cache key, used by getBackSideVariant for reverse lookup)
   *
   * `isForeground` and `isBackgroundFill` are mutually exclusive in
   * practice: the former flips a material to the colour *opposite* the
   * canvas bg (so ACI 7 text stays legible), whereas the latter paints
   * the material with the canvas bg itself. Subclasses enforce the split via
   * `shouldTrackForeground` and `shouldTrackBackground`.
   */
  protected createMaterial(
    key: string,
    traits: AcGiSubEntityTraits,
    options: T,
    byLayerBindings?: AcTrByLayerBindingFlags,
    layerColorRgb?: number,
    layerColor?: AcCmColor
  ): THREE.Material {
    const material = this.createMaterialImpl(traits, options, layerColorRgb)
    // A ByLayer material on an ACI-7 layer must follow the foreground too:
    // its resolved layer RGB is the theme-dependent white/black, not an
    // absolute colour (#464). Re-consult shouldTrackForeground with the
    // layer colour substituted so ByLayer-on-ACI-7 obeys the same
    // subclass rules (e.g. gradient/empty-fill exclusions) as explicit
    // ACI-7.
    const isForeground =
      this.shouldTrackForeground(traits, options) ||
      (traits.color.isByLayer &&
        layerColor?.isForeground === true &&
        this.shouldTrackForeground({ ...traits, color: layerColor }, options))
    const isBackgroundFill = this.shouldTrackBackground(traits, options)

    // Foreground-follow materials (typically ACI 7 lines/text) must be
    // initialized from the current layout background, not from trait RGB,
    // otherwise they can be created with stale white before the first
    // background-driven repaint occurs.
    if (isForeground) {
      AcTrMaterialUtil.setMaterialColor(
        material,
        new THREE.Color(
          acgiForegroundColorForBackground(this.options.currentBackgroundColor)
        )
      )
    } else if (isBackgroundFill) {
      // Wipeouts (and any other bg-tracked fills) are born with the current
      // canvas colour so the first frame matches MODELBKCOLOR / PAPERBKCOLOR.
      AcTrMaterialUtil.setMaterialColor(
        material,
        new THREE.Color(this.options.currentBackgroundColor)
      )
    }

    const resolvedByLayerBindings =
      byLayerBindings ?? this.resolveByLayerBindings(traits)

    // Attach metadata required for layer updates and side-variant lookups
    setMaterialMetadata(material, {
      layer: traits.layer,
      isByLayerColor: resolvedByLayerBindings.isByLayerColor,
      isByLayerLineType: resolvedByLayerBindings.isByLayerLineType,
      isByLayerLineWeight: resolvedByLayerBindings.isByLayerLineWeight,
      isByLayerTransparency: resolvedByLayerBindings.isByLayerTransparency,
      isForeground,
      isBackgroundFill,
      drawOrder: traits.drawOrder ?? 0,
      materialKey: key
    })

    this.cache[key] = material
    return material
  }

  /**
   * Returns whether traits should be cached as layer-scoped instead of entity-scoped.
   *
   * This flag is used for material-key partitioning only; userData stores granular
   * ByLayer flags per trait.
   */
  protected hasByLayerKeyTraits(traits: AcGiSubEntityTraits): boolean {
    return traits.color.isByLayer || traits.lineType.type === 'ByLayer'
  }

  /**
   * Whether materials from this manager should follow layout-background
   * ACI-7 inversion (i.e. be flipped by `changeForeground`).
   *
   * The default implementation delegates to `AcCmColor.isForeground`,
   * so lines, points and text glyph fills keep inverting ACI 7 with
   * the theme to preserve legibility (dark stroke on light background
   * / light stroke on dark background).
   *
   * Subclasses can override this to opt a primitive type out of the
   * inversion. `AcTrFillMaterialManager` overrides this and uses
   * `traits.drawOrder` to distinguish text / line-like fills
   * (invert) from hatch fills when needed.
   */
  protected shouldTrackForeground(
    traits: AcGiSubEntityTraits,
    _options: T
  ): boolean {
    return traits.color.isForeground
  }

  /**
   * Whether materials from this manager should follow the canvas
   * background colour — i.e. be repainted by `changeBackground` when
   * the theme flips.
   *
   * Default is `false`: lines, points and text glyph fills never fuse
   * with the background — they need to stay visible against it.
   *
   * Managers can override this to opt specific fill styles into
   * background-follow behaviour.
   */
  protected shouldTrackBackground(
    _traits: AcGiSubEntityTraits,
    _options: T
  ): boolean {
    return false
  }

  /**
   * Cache-key suffix used to keep different render tiers from sharing
   * the same material instance.
   *
   * This matters for mesh primitives because batching groups by
   * material id. If two entities need different `renderOrder` values,
   * they must not collapse onto the same cached material.
   */
  protected buildDrawOrderSuffix(traits: AcGiSubEntityTraits): string {
    return traits.drawOrder === 0 ? '' : `_draw_${traits.drawOrder ?? 0}`
  }

  /** Resolves trait colour to pixel RGB using the current canvas background. */
  protected resolveTraitsRgb(traits: AcGiSubEntityTraits): number {
    return acgiResolveSubEntityTraitsRgbFromBackground(
      traits,
      this.options.currentBackgroundColor
    )
  }

  /**
   * Resolves the RGB written into a Three.js material.
   *
   * Cache keys stay symbolic (`color.toString()`), but materials still carry
   * the current layer-table swatch when it is available.
   */
  protected resolveMaterialRgb(
    traits: AcGiSubEntityTraits,
    layerColorRgb?: number
  ): number {
    if (traits.color.isByLayer && typeof layerColorRgb === 'number') {
      return layerColorRgb
    }
    return this.resolveTraitsRgb(traits)
  }

  /**
   * Builds the colour portion of a material cache key from symbolic CAD colour.
   */
  protected buildKeyColorSegment(traits: AcGiSubEntityTraits): string {
    return traits.color.toString()
  }

  /**
   * Repaints one cached material from resolved layer-table colour.
   *
   * An ACI-7 (foreground) layer colour must not be applied as its raw RGB —
   * that bakes white onto a light canvas (#464). Resolve it against the
   * current background instead, and keep `isForeground` metadata in sync so
   * `changeForeground` flips the material on subsequent background switches.
   */
  protected refreshMaterialResolvedColor(
    material: THREE.Material,
    layerTraits: Partial<AcGiSubEntityTraits>
  ): void {
    const color = layerTraits.color
    if (!color) {
      return
    }
    if (color.isForeground) {
      setMaterialMetadata(material, { isForeground: true })
      AcTrMaterialUtil.setMaterialColor(
        material,
        new THREE.Color(
          acgiForegroundColorForBackground(this.options.currentBackgroundColor)
        )
      )
      return
    }
    const rgb = color.RGB
    if (typeof rgb !== 'number') {
      return
    }
    if (getMaterialMetadata(material).isForeground === true) {
      setMaterialMetadata(material, { isForeground: false })
    }
    AcTrMaterialUtil.setMaterialColor(material, new THREE.Color(rgb))
  }

  /** Subclass must build stable key. */
  protected abstract buildKey(traits: AcGiSubEntityTraits, options: T): string

  /** Subclass must create material. */
  protected abstract createMaterialImpl(
    traits: AcGiSubEntityTraits,
    options: T,
    layerColorRgb?: number
  ): THREE.Material
}
