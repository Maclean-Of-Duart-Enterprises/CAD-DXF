import {
  AcCmColor,
  ACGI_MODEL_SPACE_BACKGROUND,
  acgiForegroundColorForBackground,
  AcGiSubEntityTraits
} from '@mlightcad/data-model'
import * as THREE from 'three'

import { AcTrFillMaterialManager } from './AcTrFillMaterialManager'
import { AcTrLineMaterialManager } from './AcTrLineMaterialManager'
import { AcTrMaterialCacheStats } from './AcTrMaterialManager'
import { AcTrPointMaterialManager } from './AcTrPointMaterialManager'
import { AcTrStyleManagerOptions } from './AcTrStyleManagerOptions'

/** Aggregated material-cache stats across point / line / fill managers. */
export interface AcTrStyleManagerStats {
  point: AcTrMaterialCacheStats
  line: AcTrMaterialCacheStats
  fill: AcTrMaterialCacheStats
  totalCount: number
  totalEstimatedBytes: number
}

/**
 * Central style/material access point for the CAD viewer.
 *
 * This class delegates all material creation to the four specialized
 * AcTrMaterialManager implementations:
 *
 * - Point materials
 * - Line materials
 * - Mesh materials
 * - Hatch materials
 *
 * This ensures consistent material reuse, improved rendering performance,
 * and clean separation of material logic.
 */
export class AcTrStyleManager {
  public options: AcTrStyleManagerOptions = {
    // cameraZoomUniform: 1.0,
    ltscale: 1.0,
    celtscale: 1.0,
    viewportScaleUniform: 1.0,
    maxFragmentUniforms: 1024,
    resolution: new THREE.Vector2(1, 1),
    showLineWeight: false,
    currentBackgroundColor: ACGI_MODEL_SPACE_BACKGROUND
  }
  private pointMgr: AcTrPointMaterialManager
  private lineMgr: AcTrLineMaterialManager
  private fillMgr: AcTrFillMaterialManager
  /**
   * When true, fat-line materials are used even if {@link showLineWeight}
   * (LWDISPLAY) is off. Overlay transients (markup / measurement) set this
   * for the duration of conversion so ribbon lineweight is visible.
   */
  private _forceShowLineWeight = false

  constructor() {
    this.pointMgr = new AcTrPointMaterialManager(this.options)
    this.lineMgr = new AcTrLineMaterialManager(this.options)
    this.fillMgr = new AcTrFillMaterialManager(this.options)
  }

  /** Unsupported text styles mapped by name → usage count. */
  public unsupportedTextStyles: Record<string, number> = {}

  /**
   * Returns a material for point entities.
   *
   * @param size - Point size (default = 2).
   */
  getPointsMaterial(
    traits: AcGiSubEntityTraits,
    size: number = 2
  ): THREE.Material {
    return this.pointMgr.getMaterial(traits, { size })!
  }

  /**
   * Returns a basic or shader line material depending on the lineType.
   *
   * @param traits - Current entity traits.
   * @param basicMaterialOnly - The flag whether to search and return the basic material only
   */
  getLineMaterial(
    traits: AcGiSubEntityTraits,
    basicMaterialOnly?: boolean,
    fatLines?: boolean,
    layerColor?: AcCmColor,
    layerColorRgb?: number
  ): THREE.Material {
    if (fatLines) {
      return this.lineMgr.getMaterial(
        traits,
        { fatLines: true },
        layerColorRgb,
        layerColor
      )!
    }
    const hasLinePattern = !!(
      traits.lineType.pattern && traits.lineType.pattern.length > 0
    )
    const showLineWeight =
      this.options.showLineWeight || this._forceShowLineWeight
    const forceBasicMaterial = !showLineWeight && !hasLinePattern
    return this.lineMgr.getMaterial(
      traits,
      {
        basicMaterialOnly: basicMaterialOnly || forceBasicMaterial
      },
      layerColorRgb,
      layerColor
    )!
  }

  /**
   * Gets whether lineweights are currently displayed.
   */
  get showLineWeight(): boolean {
    return this.options.showLineWeight
  }

  /**
   * Sets whether lineweights are displayed.
   */
  set showLineWeight(value: boolean) {
    this.options.showLineWeight = value
  }

  /**
   * Whether overlay conversion should honor entity lineweights even when
   * {@link showLineWeight} is false.
   */
  get forceShowLineWeight(): boolean {
    return this._forceShowLineWeight
  }

  set forceShowLineWeight(value: boolean) {
    this._forceShowLineWeight = value
  }

  /**
   * Current canvas background colour tracked by the style manager.
   *
   * See `AcTrStyleManagerOptions.currentBackgroundColor` for the full
   * contract. In short: this is the single source of truth that material
   * managers consult when creating theme-sensitive materials.
   */
  get currentBackgroundColor(): number {
    return this.options.currentBackgroundColor
  }

  /**
   * Updates the canvas background colour, repaints background-follow
   * materials, and refreshes ACI-7 foreground inversion to contrast with
   * the new layout background.
   */
  set currentBackgroundColor(value: number) {
    this.options.currentBackgroundColor = value
    this.changeBackground(value)
    this.repaintForegroundMaterials(acgiForegroundColorForBackground(value))
  }

  /**
   * Returns the shader hatch material or a mesh fallback.
   *
   * @param traits - Current entity traits.
   * @param rebaseOffset - Offset used to transform pattern origins.
   */
  getFillMaterial(
    traits: AcGiSubEntityTraits,
    rebaseOffset: THREE.Vector2 = _rebaseOffset,
    gradientBounds?: {
      minX: number
      minY: number
      maxX: number
      maxY: number
    }
  ): THREE.Material {
    return this.fillMgr.getMaterial(traits, {
      rebaseOffset,
      gradientBounds
    })
  }

  /**
   * Returns a fill material for MText glyph geometry.
   *
   * MText glyphs are rendered as mesh fills, so they share the fill
   * manager with hatches and wide polylines. Their distinction now
   * lives on `traits.drawOrder`: normal linework-tier fills stay at
   * `0`, while hatches set `-1` upstream.
   *
   * @param traits - Current entity traits (built via
   *                 `AcTrSubEntityTraitsUtil.createTraitsForMText`).
   * @param rebaseOffset - Offset used to transform pattern origins
   *                       (unused for solid glyph fills, kept for
   *                       API symmetry with `getFillMaterial`).
   */
  getMTextFillMaterial(
    traits: AcGiSubEntityTraits,
    rebaseOffset: THREE.Vector2 = _rebaseOffset,
    layerColor?: AcCmColor,
    layerColorRgb?: number
  ): THREE.Material {
    return this.fillMgr.getMaterial(
      traits,
      {
        rebaseOffset
      },
      layerColorRgb,
      layerColor
    )
  }

  /**
   * Returns a `BackSide` variant of the given fill material.
   *
   * Mirrored block references (transforms with negative determinant)
   * reverse triangle winding.  Instead of paying `DoubleSide` for every
   * fill in the scene, the batching layer calls this method only for
   * meshes that actually need it.  The variant is cached so repeated
   * calls for the same material are free.
   *
   * For non-fill materials (lines, points) this is a no-op — those
   * primitives are unaffected by face culling.
   */
  getBackSideVariant(material: THREE.Material): THREE.Material {
    return this.fillMgr.getBackSideVariant(material)
  }

  /**
   * Forces all materials that belong to the given layer to update,
   * for traits that use ByLayer color or ByLayer lineType.
   *
   * @param layerName - The name of the layer whose materials need to be updated.
   * @param newTraits - Layer-level traits (color, lineType, etc.) resolved from your layer table.
   * @returns Mapping: oldMaterialId → newMaterial
   */
  updateLayerMaterial(
    layerName: string,
    newTraits: Partial<AcGiSubEntityTraits>
  ): Record<number, THREE.Material> {
    return {
      ...this.lineMgr.updateLayerMaterial(layerName, newTraits),
      ...this.pointMgr.updateLayerMaterial(layerName, newTraits),
      ...this.fillMgr.updateLayerMaterial(layerName, newTraits)
    }
  }

  /**
   * Returns a cached material bound to an effective layer without changing symbolic traits.
   *
   * This is used when block contents authored on layer `0` inherit the layer of the INSERT that
   * owns them. The returned material keeps the same appearance now, but future layer updates
   * will target the effective layer instead of the source layer.
   *
   * @param material - Existing material used by a rendered object.
   * @param layerName - Effective layer that should own future updates for this material.
   * @param layerTraits - Optional resolved layer traits applied immediately for ByLayer attributes.
   * @returns A cached material bound to the effective layer.
   */
  getLayerBoundMaterial(
    material: THREE.Material,
    layerName: string,
    layerTraits?: Partial<AcGiSubEntityTraits>
  ) {
    return (
      this.lineMgr.getLayerBoundMaterial(material, layerName, layerTraits) ||
      this.pointMgr.getLayerBoundMaterial(material, layerName, layerTraits) ||
      this.fillMgr.getLayerBoundMaterial(material, layerName, layerTraits) ||
      material
    )
  }

  /**
   * Repaints cached ACI-7 / foreground-tracked materials.
   */
  private repaintForegroundMaterials(color: number) {
    this.lineMgr.changeForeground(color)
    this.pointMgr.changeForeground(color)
    this.fillMgr.changeForeground(color)
  }

  /**
   * Repaints every material marked as `isBackgroundFill` with the given colour.
   *
   * Point and line managers currently never opt materials into this
   * behaviour, so their delegation is a no-op; keeping it symmetric
   * allows future managers to opt in without touching the callers.
   *
   * @param color - New rendering color (typically the canvas bg).
   */
  changeBackground(color: number) {
    this.lineMgr.changeBackground(color)
    this.pointMgr.changeBackground(color)
    this.fillMgr.changeBackground(color)
  }

  /**
   * Clears all cached materials and releases its memory
   */
  dispose(): void {
    this.lineMgr.dispose()
    this.pointMgr.dispose()
    this.fillMgr.dispose()
  }

  /**
   * Returns aggregated material-cache stats for memory diagnostics.
   */
  getStats(): AcTrStyleManagerStats {
    const point = this.pointMgr.getStats()
    const line = this.lineMgr.getStats()
    const fill = this.fillMgr.getStats()
    return {
      point,
      line,
      fill,
      totalCount: point.count + line.count + fill.count,
      totalEstimatedBytes:
        point.estimatedBytes + line.estimatedBytes + fill.estimatedBytes
    }
  }

  updateLineResolution(width: number, height: number): void {
    this.options.resolution.set(width, height)
    this.lineMgr.updateResolution()
  }
}

const _rebaseOffset = /*@__PURE__*/ new THREE.Vector2(0, 0)
