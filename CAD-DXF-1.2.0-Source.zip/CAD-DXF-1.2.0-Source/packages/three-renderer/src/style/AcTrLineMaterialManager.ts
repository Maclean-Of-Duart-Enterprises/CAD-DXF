import { AcGiLineWeight, AcGiSubEntityTraits } from '@mlightcad/data-model'
import * as THREE from 'three'
import { LineMaterial } from 'three/examples/jsm/lines/LineMaterial.js'

import { AcTrLinePatternShaders } from './AcTrLinePatternShaders'
import { AcTrMaterialManager } from './AcTrMaterialManager'

export interface AcTrLineMaterialOptions {
  basicMaterialOnly?: boolean
  /**
   * Antialiased screen-space strokes (Line2) even when lineweight is ByLayer
   * or lineweight display is off. Used by complex TEXT/SHAPE linetypes:
   * WebGL's 1px `GL_LINES` stay device pixels when zoomed and look stair-stepped.
   */
  fatLines?: boolean
}

/**
 * Material manager responsible for creating and caching all line materials.
 *
 * This class supports:
 * - Simple non-patterned lines (THREE.LineBasicMaterial)
 * - Patterned/dashed lines (custom shader materials)
 *
 * Materials are cached by computed keys. Each material also remembers:
 * - The CAD layer it belongs to
 * - Whether its certain property value (for example color or linetype) is ByLayer
 *
 * Layer updates then locate materials using these userData flags instead of
 * maintaining a separate layer → key mapping.
 */
export class AcTrLineMaterialManager extends AcTrMaterialManager<AcTrLineMaterialOptions> {
  /**
   * Builds a stable material key from traits.
   * Every key includes the effective layer so layer-scoped updates stay precise.
   */
  protected buildKey(
    traits: AcGiSubEntityTraits,
    options: AcTrLineMaterialOptions
  ): string {
    const lineWidth = this.resolveLineWidth(traits.lineWeight)
    const mode = this.getMaterialMode(traits, options)
    const drawOrderSuffix = this.buildDrawOrderSuffix(traits)
    const colorKey = this.buildKeyColorSegment(traits)
    const fatSuffix = options.fatLines ? '_aaline' : ''

    if (mode === 'shader') {
      return `${traits.layer}_${mode}_${traits.lineType.name}_${colorKey}_${traits.lineTypeScale}_${lineWidth}${drawOrderSuffix}`
    }

    return `${traits.layer}_${mode}_${colorKey}_${lineWidth}${fatSuffix}${drawOrderSuffix}`
  }

  /** Returns true if a shader material is required. */
  private isShaderMaterial(
    traits: AcGiSubEntityTraits,
    options: AcTrLineMaterialOptions
  ): boolean {
    if (options.fatLines) {
      return false
    }
    // Complex TEXT/SHAPE patterns still use the dash shader for their simple
    // dash/gap elements when {@link buildComplexLineTypeGeometry} declines
    // (density fallback). The shader skips complex elements itself.
    return !!(
      !options.basicMaterialOnly &&
      traits.lineType.pattern &&
      traits.lineType.pattern.length > 0
    )
  }

  private getMaterialMode(
    traits: AcGiSubEntityTraits,
    options: AcTrLineMaterialOptions
  ): 'shader' | 'basic' | 'fat' {
    if (options.fatLines) return 'fat'
    if (this.isShaderMaterial(traits, options)) return 'shader'
    return options.basicMaterialOnly ? 'basic' : 'fat'
  }

  protected createMaterialImpl(
    traits: AcGiSubEntityTraits,
    options: AcTrLineMaterialOptions = {},
    layerColorRgb?: number
  ): THREE.Material {
    let material: THREE.Material
    const rgb = this.resolveMaterialRgb(traits, layerColorRgb)

    const scales = this.getLineTypeScales()
    const scale = scales.ltscale * scales.celtscale * traits.lineTypeScale

    if (this.isShaderMaterial(traits, options)) {
      material = AcTrLinePatternShaders.createLineShaderMaterial(
        traits.lineType.pattern!,
        rgb,
        scale,
        this.options.viewportScaleUniform,
        AcTrMaterialManager.CameraZoomUniform
      )
    } else if (
      !options.fatLines &&
      (options.basicMaterialOnly || traits.lineWeight < 0)
    ) {
      material = new THREE.LineBasicMaterial({
        color: rgb
      })
    } else {
      const fatLineMaterial = new LineMaterial({
        color: rgb,
        linewidth: this.resolveLineWidth(traits.lineWeight)
      })
      fatLineMaterial.resolution.copy(this.options.resolution)
      material = fatLineMaterial
    }
    return material
  }

  protected hasByLayerKeyTraits(traits: AcGiSubEntityTraits): boolean {
    return (
      super.hasByLayerKeyTraits(traits) ||
      traits.lineWeight === AcGiLineWeight.ByLayer
    )
  }

  private resolveLineWidth(lineWeight: AcGiLineWeight): number {
    if (lineWeight < 0) return 1
    return Math.max(1, lineWeight / 40)
  }

  updateResolution() {
    const resolution = this.options.resolution
    Object.values(this.cache).forEach(material => {
      if (material instanceof LineMaterial) {
        material.resolution.copy(resolution)
      }
    })
  }

  //References https://knowledge.autodesk.com/support/autocad-lt/learn-explore/caas/CloudHelp/cloudhelp/2020/ENU/AutoCAD-LT/files/GUID-4323BBAD-2757-4E92-B2E4-E0E550BB37CB-htm.html
  private getLineTypeScales() {
    return {
      ltscale: this.options.ltscale || 1.0,
      celtscale: this.options.celtscale || 1.0
    }
  }
}
