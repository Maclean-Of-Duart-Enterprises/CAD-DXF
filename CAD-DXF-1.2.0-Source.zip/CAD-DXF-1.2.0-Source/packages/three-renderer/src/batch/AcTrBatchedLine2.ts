import * as THREE from 'three'
import { LineMaterial } from 'three/examples/jsm/lines/LineMaterial.js'
import { LineSegments2 } from 'three/examples/jsm/lines/LineSegments2.js'
import { LineSegmentsGeometry } from 'three/examples/jsm/lines/LineSegmentsGeometry.js'

import { AcTrBufferGeometryUtil } from '../util/AcTrBufferGeometryUtil'
import type { AcTrBatchedContainerUserData } from '../util/AcTrObjectUserData'
import {
  AcTrBatchGeometryUserData,
  AcTrVertexBatchGeometryInfo,
  copyArrayContents,
  copyAttributeData,
  isBatchGeometryActive,
  isBatchGeometryVisible
} from './AcTrBatchedGeometryInfo'
import {
  assertReservedCapacity,
  createAcTrBatchedMixin,
  createGeometryState,
  growCapacityIfNeeded,
  reserveGeometryId,
  resolveReservedCount
} from './AcTrBatchedMixin'
import { syncBatchDrawVisibilityAfterOptimize } from './drawVisibility'
import { ensureSlotIdAttribute, writeSlotIdRange } from './highlight'

type AcTrBatchedLine2GeometryInfo = AcTrVertexBatchGeometryInfo

const _box = /*@__PURE__*/ new THREE.Box3()
const _vector = /*@__PURE__*/ new THREE.Vector3()
const _vector2 = /*@__PURE__*/ new THREE.Vector3()
const _segmentStart = /*@__PURE__*/ new THREE.Vector3()
const _segmentEnd = /*@__PURE__*/ new THREE.Vector3()
const _pointOnRay = /*@__PURE__*/ new THREE.Vector3()
const _pointOnSegment = /*@__PURE__*/ new THREE.Vector3()
const _batchIntersects: THREE.Intersection[] = []
const _raycastObject = /*@__PURE__*/ new LineSegments2(
  new LineSegmentsGeometry()
)

const AcTrBatchedLine2Base =
  createAcTrBatchedMixin<AcTrBatchedLine2GeometryInfo>(LineSegments2, {
    typeName: 'AcTrBatchedLine2',
    createObject: () => new LineSegments2(new LineSegmentsGeometry()),
    getDrawRange: (_instance, geometryInfo) => ({
      start: geometryInfo.vertexStart,
      count: geometryInfo.vertexCount
    })
  })

/**
 * Batched renderer for `LineSegments2` wide-line geometries.
 *
 * This class packs many `LineSegmentsGeometry` segment ranges into one shared
 * GPU buffer and renders them via one `LineSegments2` object per material.
 */
export class AcTrBatchedLine2 extends AcTrBatchedLine2Base {
  declare userData: AcTrBatchedContainerUserData
  private static readonly GROWTH_FACTOR = 1.25
  /** Stable world origin for this batch. */
  private _origin?: THREE.Vector3

  /** Current allocated segment capacity. */
  private _maxSegmentCount: number
  /** Next free segment offset for appended geometries. */
  private _nextSegmentStart = 0
  /** Whether packed segment buffers have been allocated. */
  private _geometryInitialized = false

  constructor(maxSegmentCount: number = 1000, material?: THREE.Material) {
    super(new LineSegmentsGeometry(), material)
    this.frustumCulled = false
    this._maxSegmentCount = maxSegmentCount
  }

  get geometryCount() {
    return this._geometryCount
  }

  get unusedSegmentCount() {
    return this._maxSegmentCount - this._nextSegmentStart
  }

  /** World-space origin used when rebasing packed segment data, if established. */
  get origin() {
    return this._origin
  }

  private _initializeGeometry(reference: LineSegmentsGeometry) {
    if (this._geometryInitialized) {
      return
    }
    ;(this.geometry as LineSegmentsGeometry).setPositions(
      new Float32Array(this._maxSegmentCount * 6)
    )
    ensureSlotIdAttribute(this.geometry, this._maxSegmentCount)
    this._copyStaticAttributes(reference)
    this._geometryInitialized = true
  }

  private _copyStaticAttributes(
    reference: LineSegmentsGeometry,
    target: LineSegmentsGeometry = this.geometry as LineSegmentsGeometry
  ) {
    const dstGeometry = target
    const srcIndex = reference.getIndex()
    if (srcIndex) {
      dstGeometry.setIndex(srcIndex.clone())
    }

    for (const key in reference.attributes) {
      if (
        key === 'instanceStart' ||
        key === 'instanceEnd' ||
        key === 'slotId'
      ) {
        continue
      }
      dstGeometry.setAttribute(key, reference.getAttribute(key).clone())
    }
  }

  private _validateGeometry(geometry: LineSegmentsGeometry) {
    const start = geometry.getAttribute('instanceStart')
    const end = geometry.getAttribute('instanceEnd')
    if (!start || !end) {
      throw new Error(
        'AcTrBatchedLine2: Geometry must have "instanceStart" and "instanceEnd" attributes.'
      )
    }
    if (
      start.itemSize !== 3 ||
      end.itemSize !== 3 ||
      start.count !== end.count
    ) {
      throw new Error(
        'AcTrBatchedLine2: Invalid line segment attributes. Expected matching vec3 instanceStart/instanceEnd.'
      )
    }
  }

  private _resizeSpaceIfNeeded(geometry: LineSegmentsGeometry) {
    const segmentCount = geometry.getAttribute('instanceStart').count
    const newMaxSegmentCount = growCapacityIfNeeded({
      currentMaxCount: this._maxSegmentCount,
      nextStart: this._nextSegmentStart,
      requiredCount: segmentCount,
      growthFactor: AcTrBatchedLine2.GROWTH_FACTOR
    })

    if (newMaxSegmentCount > this._maxSegmentCount) {
      this.setGeometrySize(newMaxSegmentCount)
    }
  }

  /**
   * Resets batched state and releases current geometry buffers.
   */
  reset() {
    this.boundingBox = null
    this.boundingSphere = null
    this._geometryInfo = []
    this._availableGeometryIds = []
    this._nextSegmentStart = 0
    this._geometryCount = 0
    this._origin = undefined
    this.position.set(0, 0, 0)
    this._geometryInitialized = false
    this.geometry.dispose()
  }

  /**
   * Appends one source line-segment geometry into the packed segment buffer.
   */
  addGeometry(
    geometry: LineSegmentsGeometry,
    reservedSegmentCount: number = -1,
    worldOffset: THREE.Vector3 = new THREE.Vector3()
  ) {
    this.rebaseGeometryInPlace(geometry, worldOffset)
    this._initializeGeometry(geometry)
    this._validateGeometry(geometry)
    this._resizeSpaceIfNeeded(geometry)

    const segmentCount = geometry.getAttribute('instanceStart').count
    const geometryInfo: AcTrBatchedLine2GeometryInfo = {
      vertexStart: this._nextSegmentStart,
      vertexCount: -1,
      reservedVertexCount: resolveReservedCount(
        reservedSegmentCount,
        segmentCount
      ),
      ...createGeometryState()
    }

    assertReservedCapacity({
      typeName: 'AcTrBatchedLine2',
      maxVertexCount: this._maxSegmentCount,
      vertexStart: geometryInfo.vertexStart,
      reservedVertexCount: geometryInfo.reservedVertexCount
    })

    const { geometryId, geometryCount } = reserveGeometryId(
      this._availableGeometryIds,
      this._geometryInfo,
      this._geometryCount,
      geometryInfo
    )
    this._geometryCount = geometryCount

    this.setGeometryAt(geometryId, geometry)

    this._nextSegmentStart =
      geometryInfo.vertexStart + geometryInfo.reservedVertexCount
    this._syncDrawRange()

    return geometryId
  }

  private rebaseGeometryInPlace(
    geometry: LineSegmentsGeometry,
    worldOffset: THREE.Vector3
  ) {
    const start = geometry.getAttribute('instanceStart') as
      | THREE.InterleavedBufferAttribute
      | THREE.BufferAttribute
      | undefined
    const end = geometry.getAttribute('instanceEnd') as
      | THREE.InterleavedBufferAttribute
      | THREE.BufferAttribute
      | undefined
    if (!start || !end) {
      return
    }

    if (!this._origin) {
      AcTrBufferGeometryUtil.safeComputeBoundingBox(geometry)
      const center = geometry.boundingBox
        ? geometry.boundingBox.getCenter(new THREE.Vector3())
        : new THREE.Vector3()
      this._origin = center.add(worldOffset.clone())
      this.position.copy(this._origin)
    }

    const origin = this._origin
    if (!origin) {
      return
    }

    for (let i = 0; i < start.count; i++) {
      start.setXYZ(
        i,
        start.getX(i) + worldOffset.x - origin.x,
        start.getY(i) + worldOffset.y - origin.y,
        start.getZ(i) + worldOffset.z - origin.z
      )
      end.setXYZ(
        i,
        end.getX(i) + worldOffset.x - origin.x,
        end.getY(i) + worldOffset.y - origin.y,
        end.getZ(i) + worldOffset.z - origin.z
      )
    }

    start.needsUpdate = true
    end.needsUpdate = true
  }

  /**
   * Assigns entity metadata for a packed geometry id.
   */
  setGeometryInfo(geometryId: number, userData: AcTrBatchGeometryUserData) {
    if (geometryId >= this._geometryCount) {
      throw new Error('AcTrBatchedLine2: Maximum geometry count reached.')
    }
    const geometryInfo = this._geometryInfo[geometryId]
    geometryInfo.objectId = userData.objectId
    geometryInfo.bboxIntersectionCheck = userData.bboxIntersectionCheck
  }

  /**
   * Rewrites segment data for an existing packed geometry id.
   */
  setGeometryAt(geometryId: number, geometry: LineSegmentsGeometry) {
    if (geometryId >= this._geometryCount) {
      throw new Error('AcTrBatchedLine2: Maximum geometry count reached.')
    }
    this._validateGeometry(geometry)

    const geometryInfo = this._geometryInfo[geometryId]
    const segmentCount = geometry.getAttribute('instanceStart').count
    if (segmentCount > geometryInfo.reservedVertexCount) {
      throw new Error(
        'AcTrBatchedLine2: Reserved space not large enough for provided geometry.'
      )
    }

    const dstStart = this.geometry.getAttribute('instanceStart')
    const dstEnd = this.geometry.getAttribute('instanceEnd')
    const srcStart = geometry.getAttribute('instanceStart')
    const srcEnd = geometry.getAttribute('instanceEnd')
    const segmentStart = geometryInfo.vertexStart

    copyAttributeData(srcStart, dstStart, segmentStart)
    copyAttributeData(srcEnd, dstEnd, segmentStart)

    for (
      let i = segmentCount, l = geometryInfo.reservedVertexCount;
      i < l;
      i++
    ) {
      const index = segmentStart + i
      for (let c = 0; c < 3; c++) {
        dstStart.setComponent(index, c, 0)
        dstEnd.setComponent(index, c, 0)
      }
    }

    dstStart.needsUpdate = true
    dstEnd.needsUpdate = true

    geometryInfo.vertexCount = segmentCount
    geometryInfo.boundingBox = null

    writeSlotIdRange(
      this.geometry,
      segmentStart,
      geometryInfo.reservedVertexCount,
      geometryId
    )

    return geometryId
  }

  /**
   * Compacts active segment ranges to remove holes left by deletions.
   */
  optimize() {
    const packed = this._getPackedSegmentArray()
    let nextSegmentStart = 0

    const entries = this._geometryInfo
      .map((info, id) => ({ info, id }))
      .filter(e => isBatchGeometryActive(e.info.flags))
      .sort((a, b) => a.info.vertexStart - b.info.vertexStart)

    for (const { info } of entries) {
      const oldStart = info.vertexStart
      const count = info.reservedVertexCount
      if (oldStart !== nextSegmentStart) {
        packed.copyWithin(
          nextSegmentStart * 6,
          oldStart * 6,
          (oldStart + count) * 6
        )
        const slotIdAttr = this.geometry.getAttribute('slotId') as
          | THREE.BufferAttribute
          | undefined
        if (slotIdAttr) {
          slotIdAttr.array.copyWithin(
            nextSegmentStart,
            oldStart,
            oldStart + count
          )
          slotIdAttr.addUpdateRange(nextSegmentStart, count)
          slotIdAttr.needsUpdate = true
        }
      }
      info.vertexStart = nextSegmentStart
      nextSegmentStart += count
    }

    for (let i = nextSegmentStart * 6, l = packed.length; i < l; i++) {
      packed[i] = 0
    }

    this._nextSegmentStart = nextSegmentStart
    this._syncDrawRange()
    this._availableGeometryIds.length = 0

    const instanceStart = this.geometry.getAttribute('instanceStart')
    const instanceEnd = this.geometry.getAttribute('instanceEnd')
    instanceStart.needsUpdate = true
    instanceEnd.needsUpdate = true

    syncBatchDrawVisibilityAfterOptimize(this.geometry, this._geometryInfo)

    return this
  }

  /**
   * Returns cached per-geometry bounds, computing lazily when missing.
   */
  getBoundingBoxAt(geometryId: number, target: THREE.Box3) {
    if (geometryId >= this._geometryCount) {
      return null
    }

    const geometryInfo = this._geometryInfo[geometryId]
    if (geometryInfo.boundingBox === null) {
      const box = new THREE.Box3()
      const start = this.geometry.getAttribute('instanceStart')
      const end = this.geometry.getAttribute('instanceEnd')
      for (
        let i = geometryInfo.vertexStart,
          l = geometryInfo.vertexStart + geometryInfo.vertexCount;
        i < l;
        i++
      ) {
        box.expandByPoint(_vector.fromBufferAttribute(start, i))
        box.expandByPoint(_vector2.fromBufferAttribute(end, i))
      }
      geometryInfo.boundingBox = box
    }

    target.copy(geometryInfo.boundingBox)
    return target
  }

  /**
   * Returns per-geometry bounding sphere derived from cached bounding box.
   */
  getBoundingSphereAt(geometryId: number, target: THREE.Sphere) {
    if (geometryId >= this._geometryCount) {
      return null
    }
    this.getBoundingBoxAt(geometryId, _box)
    _box.getBoundingSphere(target)
    return target
  }

  /**
   * Computes the object-space AABB of one packed slot by scanning the packed
   * `instanceStart`/`instanceEnd` segment data.
   *
   * Overrides the mixin default so aggregate bounds queries (frustum culling,
   * layout extents, picking) never go through the lazily cached slot `Box3`:
   * one cached box per slot would stay resident for the whole session
   * (~234B × slot count, i.e. ~100MB on a large drawing).
   *
   * Numerically identical to {@link getBoundingBoxAt}: both expand `start` and
   * `end` in the same order with the same float values, so aggregate spheres
   * and boxes are bit-for-bit unchanged. The contiguous fast path only skips
   * the `fromBufferAttribute` indirection.
   *
   * @param geometryId - Slot index to query.
   * @param target - Reusable {@link THREE.Box3} that receives the result.
   * @returns `target` when the id is valid, otherwise `null`.
   */
  override computeBoundingBoxAt(
    geometryId: number,
    target: THREE.Box3
  ) {
    if (geometryId >= this._geometryCount) {
      return null
    }

    const geometryInfo = this._geometryInfo[geometryId]
    const start = this.geometry.getAttribute('instanceStart')
    const end = this.geometry.getAttribute('instanceEnd')
    const vertexStart = geometryInfo.vertexStart
    const vertexEnd = vertexStart + geometryInfo.vertexCount
    target.makeEmpty()

    const interleavedStart =
      start instanceof THREE.InterleavedBufferAttribute ? start : null
    const interleavedEnd =
      end instanceof THREE.InterleavedBufferAttribute ? end : null
    if (
      interleavedStart !== null &&
      interleavedEnd !== null &&
      interleavedEnd.data === interleavedStart.data &&
      interleavedStart.itemSize === 3 &&
      interleavedEnd.itemSize === 3 &&
      interleavedStart.offset === 0 &&
      interleavedEnd.offset === 3 &&
      interleavedStart.data.stride === 6
    ) {
      // instanceStart/instanceEnd share one interleaved [sx,sy,sz,ex,ey,ez]
      // buffer; read it as a flat Float32Array.
      const packed = interleavedStart.data.array as Float32Array
      for (let i = vertexStart; i < vertexEnd; i++) {
        const offset = i * 6
        target.expandByPoint(
          _vector.set(packed[offset], packed[offset + 1], packed[offset + 2])
        )
        target.expandByPoint(
          _vector2.set(
            packed[offset + 3],
            packed[offset + 4],
            packed[offset + 5]
          )
        )
      }
      return target
    }

    for (let i = vertexStart; i < vertexEnd; i++) {
      target.expandByPoint(_vector.fromBufferAttribute(start, i))
      target.expandByPoint(_vector2.fromBufferAttribute(end, i))
    }
    return target
  }

  /**
   * Aggregate object-space bounding sphere from one pass over the packed
   * segment ranges of every active slot.
   *
   * Replaces the mixin's per-slot `Box3` + `Sphere.union` with plain min/max
   * comparisons on the contiguous packed buffer: no per-slot object is
   * allocated and the packed data is touched once. The resulting sphere is the
   * circumsphere of the aggregate AABB of the same active slot set, so it
   * still encloses every active vertex — frustum culling can only ever drop a
   * batch whose geometry is entirely outside the frustum, exactly as before.
   *
   * @param target - Sphere that receives the aggregate result.
   * @returns `target`, or `null` when no bounds could be derived.
   */
  override computeAggregateBoundingSphere(target: THREE.Sphere) {
    const start = this.geometry.getAttribute('instanceStart')
    const end = this.geometry.getAttribute('instanceEnd')
    if (!start || !end) {
      return null
    }

    let minX = Infinity
    let minY = Infinity
    let minZ = Infinity
    let maxX = -Infinity
    let maxY = -Infinity
    let maxZ = -Infinity

    const interleavedStart =
      start instanceof THREE.InterleavedBufferAttribute ? start : null
    const interleavedEnd =
      end instanceof THREE.InterleavedBufferAttribute ? end : null
    const packed =
      interleavedStart !== null &&
      interleavedEnd !== null &&
      interleavedEnd.data === interleavedStart.data &&
      interleavedStart.itemSize === 3 &&
      interleavedEnd.itemSize === 3 &&
      interleavedStart.offset === 0 &&
      interleavedEnd.offset === 3 &&
      interleavedStart.data.stride === 6
        ? (interleavedStart.data.array as Float32Array)
        : null

    for (let slot = 0; slot < this._geometryCount; slot++) {
      const info = this._geometryInfo[slot]
      if (!isBatchGeometryActive(info.flags)) continue
      const vertexStart = info.vertexStart
      const vertexEnd = vertexStart + info.vertexCount

      if (packed !== null) {
        for (let i = vertexStart; i < vertexEnd; i++) {
          const offset = i * 6
          const sx = packed[offset]
          const sy = packed[offset + 1]
          const sz = packed[offset + 2]
          const ex = packed[offset + 3]
          const ey = packed[offset + 4]
          const ez = packed[offset + 5]
          if (sx < minX) minX = sx
          if (sy < minY) minY = sy
          if (sz < minZ) minZ = sz
          if (sx > maxX) maxX = sx
          if (sy > maxY) maxY = sy
          if (sz > maxZ) maxZ = sz
          if (ex < minX) minX = ex
          if (ey < minY) minY = ey
          if (ez < minZ) minZ = ez
          if (ex > maxX) maxX = ex
          if (ey > maxY) maxY = ey
          if (ez > maxZ) maxZ = ez
        }
      } else {
        for (let i = vertexStart; i < vertexEnd; i++) {
          _vector.fromBufferAttribute(start, i)
          _vector2.fromBufferAttribute(end, i)
          if (_vector.x < minX) minX = _vector.x
          if (_vector.y < minY) minY = _vector.y
          if (_vector.z < minZ) minZ = _vector.z
          if (_vector.x > maxX) maxX = _vector.x
          if (_vector.y > maxY) maxY = _vector.y
          if (_vector.z > maxZ) maxZ = _vector.z
          if (_vector2.x < minX) minX = _vector2.x
          if (_vector2.y < minY) minY = _vector2.y
          if (_vector2.z < minZ) minZ = _vector2.z
          if (_vector2.x > maxX) maxX = _vector2.x
          if (_vector2.y > maxY) maxY = _vector2.y
          if (_vector2.z > maxZ) maxZ = _vector2.z
        }
      }
    }

    if (minX > maxX) {
      target.makeEmpty()
      return target
    }

    _box.min.set(minX, minY, minZ)
    _box.max.set(maxX, maxY, maxZ)
    return _box.getBoundingSphere(target)
  }

  getGeometryAt(geometryId: number) {
    this.validateGeometryId(geometryId)
    return this._geometryInfo[geometryId]
  }

  /**
   * Resizes packed segment capacity while preserving existing segment data.
   */
  setGeometrySize(maxSegmentCount: number) {
    const oldGeometry = this.geometry as LineSegmentsGeometry
    const oldPacked = this._getPackedSegmentArray()
    const oldSlotId = oldGeometry.getAttribute('slotId') as
      | THREE.BufferAttribute
      | THREE.InstancedBufferAttribute
      | undefined
    const oldSlotIdArray = oldSlotId
      ? (oldSlotId.array as Float32Array).slice(
          0,
          Math.min(oldSlotId.count, this._maxSegmentCount)
        )
      : undefined

    this._maxSegmentCount = maxSegmentCount
    this.geometry = new LineSegmentsGeometry()
    ;(this.geometry as LineSegmentsGeometry).setPositions(
      new Float32Array(maxSegmentCount * 6)
    )

    const newPacked = this._getPackedSegmentArray()
    copyArrayContents(oldPacked, newPacked)
    this._copyStaticAttributes(oldGeometry)
    const slotIdAttr = ensureSlotIdAttribute(this.geometry, maxSegmentCount)
    if (oldSlotIdArray) {
      ;(slotIdAttr.array as Float32Array).set(
        oldSlotIdArray.subarray(
          0,
          Math.min(oldSlotIdArray.length, slotIdAttr.count)
        )
      )
      slotIdAttr.needsUpdate = true
    }
    this._geometryInitialized = true
    this._syncDrawRange()
    oldGeometry.dispose()
  }

  /**
   * Builds a standalone `LineSegments2` object for one packed geometry id.
   */
  getObjectAt(batchId: number) {
    const info = this._geometryInfo[batchId]
    const geometry = this._createSubGeometry(
      info.vertexStart,
      info.vertexCount,
      true
    )
    const object = new LineSegments2(geometry, this.material as LineMaterial)
    object.position.copy(this.position)
    object.updateMatrix()
    object.updateMatrixWorld(true)
    const localBox = object.geometry.boundingBox ?? new THREE.Box3()
    this.computeBoundingBoxAt(batchId, localBox)
    object.geometry.boundingBox = localBox
    const localSphere = object.geometry.boundingSphere ?? new THREE.Sphere()
    localBox.getBoundingSphere(localSphere)
    object.geometry.boundingSphere = localSphere
    return object
  }

  /**
   * Raycasts one packed geometry id.
   */
  intersectWith(
    geometryId: number,
    raycaster: THREE.Raycaster,
    intersects: THREE.Intersection[]
  ) {
    this._intersectWith(geometryId, raycaster, intersects)
  }

  /**
   * Raycasts all packed geometry ids.
   */
  raycast(raycaster: THREE.Raycaster, intersects: THREE.Intersection[]) {
    for (let i = 0, l = this._geometryInfo.length; i < l; i++) {
      this._intersectWith(i, raycaster, intersects)
    }
  }

  /**
   * Deep-copies packed geometry state and bounds.
   */
  copy(source: AcTrBatchedLine2) {
    super.copy(source)
    this.geometry = source.geometry.clone()
    this.boundingBox = source.boundingBox ? source.boundingBox.clone() : null
    this.boundingSphere = source.boundingSphere
      ? source.boundingSphere.clone()
      : null
    this._geometryInfo = source._geometryInfo.map(info => ({
      ...info,
      boundingBox: info.boundingBox ? info.boundingBox.clone() : null
    }))
    this._maxSegmentCount = source._maxSegmentCount
    this._geometryCount = source._geometryCount
    this._nextSegmentStart = source._nextSegmentStart
    this._geometryInitialized = source._geometryInitialized
    this._origin = source._origin?.clone()
    return this
  }

  /**
   * Disposes packed geometry resources.
   */
  dispose() {
    this.geometry.dispose()
    return this
  }

  /**
   * Internal raycast implementation for one packed geometry id.
   */
  _intersectWith(
    geometryId: number,
    raycaster: THREE.Raycaster,
    intersects: THREE.Intersection[]
  ) {
    const geometryInfo = this._geometryInfo[geometryId]
    if (!isBatchGeometryVisible(geometryInfo.flags)) {
      return
    }

    if (geometryInfo.bboxIntersectionCheck) {
      this.computeBoundingBoxAt(geometryId, _box)
      _box.applyMatrix4(this.matrixWorld)
      if (raycaster.ray.intersectBox(_box, _vector)) {
        const distance = raycaster.ray.origin.distanceTo(_vector)
        ;(
          intersects as Array<
            THREE.Intersection & { batchId?: number; objectId?: string }
          >
        ).push({
          distance,
          point: _vector.clone(),
          object: this,
          face: null,
          faceIndex: undefined,
          uv: undefined,
          batchId: geometryId,
          objectId: geometryInfo.objectId
        })
      }
      return
    }

    const geometry = this._createSubGeometry(
      geometryInfo.vertexStart,
      geometryInfo.vertexCount,
      false
    )
    _raycastObject.geometry = geometry
    _raycastObject.material = this.material as LineMaterial
    _raycastObject.position.copy(this.position)
    _raycastObject.quaternion.copy(this.quaternion)
    _raycastObject.scale.copy(this.scale)
    _raycastObject.updateMatrix()
    _raycastObject.updateMatrixWorld(true)
    _raycastObject.raycast(raycaster, _batchIntersects)

    // LineSegments2.raycast() uses pixel LineMaterial.linewidth (plus optional
    // params.Line2.threshold in px), not params.Line.threshold in WCS. When the
    // screen-space pick misses, test distance to each segment against the WCS
    // Line threshold. Do not fall back to the geometry AABB — that would make
    // hollow rectangles / compacted INSERT linework selectable anywhere inside.
    if (_batchIntersects.length === 0) {
      this._intersectSegmentsWithLineThreshold(
        geometry,
        // Use the batch world matrix (includes ancestors). `_raycastObject` is
        // detached and only mirrors local TRS, so its matrixWorld is wrong when
        // the batch sits under a transformed parent.
        this.matrixWorld,
        raycaster,
        geometryId,
        geometryInfo.objectId,
        intersects
      )
      geometry.dispose()
      return
    }

    for (let i = 0, l = _batchIntersects.length; i < l; i++) {
      const intersect = _batchIntersects[i]
      ;(
        intersect as THREE.Intersection & {
          batchId?: number
          objectId?: string
        }
      ).batchId = geometryId
      ;(
        intersect as THREE.Intersection & {
          batchId?: number
          objectId?: string
        }
      ).objectId = geometryInfo.objectId
      intersect.object = this
      intersects.push(intersect)
    }
    _batchIntersects.length = 0
    geometry.dispose()
  }

  /**
   * Picks against packed segments using `raycaster.params.Line.threshold` (WCS).
   *
   * Used when {@link LineSegments2.raycast} misses because it only considers
   * pixel linewidth. Matches {@link THREE.Line} segment-distance semantics so
   * clicks inside a hollow shape's bounding box do not count as hits.
   */
  private _intersectSegmentsWithLineThreshold(
    geometry: LineSegmentsGeometry,
    matrixWorld: THREE.Matrix4,
    raycaster: THREE.Raycaster,
    geometryId: number,
    objectId: string | undefined,
    intersects: THREE.Intersection[]
  ) {
    const threshold = raycaster.params.Line?.threshold ?? 0
    if (!(threshold > 0)) {
      return
    }

    const instanceStart = geometry.getAttribute('instanceStart')
    const instanceEnd = geometry.getAttribute('instanceEnd')
    if (!instanceStart || !instanceEnd) {
      return
    }

    const thresholdSq = threshold * threshold
    const typedIntersects = intersects as Array<
      THREE.Intersection & { batchId?: number; objectId?: string }
    >

    for (let i = 0, l = instanceStart.count; i < l; i++) {
      _segmentStart
        .fromBufferAttribute(instanceStart, i)
        .applyMatrix4(matrixWorld)
      _segmentEnd
        .fromBufferAttribute(instanceEnd, i)
        .applyMatrix4(matrixWorld)

      const distSq = raycaster.ray.distanceSqToSegment(
        _segmentStart,
        _segmentEnd,
        _pointOnRay,
        _pointOnSegment
      )
      if (distSq > thresholdSq) {
        continue
      }

      const distance = raycaster.ray.origin.distanceTo(_pointOnRay)
      if (distance < raycaster.near || distance > raycaster.far) {
        continue
      }

      typedIntersects.push({
        distance,
        point: _pointOnSegment.clone(),
        object: this,
        face: null,
        faceIndex: i,
        uv: undefined,
        batchId: geometryId,
        objectId
      })
    }
  }

  /**
   * Creates a temporary sub-geometry view/copy for raycast/highlight purposes.
   */
  private _createSubGeometry(
    start: number,
    count: number,
    stableCopy: boolean
  ) {
    const packed = this._getPackedSegmentArray()
    const segmentArray = stableCopy
      ? packed.slice(start * 6, (start + count) * 6)
      : packed.subarray(start * 6, (start + count) * 6)
    const geometry = new LineSegmentsGeometry()
    geometry.setPositions(segmentArray)
    this._copyStaticAttributes(this.geometry as LineSegmentsGeometry, geometry)
    return geometry
  }

  /**
   * Returns packed segment array `[sx,sy,sz, ex,ey,ez, ...]`.
   */
  private _getPackedSegmentArray() {
    const instanceStart = this.geometry.getAttribute('instanceStart') as
      | THREE.InterleavedBufferAttribute
      | THREE.InstancedBufferAttribute
    if ('data' in instanceStart && instanceStart.data?.array) {
      return instanceStart.data.array as Float32Array
    }
    const instanceEnd = this.geometry.getAttribute('instanceEnd')
    const count = instanceStart.count
    const array = new Float32Array(count * 6)
    for (let i = 0, p = 0; i < count; i++) {
      array[p++] = instanceStart.getComponent(i, 0)
      array[p++] = instanceStart.getComponent(i, 1)
      array[p++] = instanceStart.getComponent(i, 2)
      array[p++] = instanceEnd.getComponent(i, 0)
      array[p++] = instanceEnd.getComponent(i, 1)
      array[p++] = instanceEnd.getComponent(i, 2)
    }
    return array
  }

  /**
   * Synchronizes rendered instance count with active packed segment range.
   */
  private _syncDrawRange() {
    ;(this.geometry as THREE.InstancedBufferGeometry).instanceCount =
      this._nextSegmentStart
  }
}
