import {
  AcGeBox2d,
  AcGePoint2d,
  AcGePoint2dLike,
  AcGiViewport
} from '@mlightcad/data-model'
import * as THREE from 'three'

import { AcTrRenderer } from '../renderer/AcTrRenderer'
import { AcTrBaseView } from './AcTrBaseView'
import {
  type AcTrCssRect,
  acTrCssRectToWcsBox,
  acTrCssTopLeftRectToGl,
  acTrIntersectCssRects
} from './AcTrCssRect'

/**
 * This class represents view to show viewport.
 */
export class AcTrViewportView extends AcTrBaseView {
  private _parentView: AcTrBaseView
  private _viewport: AcGiViewport

  /**
   * Calcuate the bounding box of this viewport in client window coordinate system
   */
  static calculateViewportWindowBox(
    parentView: AcTrBaseView,
    viewport: AcGiViewport
  ) {
    const wcsViewportBox = viewport.box
    const cwcsViewportBox = new AcGeBox2d()
    cwcsViewportBox.expandByPoint(parentView.worldToScreen(wcsViewportBox.min))
    cwcsViewportBox.expandByPoint(parentView.worldToScreen(wcsViewportBox.max))
    return cwcsViewportBox
  }

  /**
   * Returns `true` when the given viewport represents the **default
   * paper-space viewport** (`*Paper_Space`) — an AutoCAD-internal viewport
   * that exists in every paper-space layout and does not correspond to a
   * user-created viewport.
   *
   * The legacy heuristic was "`number === 1`", but `number` is **not a
   * reliable signal at all** on files parsed by libredwg-web: it reassigns
   * `viewportId` by sorting all VIEWPORT entities on objectId and indexing
   * from 1. This breaks the numeric assumption in **both** directions:
   *
   * - **The default gets `number ≠ 1`** — when the template default's
   *   handle sorts after a real viewport it lands on `2` (or higher). The
   *   old `number === 1` check missed it, so it rendered as a 12×9
   *   (drawing-unit) rectangle that stretched the layout's bounding box,
   *   ruined `zoomToFitDrawing`, and squeezed the real viewports into a
   *   sliver of the canvas.
   * - **A real viewport gets `number === 1`** — when a genuine user
   *   viewport's handle sorts first it receives `number = 1`. The old
   *   shortcut then **false-positived** it and skipped rendering its
   *   content entirely, leaving a large empty area where AutoCAD shows the
   *   viewport's model content (e.g. a large site-plan viewport whose paper
   *   box spans most of the sheet).
   *
   * Because `number` misfires both ways, we rely on structural fingerprints:
   *
   * 1. The default viewport "looks at itself" in paper space, so its
   *    `centerPoint` (paper WCS) coincides with its `viewCenter` (model DCS).
   *    The genuine template default is the `(0,0)-(12,9)` viewport with
   *    `centerPoint == viewCenter == (6,4.5)`.
   * 2. Some LibreDWG parses leave the default's paper `centerPoint` at the
   *    origin `(0,0)` while still storing a sheet-local `viewCenter` and a
   *    1:1 `viewHeight == height` with a zero `viewTarget`. That broken
   *    default must also be filtered: otherwise it draws a large empty
   *    rectangle near the origin and stretches first-visit zoom far away
   *    from the real sheet content.
   *
   * Real user viewports pan/zoom the model (`viewCenter`/`viewTarget` away
   * from the paper rectangle, `viewHeight` unrelated to paper `height`), so
   * they do not match either fingerprint.
   *
   * @param viewport the viewport read from `AcDbViewport.toGiViewport()`
   *                 (or the database entity, which exposes the same
   *                 `centerPoint`/`viewCenter`/`number` properties).
   */
  static isDefaultPaperSpaceViewport(viewport: {
    number: number
    centerPoint: { x: number; y: number }
    viewCenter: { x: number; y: number }
    height?: number
    viewHeight?: number
    viewTarget?: { x: number; y: number }
  }): boolean {
    // Tolerance ~1µ in drawing units — generous enough to absorb
    // floating-point round-tripping through the parser, tight enough
    // that no real user viewport (even one panned to (0,0) of model
    // space) collides with the paper rectangle's center by accident.
    const eps = 1e-6
    const looksAtItself =
      Math.abs(viewport.centerPoint.x - viewport.viewCenter.x) < eps &&
      Math.abs(viewport.centerPoint.y - viewport.viewCenter.y) < eps
    if (looksAtItself) return true

    // Broken LibreDWG default: paper center collapsed to origin, but the
    // viewport still "looks at paper" (1:1 height, zero view target).
    const centerAtOrigin =
      Math.abs(viewport.centerPoint.x) < eps &&
      Math.abs(viewport.centerPoint.y) < eps
    if (!centerAtOrigin) return false

    const height = viewport.height
    const viewHeight = viewport.viewHeight
    if (
      height == null ||
      viewHeight == null ||
      !Number.isFinite(height) ||
      !Number.isFinite(viewHeight) ||
      Math.abs(viewHeight - height) >= eps
    ) {
      return false
    }

    // Missing viewTarget is treated as (0,0): older converters did not
    // surface DXF group 17, but these broken defaults still have a zero
    // target in the DWG.
    const target = viewport.viewTarget
    if (!target) return true
    return Math.abs(target.x) < eps && Math.abs(target.y) < eps
  }

  /**
   * Construct one instance of this class.
   * @param parentView Input parent view of this viewport view. The parent view contains this viewport view.
   * @param viewport Input the viewport associated with this viewport view.
   * @param renderer Input renderer to draw this viewport view
   */
  constructor(
    parentView: AcTrBaseView,
    viewport: AcGiViewport,
    renderer: AcTrRenderer
  ) {
    const viewportWindowBox = AcTrViewportView.calculateViewportWindowBox(
      parentView,
      viewport
    )
    const viewportSize = viewportWindowBox.size
    super(renderer, viewportSize.width, viewportSize.height)
    this._parentView = parentView
    this._viewport = viewport.clone()
    this._frustum *= viewport.height / parentView.height
    this.zoomTo(this._viewport.viewBox)
    this.applyViewTwist()
    this.enabled = false
  }

  /**
   * The viewport associated with this viewport view.
   */
  get viewport() {
    return this._viewport
  }

  /**
   * Update camera of this viewport
   */
  update() {
    this.zoomTo(this._viewport.viewBox, 1.0)
    this.applyViewTwist()
  }

  /**
   * Returns true when the given point (in paper-space WCS) lies within the
   * viewport's rectangular border. Used by selection drill-through to
   * decide whether a click should resolve against the model-space content
   * shown through this viewport.
   */
  containsPaperPoint(paperPt: AcGePoint2dLike): boolean {
    const box = this._viewport.box
    return (
      paperPt.x >= box.min.x &&
      paperPt.x <= box.max.x &&
      paperPt.y >= box.min.y &&
      paperPt.y <= box.max.y
    )
  }

  /**
   * Returns true when the given paper-space point is within `tolerance` of
   * the viewport's border (any of the four edges). Used to distinguish the
   * "click on the viewport frame to select it" gesture from the "click
   * inside to drill into model space" gesture. Tolerance is in paper-space
   * WCS units — the caller is responsible for converting from screen
   * pixels (typically via `selectionBoxSize` already in WCS via
   * `pointToBox`).
   */
  isNearPaperBorder(paperPt: AcGePoint2dLike, tolerance: number): boolean {
    if (!this.containsPaperPoint(paperPt)) return false
    const box = this._viewport.box
    const distLeft = Math.abs(paperPt.x - box.min.x)
    const distRight = Math.abs(paperPt.x - box.max.x)
    const distBottom = Math.abs(paperPt.y - box.min.y)
    const distTop = Math.abs(paperPt.y - box.max.y)
    return Math.min(distLeft, distRight, distBottom, distTop) <= tolerance
  }

  /**
   * Transforms a point from paper-space WCS into the model-space WCS that
   * is visible through this viewport.
   *
   * Maps the paper rectangle onto the DCS view (`viewBox` size around its
   * center), then rotates by {@link AcGiViewport.viewTwistAngle} so a
   * non-zero DVIEW twist matches `AcGiViewport.dcsCenterToWcs` and the
   * camera applied after zoom-to-fit.
   */
  paperPointToModel(paperPt: AcGePoint2dLike): AcGePoint2d {
    const paperBox = this._viewport.box
    const modelBox = this._viewport.viewBox
    const paperW = paperBox.max.x - paperBox.min.x
    const paperH = paperBox.max.y - paperBox.min.y
    const centerX = (modelBox.min.x + modelBox.max.x) / 2
    const centerY = (modelBox.min.y + modelBox.max.y) / 2
    if (paperW <= 0 || paperH <= 0) {
      return new AcGePoint2d(centerX, centerY)
    }
    const localX =
      ((paperPt.x - paperBox.min.x) / paperW - 0.5) *
      (modelBox.max.x - modelBox.min.x)
    const localY =
      ((paperPt.y - paperBox.min.y) / paperH - 0.5) *
      (modelBox.max.y - modelBox.min.y)
    const twist = this._viewport.viewTwistAngle
    if (!Number.isFinite(twist) || twist === 0) {
      return new AcGePoint2d(centerX + localX, centerY + localY)
    }
    const cos = Math.cos(twist)
    const sin = Math.sin(twist)
    return new AcGePoint2d(
      centerX + localX * cos - localY * sin,
      centerY + localX * sin + localY * cos
    )
  }

  /**
   * Rotates this viewport's camera by {@link AcGiViewport.viewTwistAngle}
   * after {@link zoomTo}, which otherwise resets rotation to identity.
   */
  private applyViewTwist() {
    const twist = this._viewport.viewTwistAngle
    const angle = Number.isFinite(twist) ? twist : 0
    this._camera.internalCamera.up.set(-Math.sin(angle), Math.cos(angle), 0)
    this._camera.setRotationFromEuler(new THREE.Euler(0, 0, angle))
    this._camera.updateProjectionMatrix()
  }

  /**
   * Returns the paper→model scale factor for this viewport (greater than 1
   * means model is "larger" than what paper shows, i.e. the viewport zooms
   * out). Useful to convert a tolerance/hit-radius expressed in paper-space
   * WCS into the equivalent radius in model-space DCS for spatial-index
   * searches.
   */
  get paperToModelScale(): number {
    const paperBox = this._viewport.box
    const modelBox = this._viewport.viewBox
    const paperW = paperBox.max.x - paperBox.min.x
    if (paperW <= 0) return 1
    return (modelBox.max.x - modelBox.min.x) / paperW
  }

  /**
   * Clips this paper viewport to the parent canvas and returns the CSS
   * rectangle plus the model-space box that should fill it.
   *
   * A zoomed paper viewport can map to more CSS pixels than WebGL
   * `MAX_VIEWPORT_DIMS`. Clamping that rect shifts NDC (right-side content
   * appears in view) and further zoom draws nothing. The on-screen
   * intersection stays within GPU limits.
   *
   * @returns On-canvas CSS rect and matching model box, or `null` when the
   *   viewport is fully off-screen or has an empty mapping.
   */
  computeOnscreenPass(): { hit: AcTrCssRect; modelBox: AcGeBox2d } | null {
    const viewportWindowBox = AcTrViewportView.calculateViewportWindowBox(
      this._parentView,
      this._viewport
    )
    if (viewportWindowBox.isEmpty()) return null
    const size = viewportWindowBox.size
    const cssVp: AcTrCssRect = {
      x: viewportWindowBox.min.x,
      y: viewportWindowBox.min.y,
      width: size.width,
      height: size.height
    }
    const hit = acTrIntersectCssRects(cssVp, {
      x: 0,
      y: 0,
      width: this._parentView.width,
      height: this._parentView.height
    })
    if (!hit) return null
    // Map the CSS clip onto the DCS view box. Do not send corners through
    // `paperPointToModel`: that applies `viewTwistAngle`, and `render()`
    // already calls `applyViewTwist()` after `zoomTo`. Using the twisted
    // AABB would zoom out fully on-screen twisted viewports.
    const mapped = acTrCssRectToWcsBox(hit, this._viewport.viewBox, cssVp)
    const modelBox = new AcGeBox2d()
    modelBox.expandByPoint({ x: mapped.minX, y: mapped.minY })
    modelBox.expandByPoint({ x: mapped.maxX, y: mapped.maxY })
    if (modelBox.isEmpty()) return null
    return { hit, modelBox }
  }

  /**
   * Render the specified scene in this viewport view
   * @param scene Input the scene to render
   */
  render(scene: THREE.Object3D) {
    const pass = this.computeOnscreenPass()
    if (!pass) return

    this._width = pass.hit.width
    this._height = pass.hit.height
    this._frustum = pass.hit.height / 2
    this.zoomTo(pass.modelBox, 1.0)
    this.applyViewTwist()

    const gl = acTrCssTopLeftRectToGl(pass.hit, this._parentView.height)
    this._renderer.setViewport(gl.x, gl.y, gl.width, gl.height)
    this._renderer.setScissor(gl.x, gl.y, gl.width, gl.height)
    this._renderer.setScissorTest(true)
    this._renderer.render(scene, this._camera)
    this._renderer.setScissorTest(false)
  }
}
