import { AcDbLine, AcGePoint3d } from '@mlightcad/data-model'

import { applyEntityPropertyUpdate } from '../src/component/palette/entityPropertyUpdate'

describe('applyEntityPropertyUpdate', () => {
  it('edits line length while preserving direction', () => {
    const line = new AcDbLine(
      new AcGePoint3d(2, 3, 0),
      new AcGePoint3d(5, 7, 0)
    )

    const changed = applyEntityPropertyUpdate(line, {
      groupName: 'geometry',
      propertyName: 'length',
      newValue: 10
    })

    expect(changed).toBe(true)
    expect(line.startPoint.x).toBe(2)
    expect(line.startPoint.y).toBe(3)
    expect(line.endPoint.x).toBeCloseTo(8)
    expect(line.endPoint.y).toBeCloseTo(11)
  })

  it('edits ordinary runtime properties', () => {
    const line = new AcDbLine(
      new AcGePoint3d(0, 0, 0),
      new AcGePoint3d(5, 0, 0)
    )

    expect(
      applyEntityPropertyUpdate(line, {
        groupName: 'geometry',
        propertyName: 'startX',
        newValue: 2.5
      })
    ).toBe(true)
    expect(line.startPoint.x).toBe(2.5)
  })

  it('rejects invalid lengths without changing geometry', () => {
    const line = new AcDbLine(
      new AcGePoint3d(0, 0, 0),
      new AcGePoint3d(5, 0, 0)
    )

    expect(
      applyEntityPropertyUpdate(line, {
        groupName: 'geometry',
        propertyName: 'length',
        newValue: -1
      })
    ).toBe(false)
    expect(line.endPoint.x).toBe(5)
  })
})
