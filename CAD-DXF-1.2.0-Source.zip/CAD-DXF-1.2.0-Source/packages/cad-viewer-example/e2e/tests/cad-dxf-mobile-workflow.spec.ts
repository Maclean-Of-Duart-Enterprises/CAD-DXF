import { expect, type Page, test } from '@playwright/test'

type TestCadWindow = Window & {
  AcApDocManager?: {
    instance?: {
      curDocument?: {
        database?: {
          tables?: {
            blockTable?: {
              modelSpace?: { newIterator?: () => Iterable<unknown> }
            }
          }
        }
      }
    }
  }
  AndroidCadDxf?: {
    saveDxfFile: (name: string, base64: string) => void
  }
  __savedDxf?: { name: string; base64: string }
}

test.use({
  viewport: { width: 393, height: 852 },
  deviceScaleFactor: 2,
  hasTouch: true,
  isMobile: true,
  userAgent:
    'Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36'
})

async function modelEntityCount(page: Page) {
  return page.evaluate(() => {
    const modelSpace = (window as TestCadWindow).AcApDocManager?.instance
      ?.curDocument?.database?.tables?.blockTable?.modelSpace
    return modelSpace?.newIterator
      ? Array.from(modelSpace.newIterator()).length
      : -1
  })
}

async function openMoreTools(page: Page) {
  await page.getByRole('button', { name: 'More tools' }).click()
  const sheet = page.getByRole('region', { name: 'More drawing tools' })
  await expect(sheet).toBeVisible()
  return sheet
}

test('phone quick tools draw, undo, redo, open panels, and save DXF', async ({
  page
}) => {
  const runtimeErrors: string[] = []
  page.on('pageerror', error => runtimeErrors.push(error.message))
  page.on('console', message => {
    if (message.type() === 'error') runtimeErrors.push(message.text())
  })

  await page.addInitScript(() => {
    const cadWindow = window as TestCadWindow
    cadWindow.AndroidCadDxf = {
      saveDxfFile(name, base64) {
        cadWindow.__savedDxf = { name, base64 }
      }
    }
  })

  await page.goto('/')
  await page.getByRole('button', { name: 'New Drawing' }).click()
  const canvas = page.locator('.ml-cad-container canvas').first()
  await expect(canvas).toBeVisible({ timeout: 30_000 })

  const quickBar = page.getByRole('navigation', {
    name: 'Quick drawing tools'
  })
  await expect(quickBar).toBeVisible()
  await expect(
    quickBar.getByRole('button', { name: 'Line', exact: true })
  ).toBeVisible()
  await expect(
    quickBar.getByRole('button', { name: 'Polyline', exact: true })
  ).toBeVisible()
  await expect(
    quickBar.getByRole('button', { name: 'Circle', exact: true })
  ).toBeVisible()

  await quickBar.getByRole('button', { name: 'Line', exact: true }).click()
  await expect(page.locator('.ml-mobile-cmd-panel')).toBeVisible()
  await expect(
    page.getByText('How to pick points precisely?', { exact: true })
  ).toHaveCount(0)

  const box = await canvas.boundingBox()
  if (!box) throw new Error('Canvas bounding box is unavailable')
  await page.touchscreen.tap(
    box.x + box.width * 0.26,
    box.y + box.height * 0.34
  )
  await page.waitForTimeout(250)
  await page.touchscreen.tap(box.x + box.width * 0.7, box.y + box.height * 0.62)
  await expect.poll(() => modelEntityCount(page)).toBe(1)
  await expect(page.getByRole('button', { name: /Close/ })).toBeVisible()

  const confirm = page.locator('.ml-mobile-cmd-confirm')
  await expect(confirm).toBeEnabled()
  await confirm.click()
  await expect(page.locator('.ml-cad-container')).not.toHaveClass(
    /ml-mobile-cmd-active/
  )
  await expect(quickBar).toBeVisible()

  let moreTools = await openMoreTools(page)
  await moreTools.getByRole('button', { name: 'Undo', exact: true }).click()
  await expect.poll(() => modelEntityCount(page)).toBe(0)

  moreTools = await openMoreTools(page)
  await moreTools.getByRole('button', { name: 'Redo', exact: true }).click()
  await expect.poll(() => modelEntityCount(page)).toBe(1)

  moreTools = await openMoreTools(page)
  await moreTools.getByRole('button', { name: 'Layers', exact: true }).click()
  await expect(page.locator('.ml-layer-list-wrapper')).toBeVisible()
  await page.evaluate(() => {
    ;(
      window as TestCadWindow & {
        AcApDocManager?: {
          instance?: { sendStringToExecute?: (command: string) => void }
        }
      }
    ).AcApDocManager?.instance?.sendStringToExecute?.('layerclose')
  })
  await expect(page.locator('.ml-layer-list-wrapper')).toBeHidden()

  moreTools = await openMoreTools(page)
  await moreTools
    .getByRole('button', { name: 'Properties', exact: true })
    .click()
  await expect(page.locator('.ml-entity-properties-wrapper')).toBeVisible()
  await page.evaluate(() => {
    ;(
      window as TestCadWindow & {
        AcApDocManager?: {
          instance?: { sendStringToExecute?: (command: string) => void }
        }
      }
    ).AcApDocManager?.instance?.sendStringToExecute?.('layerclose')
  })

  moreTools = await openMoreTools(page)
  await moreTools.getByRole('button', { name: 'Save DXF', exact: true }).click()
  await expect
    .poll(() => page.evaluate(() => (window as TestCadWindow).__savedDxf?.name))
    .toMatch(/\.dxf$/i)

  const exported = await page.evaluate(
    () => (window as TestCadWindow).__savedDxf ?? null
  )
  expect(exported).not.toBeNull()
  const dxfText = Buffer.from(exported!.base64, 'base64').toString('utf8')
  expect(dxfText).toContain('SECTION')
  expect(dxfText).toContain('LINE')
  expect(dxfText).toContain('EOF')
  expect(runtimeErrors).toEqual([])
})
