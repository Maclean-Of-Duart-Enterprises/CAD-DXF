<script setup lang="ts">
import { AcApDocManager } from '@mlightcad/cad-simple-viewer'
import { ref } from 'vue'

interface QuickTool {
  label: string
  icon: string
  command: string
}

const primaryTools: QuickTool[] = [
  { label: 'Select', icon: '↖', command: 'select' },
  { label: 'Line', icon: '╱', command: 'line' },
  { label: 'Polyline', icon: '⌑', command: 'pline' },
  { label: 'Circle', icon: '○', command: 'circle' }
]

const toolGroups: Array<{ label: string; tools: QuickTool[] }> = [
  {
    label: 'Draw',
    tools: [
      { label: 'Rectangle', icon: '▭', command: 'rectang' },
      { label: 'Arc', icon: '⌒', command: 'arc' },
      { label: 'Text', icon: 'T', command: 'mtext' },
      { label: 'Hatch', icon: '▒', command: 'hatch' }
    ]
  },
  {
    label: 'Edit',
    tools: [
      { label: 'Move', icon: '✥', command: 'move' },
      { label: 'Copy', icon: '⧉', command: 'copy' },
      { label: 'Rotate', icon: '↻', command: 'rotate' },
      { label: 'Erase', icon: '⌫', command: 'erase' }
    ]
  },
  {
    label: 'Drawing',
    tools: [
      { label: 'Fit view', icon: '⤢', command: 'zoom\nall' },
      { label: 'Layers', icon: '◫', command: 'layer' },
      { label: 'Properties', icon: '≡', command: 'properties' },
      { label: 'Save DXF', icon: '⇩', command: 'cdxf' }
    ]
  },
  {
    label: 'History',
    tools: [
      { label: 'Undo', icon: '↶', command: 'undo' },
      { label: 'Redo', icon: '↷', command: 'redo' }
    ]
  }
]

const expanded = ref(false)
const quickToolsTitle = 'Quick tools'
const closeGlyph = '×'
const moreGlyph = '•••'
const moreLabel = 'More'

const runTool = (tool: QuickTool) => {
  expanded.value = false
  AcApDocManager.instance.sendStringToExecute(tool.command)
}
</script>

<template>
  <div class="cad-dxf-quick-tools">
    <button
      v-if="expanded"
      class="cad-dxf-quick-tools__backdrop"
      type="button"
      aria-label="Close quick tools"
      @click="expanded = false"
    ></button>

    <section
      v-if="expanded"
      id="cad-dxf-more-tools"
      class="cad-dxf-quick-tools__sheet"
      aria-label="More drawing tools"
    >
      <header class="cad-dxf-quick-tools__sheet-header">
        <strong>{{ quickToolsTitle }}</strong>
        <button
          type="button"
          aria-label="Close quick tools"
          @click="expanded = false"
        >
          {{ closeGlyph }}
        </button>
      </header>

      <div
        v-for="group in toolGroups"
        :key="group.label"
        class="cad-dxf-quick-tools__group"
      >
        <span>{{ group.label }}</span>
        <div class="cad-dxf-quick-tools__grid">
          <button
            v-for="tool in group.tools"
            :key="tool.label"
            type="button"
            :aria-label="tool.label"
            @click="runTool(tool)"
          >
            <b aria-hidden="true">{{ tool.icon }}</b>
            {{ tool.label }}
          </button>
        </div>
      </div>
    </section>

    <nav class="cad-dxf-quick-tools__bar" aria-label="Quick drawing tools">
      <button
        v-for="tool in primaryTools"
        :key="tool.label"
        type="button"
        :aria-label="tool.label"
        @click="runTool(tool)"
      >
        <b aria-hidden="true">{{ tool.icon }}</b>
        <span>{{ tool.label }}</span>
      </button>
      <button
        type="button"
        aria-label="More tools"
        aria-controls="cad-dxf-more-tools"
        :aria-expanded="expanded"
        @click="expanded = !expanded"
      >
        <b aria-hidden="true">{{ moreGlyph }}</b>
        <span>{{ moreLabel }}</span>
      </button>
    </nav>
  </div>
</template>

<style scoped>
.cad-dxf-quick-tools {
  display: none;
}

@media (max-width: 720px) {
  .cad-dxf-quick-tools {
    display: block;
    position: fixed;
    left: 8px;
    right: 8px;
    bottom: calc(var(--ml-status-bar-height, 30px) + 6px);
    z-index: 20;
    font-family:
      Inter,
      system-ui,
      -apple-system,
      BlinkMacSystemFont,
      'Segoe UI',
      sans-serif;
    color: #f4f7fb;
  }

  .cad-dxf-quick-tools__bar {
    display: grid;
    grid-template-columns: repeat(5, minmax(0, 1fr));
    gap: 2px;
    width: 100%;
    padding: 4px;
    box-sizing: border-box;
    border: 1px solid #4e5661;
    border-radius: 13px;
    background: rgba(30, 34, 40, 0.97);
    box-shadow: 0 6px 22px rgba(0, 0, 0, 0.45);
    backdrop-filter: blur(12px);
  }

  .cad-dxf-quick-tools button {
    min-width: 0;
    border: 0;
    color: inherit;
    background: transparent;
    font: inherit;
    touch-action: manipulation;
    -webkit-tap-highlight-color: transparent;
  }

  .cad-dxf-quick-tools__bar > button {
    display: flex;
    min-height: 50px;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 1px;
    padding: 3px 2px;
    border-radius: 9px;
    font-size: 11px;
    line-height: 1.15;
  }

  .cad-dxf-quick-tools__bar > button:active,
  .cad-dxf-quick-tools__bar > button[aria-expanded='true'] {
    background: #1976d2;
  }

  .cad-dxf-quick-tools__bar b {
    font-size: 22px;
    font-weight: 500;
    line-height: 1;
  }

  .cad-dxf-quick-tools__backdrop {
    position: fixed;
    inset: 0;
    z-index: -1;
    background: rgba(0, 0, 0, 0.5) !important;
  }

  .cad-dxf-quick-tools__sheet {
    position: absolute;
    right: 0;
    bottom: 62px;
    left: 0;
    max-height: min(62dvh, 520px);
    overflow-y: auto;
    padding: 12px;
    border: 1px solid #59626e;
    border-radius: 16px;
    background: #20252c;
    box-shadow: 0 12px 32px rgba(0, 0, 0, 0.6);
  }

  .cad-dxf-quick-tools__sheet-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 10px;
    font-size: 17px;
  }

  .cad-dxf-quick-tools__sheet-header button {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #333a44;
    font-size: 26px;
  }

  .cad-dxf-quick-tools__group + .cad-dxf-quick-tools__group {
    margin-top: 12px;
  }

  .cad-dxf-quick-tools__group > span {
    display: block;
    margin: 0 0 5px 2px;
    color: #aeb9c7;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
  }

  .cad-dxf-quick-tools__grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 7px;
  }

  .cad-dxf-quick-tools__grid button {
    display: flex;
    min-height: 46px;
    align-items: center;
    gap: 10px;
    padding: 8px 12px;
    border: 1px solid #454d58;
    border-radius: 10px;
    background: #2b313a;
    font-size: 14px;
    text-align: left;
  }

  .cad-dxf-quick-tools__grid button:active {
    border-color: #5eabff;
    background: #174f82;
  }

  .cad-dxf-quick-tools__grid b {
    width: 23px;
    color: #8ac2ff;
    font-size: 20px;
    font-weight: 500;
    text-align: center;
  }
}
</style>

<style>
@media (max-width: 720px) {
  body:has(.ml-mobile-cmd-active) .cad-dxf-quick-tools {
    display: none;
  }
}
</style>
